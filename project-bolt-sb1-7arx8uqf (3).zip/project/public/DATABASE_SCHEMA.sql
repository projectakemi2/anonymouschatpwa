-- =====================================================
-- 匿名チャットPWA - データベーススキーマ完全エクスポート
-- =====================================================
-- 作成日: 2026年1月17日
-- バージョン: 1.0.0
--
-- このファイルは、プロジェクトのデータベース構造全体を含みます
-- 新しいSupabaseプロジェクトでこのスクリプトを実行することで、
-- 同じデータベース構造を再現できます
-- =====================================================

-- =====================================================
-- 1. テーブル作成
-- =====================================================

-- 匿名ユーザーテーブル
CREATE TABLE IF NOT EXISTS anonymous_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  username text NOT NULL,
  avatar_color text DEFAULT '#3B82F6',
  created_at timestamptz DEFAULT now(),
  last_active timestamptz DEFAULT now(),
  is_admin boolean DEFAULT false,
  is_blocked boolean DEFAULT false,
  ip_address text
);

-- メッセージテーブル
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES anonymous_users(id) ON DELETE CASCADE,
  content text NOT NULL,
  image_url text,
  room_id text DEFAULT 'default',
  created_at timestamptz DEFAULT now()
);

-- チャットルームテーブル
CREATE TABLE IF NOT EXISTS rooms (
  id text PRIMARY KEY,
  name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by text NOT NULL
);

-- IPブロックテーブル
CREATE TABLE IF NOT EXISTS ip_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address text UNIQUE NOT NULL,
  reason text,
  blocked_at timestamptz DEFAULT now(),
  blocked_by uuid REFERENCES anonymous_users(id)
);

-- デバイス分析テーブル
CREATE TABLE IF NOT EXISTS device_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES anonymous_users(id) ON DELETE CASCADE,
  device_type text NOT NULL,
  browser text,
  os text,
  screen_width integer,
  screen_height integer,
  user_agent text,
  language text,
  timezone text,
  connection_type text,
  is_mobile boolean DEFAULT false,
  is_tablet boolean DEFAULT false,
  is_desktop boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- =====================================================
-- 2. インデックス作成
-- =====================================================

-- anonymous_users インデックス
CREATE INDEX IF NOT EXISTS idx_anonymous_users_device_id ON anonymous_users(device_id);
CREATE INDEX IF NOT EXISTS idx_anonymous_users_ip ON anonymous_users(ip_address);
CREATE INDEX IF NOT EXISTS idx_anonymous_users_last_active ON anonymous_users(last_active);

-- messages インデックス
CREATE INDEX IF NOT EXISTS idx_messages_room_created ON messages(room_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);

-- rooms インデックス
CREATE INDEX IF NOT EXISTS idx_rooms_created_at ON rooms(created_at DESC);

-- ip_blocks インデックス
CREATE INDEX IF NOT EXISTS idx_ip_blocks_ip ON ip_blocks(ip_address);

-- device_analytics インデックス
CREATE INDEX IF NOT EXISTS idx_device_analytics_user ON device_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_device_analytics_created ON device_analytics(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_device_analytics_device_type ON device_analytics(device_type);

-- =====================================================
-- 3. Row Level Security (RLS) 有効化
-- =====================================================

ALTER TABLE anonymous_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE ip_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE device_analytics ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- 4. RLS ポリシー作成
-- =====================================================

-- === anonymous_users ポリシー ===

-- 全員が全ユーザーを閲覧可能
DROP POLICY IF EXISTS "anonymous_users_select_policy" ON anonymous_users;
CREATE POLICY "anonymous_users_select_policy"
  ON anonymous_users FOR SELECT
  TO public
  USING (true);

-- 全員が新規ユーザーを作成可能
DROP POLICY IF EXISTS "anonymous_users_insert_policy" ON anonymous_users;
CREATE POLICY "anonymous_users_insert_policy"
  ON anonymous_users FOR INSERT
  TO public
  WITH CHECK (true);

-- 自分のユーザー情報のみ更新可能
DROP POLICY IF EXISTS "anonymous_users_update_policy" ON anonymous_users;
CREATE POLICY "anonymous_users_update_policy"
  ON anonymous_users FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- === messages ポリシー ===

-- 全員が全メッセージを閲覧可能
DROP POLICY IF EXISTS "messages_select_policy" ON messages;
CREATE POLICY "messages_select_policy"
  ON messages FOR SELECT
  TO public
  USING (true);

-- 全員がメッセージを投稿可能
DROP POLICY IF EXISTS "messages_insert_policy" ON messages;
CREATE POLICY "messages_insert_policy"
  ON messages FOR INSERT
  TO public
  WITH CHECK (true);

-- === rooms ポリシー ===

-- 全員が全ルームを閲覧可能
DROP POLICY IF EXISTS "rooms_select_policy" ON rooms;
CREATE POLICY "rooms_select_policy"
  ON rooms FOR SELECT
  TO public
  USING (true);

-- 管理者のみルームを作成可能
DROP POLICY IF EXISTS "rooms_insert_policy" ON rooms;
CREATE POLICY "rooms_insert_policy"
  ON rooms FOR INSERT
  TO public
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id::text = created_by
      AND anonymous_users.is_admin = true
    )
  );

-- === ip_blocks ポリシー ===

-- 全員がブロック情報を閲覧可能
DROP POLICY IF EXISTS "ip_blocks_select_policy" ON ip_blocks;
CREATE POLICY "ip_blocks_select_policy"
  ON ip_blocks FOR SELECT
  TO public
  USING (true);

-- 管理者のみIPブロックを追加可能
DROP POLICY IF EXISTS "ip_blocks_insert_policy" ON ip_blocks;
CREATE POLICY "ip_blocks_insert_policy"
  ON ip_blocks FOR INSERT
  TO public
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = blocked_by
      AND anonymous_users.is_admin = true
    )
  );

-- === device_analytics ポリシー ===

-- 管理者のみ閲覧可能
DROP POLICY IF EXISTS "device_analytics_select_policy" ON device_analytics;
CREATE POLICY "device_analytics_select_policy"
  ON device_analytics FOR SELECT
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = device_analytics.user_id
      AND anonymous_users.is_admin = true
    )
  );

-- 全員が自分のデバイス情報を記録可能
DROP POLICY IF EXISTS "device_analytics_insert_policy" ON device_analytics;
CREATE POLICY "device_analytics_insert_policy"
  ON device_analytics FOR INSERT
  TO public
  WITH CHECK (true);

-- =====================================================
-- 5. 拡張機能の有効化
-- =====================================================

-- pg_cron拡張を有効化（自動クリーンアップ用）
-- 注意: これはSupabaseダッシュボードから手動で有効化する必要があります

-- =====================================================
-- 6. 自動クリーンアップジョブ（pg_cron）
-- =====================================================

-- 古いメッセージを削除（7日以上前）
-- SELECT cron.schedule(
--   'delete-old-messages',
--   '0 2 * * *',
--   $$ DELETE FROM messages WHERE created_at < NOW() - INTERVAL '7 days' $$
-- );

-- 非アクティブユーザーを削除（30日以上非アクティブ）
-- SELECT cron.schedule(
--   'delete-inactive-users',
--   '0 3 * * *',
--   $$ DELETE FROM anonymous_users WHERE last_active < NOW() - INTERVAL '30 days' AND is_admin = false $$
-- );

-- 注意: 上記のcronジョブは、Supabaseダッシュボード > Database > Extensions
-- でpg_cronを有効化した後、SQL Editorで実行してください

-- =====================================================
-- 7. ストレージバケット設定
-- =====================================================

-- chat-images バケットの作成
-- これはSupabaseダッシュボード > Storage から手動で作成してください
--
-- バケット設定:
-- - 名前: chat-images
-- - Public: true
-- - File size limit: 5MB
-- - Allowed MIME types: image/jpeg, image/png, image/gif, image/webp

-- chat-images バケットのRLSポリシー:
-- 1. 全員がアップロード可能
-- 2. 全員が閲覧可能

-- =====================================================
-- 8. Realtime設定
-- =====================================================

-- Realtimeを有効化するテーブル:
-- - messages
-- - anonymous_users
-- - rooms
--
-- これはSupabaseダッシュボード > Database > Replication
-- から各テーブルでRealtimeを有効化してください

-- =====================================================
-- 9. データベース設定の推奨値
-- =====================================================

-- Connection Pooling: Session
-- Pooler Mode: Transaction
-- Default Pool Size: 15

-- =====================================================
-- 完了
-- =====================================================

-- このスクリプトの実行が完了したら、以下を確認してください:
-- 1. すべてのテーブルが作成されている
-- 2. すべてのインデックスが作成されている
-- 3. RLSが有効化されている
-- 4. すべてのポリシーが設定されている
-- 5. ストレージバケット(chat-images)が作成されている
-- 6. Realtimeが有効化されている（messages, anonymous_users, rooms）
-- 7. pg_cron拡張が有効化されている（オプション）

-- データベースの準備が完了しました！

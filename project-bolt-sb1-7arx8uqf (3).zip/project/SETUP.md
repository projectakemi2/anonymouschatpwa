# セットアップガイド

## 1. 初期管理者アカウントの作成

アプリの管理者を作成するには、以下の2つの方法があります。

### 方法1: 直接SQLで管理者を作成

Supabase Dashboard > SQL Editor で以下を実行：

```sql
-- あなたのIPアドレスを確認（https://api.ipify.org にアクセス）
-- 例: 123.45.67.89

INSERT INTO anonymous_users (device_id, display_name, ip_address, is_admin)
VALUES ('admin_primary', '管理者', 'YOUR_IP_ADDRESS', true);
```

**注意**: `YOUR_IP_ADDRESS` を実際のIPアドレスに置き換えてください。

その後、アプリにアクセスして、デバイスIDを `admin_primary` に設定：

1. ブラウザのDevTools > Console を開く
2. 以下を実行：
```javascript
localStorage.setItem('device_id', 'admin_primary');
location.reload();
```

### 方法2: 通常ユーザーを管理者に昇格（推奨）

1. アプリに通常ユーザーとして登録
2. デバイスIDを取得（DevTools > Console）:
```javascript
console.log(localStorage.getItem('device_id'));
```
3. Supabase Dashboard > SQL Editor で実行：
```sql
UPDATE anonymous_users
SET is_admin = true
WHERE device_id = 'YOUR_DEVICE_ID';
```
4. アプリをリロード

## 2. 管理画面へのアクセス

管理者としてログイン後：

1. 画面右上に赤い盾アイコンが表示されます
2. 盾アイコンをタップして管理画面を開く

## 3. 管理機能の使い方

### ユーザーをブロック

1. 管理画面 > 「ユーザー」タブ
2. ブロックしたいユーザーの「禁止」ボタンをクリック
3. 確認ダイアログで「OK」

**効果**:
- そのユーザーのIPアドレスが即座にブロック
- 同じIPの全ユーザーがアクセス不可
- 再アクセスすると「ブロックされています」画面が表示

### IPブロックを解除

1. 管理画面 > 「ブロック」タブ
2. 解除したいIPの「✓」ボタンをクリック
3. 確認ダイアログで「OK」

### メッセージを削除

1. 管理画面 > 「メッセージ」タブ
2. 削除したいメッセージの「ゴミ箱」ボタンをクリック
3. 確認ダイアログで「OK」

**注意**: 削除されたメッセージは全ユーザーから見えなくなります（取り消し不可）

### ユーザーを管理者に昇格

1. 管理画面 > 「ユーザー」タブ
2. 昇格させたいユーザーの「+」ボタンをクリック
3. 確認ダイアログで「OK」

**効果**:
- そのユーザーに管理者権限が付与
- 次回ログイン時から管理画面にアクセス可能

### 監査ログの確認

1. 管理画面 > 「監査ログ」タブ
2. 全ての管理操作履歴が表示されます

**記録される操作**:
- IPブロック (block_ip)
- IPブロック解除 (unblock_ip)
- メッセージ削除 (delete_message)
- 管理者昇格 (promote_admin)

## 4. トラブルシューティング

### 管理画面が表示されない

**確認項目**:
1. データベースで `is_admin` が `true` か確認
```sql
SELECT * FROM anonymous_users WHERE device_id = 'YOUR_DEVICE_ID';
```

2. ブラウザのキャッシュをクリア

3. 再ログイン（localStorage をクリア）:
```javascript
localStorage.clear();
location.reload();
```

### 誤って自分をブロックした

**解決方法**:
1. VPNまたは別のネットワークから接続
2. Supabase Dashboard > SQL Editor で直接解除:
```sql
DELETE FROM ip_blocks WHERE ip_address = 'YOUR_IP_ADDRESS';
```

### 他の管理者を削除したい

```sql
UPDATE anonymous_users
SET is_admin = false
WHERE device_id = 'TARGET_DEVICE_ID';
```

## 5. セキュリティ推奨事項

### 管理者権限の管理

- 信頼できる人のみを管理者に昇格
- 定期的に監査ログを確認
- 不要になった管理者権限は即座に削除

### IPブロックの使用

- 明確な理由がある場合のみブロック
- 誤ブロックの可能性を考慮（共用IP、VPNなど）
- 定期的にブロックリストを見直し

### メッセージ削除

- 本当に不適切なメッセージのみ削除
- 削除理由を監査ログから追跡可能にする
- 削除は取り消せないことを認識

## 6. データベース直接操作

### 全ユーザーの確認

```sql
SELECT
  display_name,
  ip_address,
  is_admin,
  created_at,
  last_seen_at
FROM anonymous_users
ORDER BY last_seen_at DESC;
```

### 最近のメッセージを確認

```sql
SELECT
  m.content,
  u.display_name,
  m.ip_address,
  m.created_at
FROM messages m
JOIN anonymous_users u ON m.user_id = u.id
WHERE m.deleted_at IS NULL
ORDER BY m.created_at DESC
LIMIT 50;
```

### 監査ログの確認

```sql
SELECT
  al.action_type,
  admin.display_name as admin_name,
  al.target_ip,
  al.created_at,
  al.details
FROM audit_logs al
JOIN anonymous_users admin ON al.admin_id = admin.id
ORDER BY al.created_at DESC;
```

### IPブロックリストの確認

```sql
SELECT
  ib.ip_address,
  u.display_name as blocked_by,
  ib.reason,
  ib.created_at
FROM ip_blocks ib
JOIN anonymous_users u ON ib.blocked_by = u.id
ORDER BY ib.created_at DESC;
```

## 7. バックアップとメンテナンス

### データのバックアップ

Supabase Dashboardから定期的にバックアップを作成：
1. Database > Backups
2. "Manual backup"をクリック

### 古いデータの削除

メッセージが増えすぎた場合：

```sql
-- 30日以上前のメッセージを削除
DELETE FROM messages
WHERE created_at < NOW() - INTERVAL '30 days';

-- または削除フラグを立てる
UPDATE messages
SET deleted_at = NOW()
WHERE created_at < NOW() - INTERVAL '30 days';
```

監査ログの削除：

```sql
-- 90日以上前の監査ログを削除
DELETE FROM audit_logs
WHERE created_at < NOW() - INTERVAL '90 days';
```

## サポート

問題が発生した場合は、README.mdのトラブルシューティングセクションを確認してください。

/*
  # Fix IP Blocks RLS Policy

  ## Changes
  - Simplify the INSERT policy for ip_blocks table
  - The policy was too complex and causing failures
  - Since Edge Functions use service role key, RLS should be bypassed anyway
  - But we'll fix the policy to be more permissive for admin operations

  ## Security
  - Only authenticated admin users can insert IP blocks
  - Service role key bypasses RLS completely
*/

-- Drop and recreate the INSERT policy with a simpler check
DROP POLICY IF EXISTS "Admins can insert IP blocks" ON ip_blocks;

CREATE POLICY "Admins can insert IP blocks"
  ON ip_blocks FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users 
      WHERE anonymous_users.id = blocked_by 
      AND anonymous_users.is_admin = true
    )
  );

-- Also recreate DELETE policy to be consistent
DROP POLICY IF EXISTS "Admins can delete IP blocks" ON ip_blocks;

CREATE POLICY "Admins can delete IP blocks"
  ON ip_blocks FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users 
      WHERE anonymous_users.is_admin = true
    )
  );

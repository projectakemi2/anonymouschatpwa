/*
  # Add user visibility control

  1. Changes
    - Add `is_visible` column to `anonymous_users` table
      - Boolean field (default: false for non-admins, true for admins)
      - Controls whether user's messages are displayed
    
  2. Security
    - Only admins can update visibility status
    - Updated RLS policies to enforce admin-only updates
*/

-- Add is_visible column to anonymous_users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'anonymous_users' AND column_name = 'is_visible'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN is_visible BOOLEAN DEFAULT false;
  END IF;
END $$;

-- Set existing admin users to visible
UPDATE anonymous_users 
SET is_visible = true 
WHERE is_admin = true AND is_visible = false;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_anonymous_users_is_visible ON anonymous_users(is_visible);

-- Update RLS policy for anonymous_users table to allow admins to update visibility
DROP POLICY IF EXISTS "Users can update own data" ON anonymous_users;

CREATE POLICY "Users can update own data"
  ON anonymous_users
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id 
    OR EXISTS (
      SELECT 1 FROM anonymous_users 
      WHERE anonymous_users.id = auth.uid() 
      AND anonymous_users.is_admin = true
    )
  )
  WITH CHECK (
    auth.uid() = id 
    OR EXISTS (
      SELECT 1 FROM anonymous_users 
      WHERE anonymous_users.id = auth.uid() 
      AND anonymous_users.is_admin = true
    )
  );

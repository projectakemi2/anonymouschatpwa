/*
  # メッセージを退会後も保持する

  1. 変更内容
    - messagesテーブルのuser_idカラムをNULLABLEに変更
    - user_idの外部キー制約を`ON DELETE SET NULL`に変更
    - これにより、ユーザーが退会してもメッセージは削除されず、user_idがNULLになる

  2. セキュリティ
    - 既存のRLSポリシーは維持
    - 削除されたユーザーのメッセージも引き続き表示可能
*/

-- Drop existing foreign key constraint
ALTER TABLE messages
DROP CONSTRAINT IF EXISTS messages_user_id_fkey;

-- Make user_id nullable
ALTER TABLE messages
ALTER COLUMN user_id DROP NOT NULL;

-- Add foreign key constraint with ON DELETE SET NULL
ALTER TABLE messages
ADD CONSTRAINT messages_user_id_fkey
FOREIGN KEY (user_id)
REFERENCES anonymous_users(id)
ON DELETE SET NULL;
/*
  # デバイスフィンガープリントの追加

  1. 新規カラムの追加
    - `canvas_fingerprint` (text) - Canvas APIから生成されるユニークな値（ほぼ一意）
    - `webgl_fingerprint` (text) - WebGL情報から生成されるユニークな値
    - `screen_resolution` (text) - 画面解像度（例: "1920x1080"）
    - `color_depth` (text) - 色深度（例: "24"）
    - `timezone` (text) - タイムゾーン（例: "Asia/Tokyo"）
    - `languages` (text) - ブラウザ言語設定（例: "ja,en"）
    - `hardware_concurrency` (integer) - CPUコア数
    - `device_memory` (integer) - デバイスメモリ（GB）
    - `touch_support` (boolean) - タッチサポート有無
    - `device_fingerprint_hash` (text) - すべての情報を組み合わせたハッシュ値

  2. 目的
    - VPNやIPアドレス変更に関係なくデバイスを追跡
    - 同一デバイスからの複数アカウント作成を検出
    - より高精度なユーザー識別
*/

-- Add device fingerprint columns
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'canvas_fingerprint'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN canvas_fingerprint text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'webgl_fingerprint'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN webgl_fingerprint text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'screen_resolution'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN screen_resolution text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'color_depth'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN color_depth text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'timezone'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN timezone text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'languages'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN languages text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'hardware_concurrency'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN hardware_concurrency integer DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'device_memory'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN device_memory integer DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'touch_support'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN touch_support boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'device_fingerprint_hash'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN device_fingerprint_hash text DEFAULT '';
  END IF;
END $$;

-- Create indexes for fingerprint searches
CREATE INDEX IF NOT EXISTS idx_anonymous_users_canvas_fp ON anonymous_users(canvas_fingerprint);
CREATE INDEX IF NOT EXISTS idx_anonymous_users_webgl_fp ON anonymous_users(webgl_fingerprint);
CREATE INDEX IF NOT EXISTS idx_anonymous_users_device_fp_hash ON anonymous_users(device_fingerprint_hash);

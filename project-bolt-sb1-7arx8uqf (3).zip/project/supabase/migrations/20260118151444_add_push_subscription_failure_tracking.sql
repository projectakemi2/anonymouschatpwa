/*
  # プッシュ通知失敗トラッキング追加

  1. 変更内容
    - `push_subscriptions`テーブルに失敗カウントと履歴カラムを追加
    - `failure_count`: 連続失敗回数（デフォルト0）
    - `last_failure_at`: 最後に失敗した日時
    - `last_success_at`: 最後に成功した日時
  
  2. 目的
    - 一時的なエラーでサブスクリプションを削除しない
    - 5回連続失敗した場合のみ削除する仕組みに変更
    - サブスクリプションの健全性を追跡
*/

-- Add failure tracking columns to push_subscriptions table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'failure_count'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN failure_count integer DEFAULT 0 NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'last_failure_at'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN last_failure_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'last_success_at'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN last_success_at timestamptz;
  END IF;
END $$;

-- Create index for filtering out failed subscriptions
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_failure_count 
  ON push_subscriptions(failure_count);

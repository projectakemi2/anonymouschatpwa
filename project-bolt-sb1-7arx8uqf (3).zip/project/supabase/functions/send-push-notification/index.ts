import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import webpush from 'npm:web-push@3.6.7';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PushSubscription {
  id: string;
  user_id: string;
  endpoint: string;
  p256dh: string;
  auth: string;
  failure_count?: number;
  last_failure_at?: string;
  last_success_at?: string;
}

async function sendWebPush(
  subscription: PushSubscription,
  payload: any,
  vapidPublicKey: string,
  vapidPrivateKey: string
) {
  try {
    const pushSubscription = {
      endpoint: subscription.endpoint,
      keys: {
        p256dh: subscription.p256dh,
        auth: subscription.auth,
      },
    };

    webpush.setVapidDetails(
      'mailto:admin@aiprojectakemi2.com',
      vapidPublicKey,
      vapidPrivateKey
    );

    await webpush.sendNotification(
      pushSubscription,
      JSON.stringify(payload)
    );

    return { success: true, shouldDelete: false, shouldIncrementFailure: false };
  } catch (error: any) {
    console.error('Push notification error:', error);

    return { success: false, shouldDelete: false, shouldIncrementFailure: true };
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const vapidPublicKey = Deno.env.get('VAPID_PUBLIC_KEY') || 'BKyhAA-s_Lb4jQ4IsJugCLi0bE0oNR95PngSJnTfCwF0xs25v3czEhSKCbLGZktGFwmuGzy99HsaOX73KOWrVZI';
    const vapidPrivateKey = Deno.env.get('VAPID_PRIVATE_KEY') || '24BNMn0DkzABG1Q78ugR6k8XkvhFMhkmcuVHXgM4Ez0';

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { message_id, room_id, sender_id, sender_name, content } = await req.json();

    // Check if sender is visible
    const { data: senderData } = await supabase
      .from('anonymous_users')
      .select('is_visible')
      .eq('id', sender_id)
      .maybeSingle();

    // Only send notifications if sender is visible
    if (!senderData || senderData.is_visible !== true) {
      return new Response(
        JSON.stringify({ success: true, sent: 0, reason: 'sender_not_visible' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    const { data: subscriptions, error: subError } = await supabase
      .from('push_subscriptions')
      .select('*')
      .eq('room_id', room_id)
      .neq('user_id', sender_id);

    if (subError || !subscriptions || subscriptions.length === 0) {
      return new Response(
        JSON.stringify({ success: true, sent: 0 }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    const payload = {
      title: sender_name || '匿名ユーザー',
      body: content || '新しいメッセージがあります',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      message_id: message_id,
      room_id: room_id,
      url: `/#room=${room_id}`,
      data: {
        url: `/#room=${room_id}`,
        room_id: room_id,
        message_id: message_id,
      },
    };

    let sentCount = 0;
    const toDelete: string[] = [];
    const toUpdateSuccess: string[] = [];
    const toUpdateFailure: string[] = [];

    for (const sub of subscriptions) {
      const result = await sendWebPush(sub, payload, vapidPublicKey, vapidPrivateKey);

      if (result.success) {
        sentCount++;
        toUpdateSuccess.push(sub.id);
      } else if (result.shouldIncrementFailure) {
        const newFailureCount = (sub.failure_count || 0) + 1;

        if (newFailureCount >= 10) {
          console.log(`Deleting subscription ${sub.id} after ${newFailureCount} failures`);
          toDelete.push(sub.id);
        } else {
          console.log(`Incrementing failure count for subscription ${sub.id}: ${newFailureCount}`);
          toUpdateFailure.push(sub.id);
        }
      }
    }

    if (toUpdateSuccess.length > 0) {
      await supabase
        .from('push_subscriptions')
        .update({
          failure_count: 0,
          last_success_at: new Date().toISOString(),
        })
        .in('id', toUpdateSuccess);
    }

    if (toUpdateFailure.length > 0) {
      for (const subId of toUpdateFailure) {
        await supabase
          .from('push_subscriptions')
          .update({
            failure_count: supabase.raw('failure_count + 1'),
            last_failure_at: new Date().toISOString(),
          })
          .eq('id', subId);
      }
    }

    if (toDelete.length > 0) {
      await supabase
        .from('push_subscriptions')
        .delete()
        .in('id', toDelete);
    }

    return new Response(
      JSON.stringify({ success: true, sent: sentCount }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

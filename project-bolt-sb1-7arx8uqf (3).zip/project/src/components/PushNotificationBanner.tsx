import { Bell, X } from 'lucide-react';

interface PushNotificationBannerProps {
  onEnable: () => void;
  onDismiss: () => void;
}

export function PushNotificationBanner({ onEnable, onDismiss }: PushNotificationBannerProps) {
  return (
    <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 shadow-lg">
      <div className="max-w-4xl mx-auto flex items-center gap-4">
        <div className="flex-shrink-0">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <Bell className="w-6 h-6" />
          </div>
        </div>

        <div className="flex-1">
          <div className="font-semibold text-lg mb-1">
            プッシュ通知を許可しますか？
          </div>
          <div className="text-sm text-white/90">
            新着メッセージが届いたらすぐに通知します。ブラウザを閉じていても通知が届きます。
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onEnable}
            className="px-6 py-2 bg-white text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-colors shadow-md"
          >
            許可する
          </button>
          <button
            onClick={onDismiss}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
            aria-label="閉じる"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}

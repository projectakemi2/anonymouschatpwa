import { useState, useEffect } from 'react';
import { Bell, Check, Smartphone } from 'lucide-react';
import { subscribeToPushNotifications } from '../lib/push';
import { supabase } from '../lib/supabase';

interface TrackingLandingPageProps {
  campaignId: string;
}

export default function TrackingLandingPage({ campaignId }: TrackingLandingPageProps) {
  const [status, setStatus] = useState<'initial' | 'requesting' | 'subscribed' | 'denied'>('initial');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const autoSubscribe = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));

      setStatus('requesting');

      try {
        const permission = await Notification.requestPermission();

        if (permission === 'granted') {
          const subscription = await subscribeToPushNotifications();

          if (subscription) {
            await supabase
              .from('push_subscriptions')
              .update({
                campaign_id: campaignId,
                subscribed_at: new Date().toISOString()
              })
              .eq('id', subscription.id);

            setStatus('subscribed');
          } else {
            setError('通知の購読に失敗しました');
          }
        } else {
          setStatus('denied');
        }
      } catch (err) {
        console.error('Auto subscribe error:', err);
        setError('通知の設定中にエラーが発生しました');
      }
    };

    autoSubscribe();
  }, [campaignId]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center">
          {status === 'initial' || status === 'requesting' ? (
            <>
              <div className="inline-block p-6 bg-blue-100 rounded-full mb-6 animate-pulse">
                <Bell className="w-16 h-16 text-blue-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                通知を有効にしています...
              </h1>
              <p className="text-gray-600 mb-6">
                最新情報をお届けするため、通知を許可してください
              </p>
              <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                <Smartphone className="w-4 h-4" />
                <span>スマホでも受け取れます</span>
              </div>
            </>
          ) : status === 'subscribed' ? (
            <>
              <div className="inline-block p-6 bg-green-100 rounded-full mb-6">
                <Check className="w-16 h-16 text-green-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                登録完了！
              </h1>
              <p className="text-gray-600 mb-6">
                通知の受信設定が完了しました
              </p>
              <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                <p className="text-sm text-green-800">
                  📱 アプリを閉じていても通知が届きます
                  <br />
                  🔒 ロック画面でも表示されます
                  <br />
                  💤 スリープ中でも受信できます
                </p>
              </div>
            </>
          ) : (
            <>
              <div className="inline-block p-6 bg-yellow-100 rounded-full mb-6">
                <Bell className="w-16 h-16 text-yellow-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                通知がブロックされています
              </h1>
              <p className="text-gray-600 mb-6">
                ブラウザの設定で通知を許可してください
              </p>
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-left">
                <p className="text-sm text-yellow-800 mb-2 font-semibold">
                  設定方法：
                </p>
                <ol className="text-sm text-yellow-800 space-y-1 list-decimal list-inside">
                  <li>ブラウザのアドレスバーの鍵マークをタップ</li>
                  <li>「通知」を探してタップ</li>
                  <li>「許可」を選択</li>
                  <li>ページを再読み込み</li>
                </ol>
              </div>
            </>
          )}

          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-xl">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

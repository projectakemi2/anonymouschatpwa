import { supabase } from './supabase';
import { getClientIP } from './device';

const ADMIN_PASSWORD = 'admin123';

async function callAdminFunction(action: string, adminId: string, params: any): Promise<void> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-operations`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      action,
      password: ADMIN_PASSWORD,
      adminId,
      ...params
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Operation failed');
  }

  return response.json();
}

export async function blockUserByIP(
  ipAddress: string,
  adminId: string,
  reason: string = ''
): Promise<void> {
  await callAdminFunction('block_ip', adminId, { ipAddress, reason });
}

export async function unblockIP(ipAddress: string, adminId: string): Promise<void> {
  await callAdminFunction('unblock_ip', adminId, { ipAddress });
}

export async function promoteToAdmin(userId: string, adminId: string): Promise<void> {
  await callAdminFunction('promote_admin', adminId, { userId });
}

export async function blockUserByDeviceId(
  deviceId: string,
  adminId: string,
  reason: string = ''
): Promise<void> {
  await callAdminFunction('block_device', adminId, { deviceId, reason });
}

export async function unblockDevice(deviceId: string, adminId: string): Promise<void> {
  await callAdminFunction('unblock_device', adminId, { deviceId });
}

export async function blockByDisplayName(
  displayName: string,
  adminId: string,
  reason: string = ''
): Promise<{ blockedCount: number; totalFound: number; message: string }> {
  return await callAdminFunction('block_by_name', adminId, { displayName, reason });
}

export async function getDeviceBlocks(): Promise<any[]> {
  const { data, error } = await supabase
    .from('device_blocks')
    .select('id, device_id, blocked_by, reason, created_at')
    .order('created_at', { ascending: false });

  if (error) throw error;

  if (!data || data.length === 0) {
    return [];
  }

  const blockerIds = [...new Set(data.map(block => block.blocked_by))];

  const { data: blockers } = await supabase
    .from('anonymous_users')
    .select('id, display_name')
    .in('id', blockerIds);

  const blockerMap = new Map(
    (blockers || []).map(user => [user.id, user.display_name])
  );

  return data.map(block => ({
    ...block,
    blocker: { display_name: blockerMap.get(block.blocked_by) || '不明' }
  }));
}

export async function getIPBlocks(): Promise<any[]> {
  const { data, error } = await supabase
    .from('ip_blocks')
    .select('id, ip_address, blocked_by, reason, created_at')
    .order('created_at', { ascending: false });

  if (error) throw error;

  if (!data || data.length === 0) {
    return [];
  }

  const blockerIds = [...new Set(data.map(block => block.blocked_by))];

  const { data: blockers } = await supabase
    .from('anonymous_users')
    .select('id, display_name')
    .in('id', blockerIds);

  const blockerMap = new Map(
    (blockers || []).map(user => [user.id, user.display_name])
  );

  return data.map(block => ({
    ...block,
    blocker: { display_name: blockerMap.get(block.blocked_by) || '不明' }
  }));
}

export async function getAuditLogs(limit = 100): Promise<any[]> {
  const { data, error } = await supabase
    .from('audit_logs')
    .select('id, admin_id, action_type, target_user_id, target_ip, details, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;

  if (!data || data.length === 0) {
    return [];
  }

  const adminIds = [...new Set(data.map(log => log.admin_id))];

  const { data: admins } = await supabase
    .from('anonymous_users')
    .select('id, display_name')
    .in('id', adminIds);

  const adminMap = new Map(
    (admins || []).map(user => [user.id, user.display_name])
  );

  return data.map(log => ({
    ...log,
    admin: { display_name: adminMap.get(log.admin_id) || '不明' }
  }));
}

export async function getUserByIP(ipAddress: string): Promise<any[]> {
  const { data, error } = await supabase
    .from('anonymous_users')
    .select('*')
    .eq('ip_address', ipAddress);

  if (error) throw error;
  return data || [];
}

export async function getAllUsers(roomId?: string): Promise<any[]> {
  let allUsers: any[] = [];
  let from = 0;
  const pageSize = 1000;
  let hasMore = true;

  while (hasMore) {
    const { data, error } = await supabase
      .from('anonymous_users')
      .select('*')
      .order('last_seen_at', { ascending: false })
      .range(from, from + pageSize - 1);

    if (error) {
      console.error('getAllUsers error:', error);
      throw error;
    }

    if (data && data.length > 0) {
      allUsers = [...allUsers, ...data];
      from += pageSize;

      if (data.length < pageSize) {
        hasMore = false;
      }
    } else {
      hasMore = false;
    }
  }

  console.log(`getAllUsers: 取得したユーザー数 ${allUsers.length}件`);
  return allUsers;
}

export async function cleanupOldAuditLogs(): Promise<{ deleted: number }> {
  const { error } = await supabase.rpc('cleanup_old_audit_logs');

  if (error) throw error;

  return { deleted: 0 };
}

export async function cleanupOldRateLimits(): Promise<{ deleted: number }> {
  const { error } = await supabase.rpc('cleanup_old_rate_limits');

  if (error) throw error;

  return { deleted: 0 };
}

export async function blockDisplayName(
  displayName: string,
  adminId: string,
  reason: string = ''
): Promise<void> {
  await callAdminFunction('block_display_name', adminId, { displayName, reason });
}

export async function unblockDisplayName(displayName: string, adminId: string): Promise<void> {
  await callAdminFunction('unblock_display_name', adminId, { displayName });
}

export async function getBlockedDisplayNames(): Promise<any[]> {
  const { data, error } = await supabase
    .from('blocked_display_names')
    .select('id, display_name, blocked_by, reason, created_at')
    .order('created_at', { ascending: false });

  if (error) throw error;

  if (!data || data.length === 0) {
    return [];
  }

  const blockerIds = [...new Set(data.map(block => block.blocked_by))];

  const { data: blockers } = await supabase
    .from('anonymous_users')
    .select('id, display_name')
    .in('id', blockerIds);

  const blockerMap = new Map(
    (blockers || []).map(user => [user.id, user.display_name])
  );

  return data.map(block => ({
    ...block,
    blocker: { display_name: blockerMap.get(block.blocked_by) || '不明' }
  }));
}

export async function checkDisplayNameBlocked(displayName: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('blocked_display_names')
    .select('id')
    .eq('display_name', displayName)
    .maybeSingle();

  if (error) throw error;

  return !!data;
}

export async function toggleUserVisibility(userId: string, isVisible: boolean): Promise<void> {
  const { error } = await supabase
    .from('anonymous_users')
    .update({ is_visible: isVisible })
    .eq('id', userId);

  if (error) throw error;
}

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerServiceWorker } from './lib/notification';

let deferredPrompt: any = null;

console.log('Setting up beforeinstallprompt listener...');

const isIOS = () => {
  const userAgent = window.navigator.userAgent.toLowerCase();
  return /iphone|ipad|ipod/.test(userAgent);
};

const isAndroid = () => {
  const userAgent = window.navigator.userAgent.toLowerCase();
  return /android/.test(userAgent);
};

window.addEventListener('beforeinstallprompt', (e) => {
  console.log('beforeinstallprompt event fired!', e);
  e.preventDefault();
  deferredPrompt = e;
  (window as any).deferredPrompt = e;

  if (isIOS()) {
    console.log('Deferred prompt saved (iOS):', deferredPrompt);
    window.dispatchEvent(new CustomEvent('pwainstallable'));
  } else if (isAndroid()) {
    console.log('Deferred prompt saved (Android):', deferredPrompt);
    window.dispatchEvent(new CustomEvent('pwainstallable'));
  } else {
    console.log('Deferred prompt saved:', deferredPrompt);
  }
});

window.addEventListener('appinstalled', () => {
  console.log('PWA was installed successfully!');
  deferredPrompt = null;
  (window as any).deferredPrompt = null;
});

registerServiceWorker().then(() => {
  console.log('Service Worker registered successfully');
}).catch((err) => {
  console.error('Service Worker registration failed:', err);
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

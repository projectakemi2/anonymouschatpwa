/*
  # Add Direct Messages (DM) System

  1. New Tables
    - `direct_messages`
      - `id` (uuid, primary key) - Unique identifier for each message
      - `sender_id` (uuid) - References anonymous_users.id (the sender)
      - `recipient_id` (uuid) - References anonymous_users.id (the recipient)
      - `content` (text) - The message content
      - `is_read` (boolean) - Read status flag, defaults to false
      - `room_id` (text) - Room context for the DM
      - `created_at` (timestamptz) - Message creation timestamp

  2. Security
    - Enable RLS on `direct_messages` table
    - Anyone can read direct messages (filtering done client-side by user_id)
    - Anyone can send direct messages
    - Anyone can update messages (client enforces recipient check)
    - Messages are deleted when either user is deleted (CASCADE)

  3. Indexes
    - Index on sender_id for faster sender queries
    - Index on recipient_id for faster recipient queries
    - Index on is_read for unread message counts
    - Composite index on recipient_id + is_read for unread inbox queries
    - Index on created_at for chronological ordering

  4. Realtime
    - Enable realtime updates for instant message delivery
*/

-- Create direct_messages table
CREATE TABLE IF NOT EXISTS direct_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (char_length(content) <= 10000),
  is_read boolean DEFAULT false NOT NULL,
  room_id text,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE direct_messages ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Anyone can read direct messages
-- (Client-side filtering by sender_id/recipient_id ensures privacy)
CREATE POLICY "Anyone can read direct messages"
  ON direct_messages
  FOR SELECT
  USING (true);

-- RLS Policy: Anyone can send direct messages
CREATE POLICY "Anyone can send direct messages"
  ON direct_messages
  FOR INSERT
  WITH CHECK (true);

-- RLS Policy: Anyone can update direct messages
-- (Client-side enforcement ensures only recipients update read status)
CREATE POLICY "Anyone can update direct messages"
  ON direct_messages
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- RLS Policy: Anyone can delete their own messages (for future feature)
CREATE POLICY "Anyone can delete direct messages"
  ON direct_messages
  FOR DELETE
  USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_direct_messages_sender ON direct_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_direct_messages_recipient ON direct_messages(recipient_id);
CREATE INDEX IF NOT EXISTS idx_direct_messages_is_read ON direct_messages(is_read);
CREATE INDEX IF NOT EXISTS idx_direct_messages_recipient_unread ON direct_messages(recipient_id, is_read) WHERE is_read = false;
CREATE INDEX IF NOT EXISTS idx_direct_messages_created_at ON direct_messages(created_at DESC);

-- Enable Realtime for instant message delivery
ALTER PUBLICATION supabase_realtime ADD TABLE direct_messages;
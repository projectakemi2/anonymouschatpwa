/*
  # Add Fallback Notification System

  ## Overview
  Creates an in-app notification system as a fallback when push notifications fail.
  Professional sites use multiple notification channels to ensure critical messages reach users.

  ## Changes Made

  1. **New Table: in_app_notifications**
     - Stores fallback notifications that failed to send via push
     - Can be displayed as banners, badges, or in notification center
     - Tracks read/unread status for user experience

  2. **Features**
     - Automatic fallback when push fails
     - Read/unread tracking
     - Expiration for old notifications
     - Links to original campaign for analytics

  3. **Security**
     - RLS policies ensure users only see their own notifications
     - Service role can create notifications for any user

  ## Important Notes
  - Fallback notifications are created automatically when push fails
  - Old notifications are auto-expired after 30 days
  - Frontend can poll or subscribe to realtime updates
*/

CREATE TABLE IF NOT EXISTS in_app_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text NOT NULL,
  url text,
  icon text DEFAULT '/icon-192.png',
  campaign_id text,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT (now() + interval '30 days'),
  metadata jsonb DEFAULT '{}'::jsonb
);

ALTER TABLE in_app_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own notifications"
  ON in_app_notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications"
  ON in_app_notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Service role can manage all notifications"
  ON in_app_notifications FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_in_app_notifications_user_unread 
  ON in_app_notifications(user_id, is_read, created_at DESC) 
  WHERE is_read = false;

CREATE INDEX IF NOT EXISTS idx_in_app_notifications_expires 
  ON in_app_notifications(expires_at);

CREATE OR REPLACE FUNCTION cleanup_expired_notifications()
RETURNS void AS $$
BEGIN
  DELETE FROM in_app_notifications
  WHERE expires_at < now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
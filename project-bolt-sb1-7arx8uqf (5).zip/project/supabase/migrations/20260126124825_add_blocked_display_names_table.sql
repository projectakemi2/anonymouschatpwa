/*
  # 名前ブロックリストテーブルの追加

  1. 新しいテーブル
    - `blocked_display_names`
      - `id` (uuid, primary key)
      - `display_name` (text, unique) - ブロックする名前
      - `blocked_by` (uuid) - ブロックした管理者
      - `reason` (text) - ブロック理由
      - `created_at` (timestamptz)

  2. セキュリティ
    - RLSを有効化
    - 全員が読み取り可能（登録時のチェックのため）
    - 管理者のみ追加・削除可能

  3. インデックス
    - display_name に一意制約とインデックス
*/

CREATE TABLE IF NOT EXISTS blocked_display_names (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name text UNIQUE NOT NULL,
  blocked_by uuid NOT NULL REFERENCES anonymous_users(id),
  reason text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- インデックスを追加
CREATE INDEX IF NOT EXISTS idx_blocked_display_names_display_name 
  ON blocked_display_names(display_name);

-- RLSを有効化
ALTER TABLE blocked_display_names ENABLE ROW LEVEL SECURITY;

-- 全員が読み取り可能（登録時のチェックのため）
CREATE POLICY "Anyone can read blocked display names"
  ON blocked_display_names
  FOR SELECT
  USING (true);

-- 管理者のみ追加可能
CREATE POLICY "Admins can insert blocked display names"
  ON blocked_display_names
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE id = blocked_by AND is_admin = true
    )
  );

-- 管理者のみ削除可能
CREATE POLICY "Admins can delete blocked display names"
  ON blocked_display_names
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE is_admin = true
    )
  );

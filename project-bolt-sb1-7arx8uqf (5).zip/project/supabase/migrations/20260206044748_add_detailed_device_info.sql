/*
  # ユーザーの詳細なデバイス情報を保存

  1. Changes
    - `anonymous_users`テーブルに以下のカラムを追加：
      - `user_agent` (text) - 完全なUserAgent文字列
      - `platform` (text) - OS種類（iOS, Android, Windows, macOS, Linux）
      - `os_version` (text) - OSバージョン
      - `browser` (text) - ブラウザ名（Chrome, Safari, Firefox, Edge）
      - `browser_version` (text) - ブラウザバージョン
      - `is_pwa` (boolean) - PWAとしてインストール済みか

  2. Purpose
    - VPNユーザーや悪意のあるユーザーの特定に役立つ
    - デバイスフィンガープリントの強化
    - より正確なユーザー追跡
*/

-- Add device info columns to anonymous_users table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'user_agent'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN user_agent text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'platform'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN platform text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'os_version'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN os_version text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'browser'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN browser text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'browser_version'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN browser_version text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'anonymous_users' AND column_name = 'is_pwa'
  ) THEN
    ALTER TABLE anonymous_users ADD COLUMN is_pwa boolean DEFAULT false;
  END IF;
END $$;

-- Create index for user_agent searches
CREATE INDEX IF NOT EXISTS idx_anonymous_users_user_agent ON anonymous_users(user_agent);
CREATE INDEX IF NOT EXISTS idx_anonymous_users_platform ON anonymous_users(platform);
CREATE INDEX IF NOT EXISTS idx_anonymous_users_browser ON anonymous_users(browser);
/*
  # Fix deleted_by foreign key constraint

  1. Changes
    - Drop existing foreign key constraint on messages.deleted_by
    - Re-add foreign key constraint with ON DELETE SET NULL
    - This allows admins to delete their accounts without constraint errors

  2. Security
    - No RLS changes needed
    - Maintains data integrity while allowing user deletion
*/

-- Drop existing foreign key constraint
ALTER TABLE messages 
DROP CONSTRAINT IF EXISTS messages_deleted_by_fkey;

-- Re-add foreign key constraint with ON DELETE SET NULL
ALTER TABLE messages
ADD CONSTRAINT messages_deleted_by_fkey 
FOREIGN KEY (deleted_by) 
REFERENCES anonymous_users(id) 
ON DELETE SET NULL;
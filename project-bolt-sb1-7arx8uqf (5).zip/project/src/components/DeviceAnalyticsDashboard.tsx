import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface Analytics {
  id: string;
  device_id: string;
  platform: string;
  browser: string;
  browser_version: string;
  os_version: string;
  is_standalone: boolean;
  is_installable: boolean;
  install_button_shown: boolean;
  install_attempted: boolean;
  install_succeeded: boolean;
  event_type: string;
  error_message: string;
  created_at: string;
}

export default function DeviceAnalyticsDashboard() {
  const [analytics, setAnalytics] = useState<Analytics[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    const { data } = await supabase
      .from('device_analytics')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      setAnalytics(data);
    }
    setLoading(false);
  };

  if (loading) {
    return <div className="p-8 text-center">読み込み中...</div>;
  }

  const groupByDevice = analytics.reduce((acc, item) => {
    if (!acc[item.device_id]) {
      acc[item.device_id] = [];
    }
    acc[item.device_id].push(item);
    return acc;
  }, {} as Record<string, Analytics[]>);

  const problemDevices = Object.entries(groupByDevice).filter(([_, events]) => {
    const hasInstallAttempt = events.some(e => e.install_attempted);
    const hasManualInstructions = events.some(e => e.event_type === 'manual_install_instructions_shown');
    const noInstallPrompt = events.every(e => !e.is_installable);

    return hasInstallAttempt && (hasManualInstructions || noInstallPrompt);
  });

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">デバイス分析ダッシュボード</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-blue-100 p-6 rounded-lg">
          <div className="text-2xl font-bold text-blue-900">{Object.keys(groupByDevice).length}</div>
          <div className="text-sm text-blue-700">総デバイス数</div>
        </div>

        <div className="bg-red-100 p-6 rounded-lg">
          <div className="text-2xl font-bold text-red-900">{problemDevices.length}</div>
          <div className="text-sm text-red-700">問題のあるデバイス</div>
        </div>

        <div className="bg-green-100 p-6 rounded-lg">
          <div className="text-2xl font-bold text-green-900">
            {analytics.filter(a => a.install_succeeded).length}
          </div>
          <div className="text-sm text-green-700">インストール成功</div>
        </div>
      </div>

      <h2 className="text-2xl font-bold mb-4 text-red-600">問題のあるデバイス</h2>

      {problemDevices.length === 0 ? (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-8">
          問題のあるデバイスはありません
        </div>
      ) : (
        <div className="space-y-4 mb-8">
          {problemDevices.map(([deviceId, events]) => {
            const latest = events[0];
            return (
              <div key={deviceId} className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="font-bold text-red-900 mb-2">
                  {latest.platform} {latest.os_version} - {latest.browser} {latest.browser_version}
                </div>
                <div className="text-sm space-y-1">
                  <div>デバイスID: {deviceId}</div>
                  <div>インストール可能: {events.some(e => e.is_installable) ? '✓' : '✗'}</div>
                  <div>ボタン表示: {events.some(e => e.install_button_shown) ? '✓' : '✗'}</div>
                  <div>インストール試行: {events.some(e => e.install_attempted) ? '✓' : '✗'}</div>
                  <div>成功: {events.some(e => e.install_succeeded) ? '✓' : '✗'}</div>
                  {events.some(e => e.error_message) && (
                    <div className="text-red-600 mt-2">
                      エラー: {events.find(e => e.error_message)?.error_message}
                    </div>
                  )}
                  <details className="mt-2">
                    <summary className="cursor-pointer text-blue-600">イベント履歴を表示</summary>
                    <div className="mt-2 space-y-1 text-xs">
                      {events.map(e => (
                        <div key={e.id} className="border-l-2 border-gray-300 pl-2">
                          {new Date(e.created_at).toLocaleString('ja-JP')}: {e.event_type}
                        </div>
                      ))}
                    </div>
                  </details>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <h2 className="text-2xl font-bold mb-4">全イベント履歴</h2>
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <table className="min-w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-2 text-left text-xs">時刻</th>
              <th className="px-4 py-2 text-left text-xs">プラットフォーム</th>
              <th className="px-4 py-2 text-left text-xs">ブラウザ</th>
              <th className="px-4 py-2 text-left text-xs">イベント</th>
              <th className="px-4 py-2 text-left text-xs">状態</th>
            </tr>
          </thead>
          <tbody>
            {analytics.slice(0, 50).map(item => (
              <tr key={item.id} className="border-t">
                <td className="px-4 py-2 text-xs">
                  {new Date(item.created_at).toLocaleString('ja-JP')}
                </td>
                <td className="px-4 py-2 text-xs">
                  {item.platform} {item.os_version}
                </td>
                <td className="px-4 py-2 text-xs">
                  {item.browser} {item.browser_version}
                </td>
                <td className="px-4 py-2 text-xs">{item.event_type}</td>
                <td className="px-4 py-2 text-xs">
                  <span className={`px-2 py-1 rounded ${
                    item.is_installable ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {item.is_installable ? 'インストール可能' : 'インストール不可'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

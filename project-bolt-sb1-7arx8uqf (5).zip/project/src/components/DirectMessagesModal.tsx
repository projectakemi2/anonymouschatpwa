import { useState, useEffect, useRef } from 'react';
import { X, Send, ArrowLeft } from 'lucide-react';
import {
  DirectMessage,
  DMThread,
  getDMThreads,
  getDirectMessages,
  sendDirectMessage,
  markThreadAsRead,
  getAdminUsers,
  subscribeToDirectMessages,
} from '../lib/direct-messages';

interface DirectMessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserId: string;
  currentUserName: string;
  isAdmin: boolean;
  roomId: string | null;
}

export function DirectMessagesModal({
  isOpen,
  onClose,
  currentUserId,
  currentUserName,
  isAdmin,
  roomId,
}: DirectMessagesModalProps) {
  const [view, setView] = useState<'threads' | 'chat'>('threads');
  const [threads, setThreads] = useState<DMThread[]>([]);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [selectedThread, setSelectedThread] = useState<DMThread | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [adminUsers, setAdminUsers] = useState<Array<{ id: string; display_name: string }>>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      loadThreads();
      if (!isAdmin) {
        loadAdminUsers();
      }
    }
  }, [isOpen, currentUserId]);

  useEffect(() => {
    if (!isOpen) return;

    const channel = subscribeToDirectMessages(currentUserId, (newMsg) => {
      if (selectedThread &&
          (newMsg.sender_id === selectedThread.user_id || newMsg.recipient_id === selectedThread.user_id)) {
        setMessages(prev => [...prev, newMsg]);
        markThreadAsRead(currentUserId, selectedThread.user_id);
      }
      loadThreads();
    });

    return () => {
      channel.unsubscribe();
    };
  }, [isOpen, currentUserId, selectedThread]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadThreads = async () => {
    const data = await getDMThreads(currentUserId);
    setThreads(data);
  };

  const loadAdminUsers = async () => {
    const data = await getAdminUsers();
    setAdminUsers(data);
  };

  const openThread = async (thread: DMThread) => {
    setSelectedThread(thread);
    const msgs = await getDirectMessages(currentUserId, thread.user_id);
    setMessages(msgs);
    setView('chat');
    await markThreadAsRead(currentUserId, thread.user_id);
    await loadThreads();
  };

  const startNewThreadWithAdmin = async (adminId: string, adminName: string) => {
    const thread: DMThread = {
      user_id: adminId,
      user_name: adminName,
      is_admin: true,
      last_message: '',
      last_message_at: new Date().toISOString(),
      unread_count: 0,
    };
    setSelectedThread(thread);
    const msgs = await getDirectMessages(currentUserId, adminId);
    setMessages(msgs);
    setView('chat');
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedThread) return;

    const message = await sendDirectMessage(
      currentUserId,
      selectedThread.user_id,
      newMessage.trim(),
      roomId
    );

    if (message) {
      setMessages(prev => [...prev, message]);
      setNewMessage('');
      await loadThreads();
    }
  };

  const backToThreads = () => {
    setView('threads');
    setSelectedThread(null);
    setMessages([]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          {view === 'chat' && (
            <button
              onClick={backToThreads}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-xl font-bold flex-1">
            {view === 'threads' ? 'ダイレクトメッセージ' : selectedThread?.user_name}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {view === 'threads' ? (
          <div className="flex-1 overflow-y-auto">
            {!isAdmin && adminUsers.length > 0 && (
              <div className="p-4 border-b bg-gray-50">
                <h3 className="text-sm font-semibold text-gray-700 mb-2">管理者に連絡</h3>
                <div className="space-y-2">
                  {adminUsers.map((admin) => (
                    <button
                      key={admin.id}
                      onClick={() => startNewThreadWithAdmin(admin.id, admin.display_name)}
                      className="w-full text-left p-3 bg-white hover:bg-blue-50 rounded-lg transition-colors border border-gray-200"
                    >
                      <div className="font-medium text-blue-600">{admin.display_name}</div>
                      <div className="text-sm text-gray-500">新しいメッセージを送信</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {threads.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <p>メッセージはありません</p>
                {!isAdmin && adminUsers.length > 0 && (
                  <p className="mt-2 text-sm">上の管理者から選択してメッセージを送信できます</p>
                )}
              </div>
            ) : (
              <div className="divide-y">
                {threads.map((thread) => (
                  <button
                    key={thread.user_id}
                    onClick={() => openThread(thread)}
                    className="w-full text-left p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{thread.user_name}</span>
                          {thread.is_admin && (
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">
                              管理者
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 truncate mt-1">{thread.last_message}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(thread.last_message_at).toLocaleString('ja-JP')}
                        </p>
                      </div>
                      {thread.unread_count > 0 && (
                        <span className="ml-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                          {thread.unread_count}
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <p>メッセージを送信して会話を始めましょう</p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isOwnMessage = msg.sender_id === currentUserId;
                  return (
                    <div
                      key={msg.id}
                      className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg p-3 ${
                          isOwnMessage
                            ? 'bg-blue-500 text-white'
                            : 'bg-white border border-gray-200'
                        }`}
                      >
                        <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                        <p
                          className={`text-xs mt-1 ${
                            isOwnMessage ? 'text-blue-100' : 'text-gray-400'
                          }`}
                        >
                          {new Date(msg.created_at).toLocaleTimeString('ja-JP', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="p-4 border-t bg-white">
              <div className="flex gap-2 items-center">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="メッセージを入力..."
                  className="flex-1 min-w-0 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  maxLength={10000}
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim()}
                  className="flex-shrink-0 p-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  title="送信"
                >
                  <Send className="w-5 h-5" />
                  <span className="hidden sm:inline">送信</span>
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

import { MessageCircle, Shield, Users, Lock, CheckCircle } from 'lucide-react';
import { useState, useEffect } from 'react';

interface LandingPageProps {
  onContinue: () => void;
}

export default function LandingPage({ onContinue }: LandingPageProps) {
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onContinue();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [onContinue]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-500 p-8 text-white text-center">
              <div className="inline-block p-4 bg-white/20 rounded-full mb-4">
                <MessageCircle className="w-16 h-16" />
              </div>
              <h1 className="text-4xl font-bold mb-2">参加者オープンチャット</h1>
              <p className="text-xl text-blue-100">安全で信頼できるチャットアプリケーション</p>
            </div>

            <div className="p-8">
              <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-6 mb-8 flex items-start gap-4">
                <Shield className="w-8 h-8 text-green-600 flex-shrink-0" />
                <div>
                  <h2 className="text-xl font-bold text-green-900 mb-2">
                    このサイトは安全です
                  </h2>
                  <p className="text-green-800">
                    参加者オープンチャットは、オープンソースのプログレッシブウェブアプリケーション（PWA）です。
                    個人情報の収集は最小限で、匿名でチャットを楽しめます。
                  </p>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-6 bg-blue-50 rounded-2xl">
                  <div className="inline-block p-3 bg-blue-100 rounded-full mb-3">
                    <Users className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">匿名参加</h3>
                  <p className="text-sm text-gray-600">
                    ログイン不要で簡単にチャットに参加できます
                  </p>
                </div>

                <div className="text-center p-6 bg-blue-50 rounded-2xl">
                  <div className="inline-block p-3 bg-blue-100 rounded-full mb-3">
                    <Lock className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">プライバシー保護</h3>
                  <p className="text-sm text-gray-600">
                    個人情報の収集は最小限、データは暗号化されています
                  </p>
                </div>

                <div className="text-center p-6 bg-blue-50 rounded-2xl">
                  <div className="inline-block p-3 bg-blue-100 rounded-full mb-3">
                    <CheckCircle className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">安全性</h3>
                  <p className="text-sm text-gray-600">
                    セキュリティヘッダーとRLSで保護されています
                  </p>
                </div>
              </div>

              <div className="bg-gray-50 rounded-2xl p-6 mb-6">
                <h3 className="font-bold text-gray-900 mb-3">技術仕様</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>PWA（Progressive Web App）技術を採用</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>Supabaseによる安全なデータベース管理</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>Row Level Security（RLS）による厳格なアクセス制御</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>CSP、XSS対策などのセキュリティヘッダー実装</span>
                  </li>
                </ul>
              </div>

              <div className="text-center">
                <button
                  onClick={onContinue}
                  className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-colors shadow-lg"
                >
                  チャットに進む ({countdown}秒)
                </button>
                <p className="text-sm text-gray-500 mt-4">
                  自動的にチャットページに移動します
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center text-sm text-gray-600">
            <p>このアプリケーションはオープンソースプロジェクトです</p>
            <p className="mt-2">
              セキュリティに関する懸念がある場合は、
              <a href="/.well-known/security.txt" className="text-blue-600 hover:underline ml-1">
                セキュリティポリシー
              </a>
              をご確認ください
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

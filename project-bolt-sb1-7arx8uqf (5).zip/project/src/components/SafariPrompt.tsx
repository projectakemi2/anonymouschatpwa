import { Compass } from 'lucide-react';

export default function SafariPrompt() {
  const handleOpenInSafari = () => {
    const currentUrl = window.location.href;
    const message = `このアプリを使用するには、Safariで開く必要があります。\n\n手順:\n1. この画面の右上または下部のメニュー（···）をタップ\n2. 「Safariで開く」または「デフォルトのブラウザで開く」を選択\n3. Safariで開いたら、再度アクセスしてください\n\nURL: ${currentUrl}`;

    alert(message);

    const safariUrl = currentUrl.replace(/^https?:\/\//, 'x-safari-https://');
    setTimeout(() => {
      window.location.href = safariUrl;
    }, 100);
  };

  const copyUrl = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      alert('URLをコピーしました！Safariを開いて、アドレスバーに貼り付けてください。');
    }).catch(() => {
      alert(`このURLをコピーして、Safariで開いてください:\n\n${url}`);
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-6">
          <div className="inline-block p-6 bg-blue-100 rounded-full mb-4">
            <Compass className="w-16 h-16 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Safariで開いてください
          </h1>
          <p className="text-gray-600 text-lg">
            このアプリはiPhoneの<span className="font-bold text-blue-600">Safari</span>でのみ動作します
          </p>
        </div>

        <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6 mb-6">
          <h2 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">1</span>
            メニューを開く
          </h2>
          <p className="text-gray-700 mb-4 ml-8">
            画面の右上または下部にある<span className="font-bold">メニューボタン（···）</span>をタップ
          </p>

          <h2 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">2</span>
            Safariで開く
          </h2>
          <p className="text-gray-700 mb-4 ml-8">
            <span className="font-bold">「Safariで開く」</span>または<span className="font-bold">「デフォルトのブラウザで開く」</span>を選択
          </p>

          <h2 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">3</span>
            再度アクセス
          </h2>
          <p className="text-gray-700 ml-8">
            Safariで開いたら、そのままアプリをご利用いただけます
          </p>
        </div>

        <div className="space-y-3">
          <button
            onClick={handleOpenInSafari}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold py-4 px-6 rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            Safariで開く
          </button>

          <button
            onClick={copyUrl}
            className="w-full bg-gray-100 text-gray-700 font-bold py-4 px-6 rounded-xl hover:bg-gray-200 transition-all duration-200"
          >
            URLをコピー
          </button>
        </div>

        <p className="text-sm text-gray-500 text-center mt-6">
          ※ Androidをご利用の場合は、そのままご利用いただけます
        </p>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Plus, Copy, Check, MessageCircle, ArrowLeft, LogIn, Settings } from 'lucide-react';
import { getAllRooms, createRoom, getRoomURL, Room, URLFormat, getFormatLabel } from '../lib/room';
import { AnonymousUser } from '../lib/user';

interface RoomListProps {
  currentUser: AnonymousUser;
  onClose: () => void;
}

export default function RoomList({ currentUser, onClose }: RoomListProps) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [copiedRoomId, setCopiedRoomId] = useState<string | null>(null);
  const [roomCode, setRoomCode] = useState('');
  const [urlFormat, setUrlFormat] = useState<URLFormat>('query');
  const [showFormatSelector, setShowFormatSelector] = useState(false);

  useEffect(() => {
    loadRooms();
  }, []);

  const loadRooms = async () => {
    try {
      const data = await getAllRooms();
      setRooms(data);
    } catch (err) {
      console.error('Failed to load rooms:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim()) return;

    setCreating(true);
    try {
      const room = await createRoom(newRoomName, currentUser.id);
      setRooms([room, ...rooms]);
      setNewRoomName('');

      const url = getRoomURL(room.id, urlFormat);
      await navigator.clipboard.writeText(url);
      setCopiedRoomId(room.id);
      setTimeout(() => setCopiedRoomId(null), 3000);
    } catch (err: any) {
      alert('ルームの作成に失敗しました: ' + err.message);
    } finally {
      setCreating(false);
    }
  };

  const handleCopyUrl = async (roomId: string) => {
    try {
      const url = getRoomURL(roomId, urlFormat);
      await navigator.clipboard.writeText(url);
      setCopiedRoomId(roomId);
      setTimeout(() => setCopiedRoomId(null), 2000);
    } catch (err) {
      alert('URLのコピーに失敗しました');
    }
  };

  const handleCopyDefaultRoom = async () => {
    try {
      const url = getRoomURL('default', urlFormat);
      await navigator.clipboard.writeText(url);
      setCopiedRoomId('default');
      setTimeout(() => setCopiedRoomId(null), 2000);
    } catch (err: any) {
      alert('URLのコピーに失敗しました: ' + err.message);
    }
  };

  const handleJoinByCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomCode.trim()) return;
    window.location.hash = roomCode.trim();
    window.location.reload();
  };

  const handleJoinRoom = (roomId: string) => {
    window.location.href = getRoomURL(roomId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white">
            <div className="flex items-center justify-between mb-2">
              <h1 className="text-3xl font-bold">チャットルーム</h1>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowFormatSelector(!showFormatSelector)}
                  className="p-2 bg-white/20 rounded-xl hover:bg-white/30 transition-colors"
                  title="URL形式を変更"
                >
                  <Settings className="w-6 h-6" />
                </button>
                <button
                  onClick={onClose}
                  className="p-2 bg-white/20 rounded-xl hover:bg-white/30 transition-colors"
                >
                  <ArrowLeft className="w-6 h-6" />
                </button>
              </div>
            </div>
            <p className="text-blue-100">新しいルームを作成するか、既存のルームに参加しましょう</p>

            {showFormatSelector && (
              <div className="mt-4 bg-white/10 rounded-xl p-4 backdrop-blur-sm">
                <h3 className="font-bold mb-3 text-sm">URL形式を選択</h3>
                <div className="space-y-2">
                  {(['hash', 'query', 'path'] as URLFormat[]).map((format) => (
                    <button
                      key={format}
                      onClick={() => setUrlFormat(format)}
                      className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                        urlFormat === format
                          ? 'bg-white text-blue-600 font-medium'
                          : 'bg-white/20 hover:bg-white/30'
                      }`}
                    >
                      {getFormatLabel(format)}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-blue-100 mt-3">
                  現在: {getFormatLabel(urlFormat)}
                </p>
              </div>
            )}
          </div>

          <div className="p-6">
            <form onSubmit={handleJoinByCode} className="mb-8">
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
                <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <LogIn className="w-6 h-6 text-green-600" />
                  ルームコードで参加
                </h2>
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={roomCode}
                    onChange={(e) => setRoomCode(e.target.value)}
                    placeholder="ルームコードを入力（例: chat10, room2）"
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                  <button
                    type="submit"
                    disabled={!roomCode.trim()}
                    className="px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed font-medium"
                  >
                    参加
                  </button>
                </div>
                <p className="text-sm text-gray-600 mt-3">
                  友達から受け取ったルームコードを入力してチャットに参加しましょう。
                </p>
              </div>
            </form>

            {currentUser.is_admin && (
              <form onSubmit={handleCreateRoom} className="mb-8">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-200">
                  <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Plus className="w-6 h-6 text-blue-600" />
                    新しいルームを作成（管理者限定）
                  </h2>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={newRoomName}
                      onChange={(e) => setNewRoomName(e.target.value)}
                      placeholder="ルーム名を入力（例: チーム会議、友達グループ）"
                      maxLength={50}
                      disabled={creating}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="submit"
                      disabled={creating || !newRoomName.trim()}
                      className="px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed font-medium"
                    >
                      {creating ? '作成中...' : '作成'}
                    </button>
                  </div>
                  <p className="text-sm text-gray-600 mt-3">
                    作成すると自動的にURLがコピーされます。
                  </p>
                </div>
              </form>
            )}

            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <MessageCircle className="w-6 h-6 text-indigo-600" />
                全てのルーム
              </h2>

              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">読み込み中...</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-900">参加者オープンチャット</h3>
                        <p className="text-sm text-gray-600">誰でも参加できる公開チャット</p>
                        <p className="text-xs text-gray-400 mt-1 font-mono break-all">
                          {getRoomURL('default', urlFormat)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={handleCopyDefaultRoom}
                          disabled={copiedRoomId === 'default'}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                        >
                          {copiedRoomId === 'default' ? (
                            <>
                              <Check className="w-4 h-4" />
                              コピー済み
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              URL発行
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => handleJoinRoom('default')}
                          className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors whitespace-nowrap"
                        >
                          参加
                        </button>
                      </div>
                    </div>
                  </div>

                  {rooms.map((room) => (
                    <div key={room.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:border-blue-300 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-gray-900">{room.name}</h3>
                          <p className="text-sm text-gray-500">
                            コード: <span className="font-mono font-bold">{room.id}</span>
                          </p>
                          <p className="text-xs text-gray-400 mt-1">
                            作成: {new Date(room.created_at).toLocaleString('ja-JP')}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleCopyUrl(room.id)}
                            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2"
                          >
                            {copiedRoomId === room.id ? (
                              <>
                                <Check className="w-4 h-4" />
                                コピー済み
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4" />
                                URL
                              </>
                            )}
                          </button>
                          <button
                            onClick={() => handleJoinRoom(room.id)}
                            className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
                          >
                            参加
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { supabase } from './supabase';
import { generateDeviceId, getDeviceInfo } from './device';

export async function logDeviceAnalytics(data: {
  eventType: string;
  isInstallable?: boolean;
  installButtonShown?: boolean;
  installAttempted?: boolean;
  installSucceeded?: boolean;
  errorMessage?: string;
}) {
  try {
    const deviceId = generateDeviceId();
    const deviceInfo = getDeviceInfo();

    await supabase.from('device_analytics').insert({
      device_id: deviceId,
      user_agent: deviceInfo.userAgent,
      platform: deviceInfo.platform,
      browser: deviceInfo.browser,
      browser_version: deviceInfo.browserVersion,
      os_version: deviceInfo.osVersion,
      is_standalone: deviceInfo.isStandalone,
      is_installable: data.isInstallable ?? false,
      install_button_shown: data.installButtonShown ?? false,
      install_attempted: data.installAttempted ?? false,
      install_succeeded: data.installSucceeded ?? false,
      event_type: data.eventType,
      error_message: data.errorMessage ?? '',
      ip_address: 'client',
    });
  } catch (error) {
    console.error('Analytics error:', error);
  }
}

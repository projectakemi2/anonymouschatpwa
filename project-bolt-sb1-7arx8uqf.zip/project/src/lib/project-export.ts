import JSZip from 'jszip';

export async function downloadProjectHandoverPackage(): Promise<void> {
  try {
    const zip = new JSZip();

    const readmeContent = generateHandoverReadme();
    zip.file('HANDOVER_README.md', readmeContent);

    const envExample = generateEnvExample();
    zip.file('.env.example', envExample);

    const apiSpec = generateApiSpec();
    zip.file('docs/API_SPECIFICATION.md', apiSpec);

    const setupGuide = generateSetupGuide();
    zip.file('docs/SETUP_GUIDE.md', setupGuide);

    const deployGuide = generateDeployGuide();
    zip.file('docs/DEPLOY_GUIDE.md', deployGuide);

    const architectureDoc = generateArchitectureDoc();
    zip.file('docs/ARCHITECTURE.md', architectureDoc);

    const fileStructure = generateFileStructure();
    zip.file('docs/FILE_STRUCTURE.md', fileStructure);

    const instructionsDoc = generateInstructions();
    zip.file('README_FIRST.md', instructionsDoc);

    const blob = await zip.generateAsync({ type: 'blob' });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    link.download = `anonymous-chat-pwa-handover-${timestamp}.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Failed to download handover package:', error);
    throw new Error('プロジェクト引き継ぎパッケージのダウンロードに失敗しました');
  }
}

function generateInstructions(): string {
  return `# 📦 プロジェクト引き継ぎパッケージ

**重要**: このZIPファイルにはドキュメントのみが含まれています。
実際のソースコードは、実行中のアプリケーションから取得してください。

## 📋 このパッケージに含まれるもの

1. **HANDOVER_README.md** - プロジェクト概要と引き継ぎ情報
2. **docs/SETUP_GUIDE.md** - セットアップ手順書
3. **docs/DEPLOY_GUIDE.md** - デプロイ手順書
4. **docs/API_SPECIFICATION.md** - API仕様書
5. **docs/ARCHITECTURE.md** - アーキテクチャ設計書
6. **docs/FILE_STRUCTURE.md** - ファイル構造
7. **.env.example** - 環境変数テンプレート

## 🚀 次のステップ

### 1. ソースコードの取得

このプロジェクトのソースコードは、実行中のサーバーから取得してください：

\`\`\`bash
# プロジェクトディレクトリ全体をコピー
# または、Gitリポジトリからクローン
\`\`\`

### 2. ドキュメントの確認

1. **HANDOVER_README.md** を最初に読む
2. **docs/SETUP_GUIDE.md** でセットアップ手順を確認
3. **docs/ARCHITECTURE.md** でシステム構成を理解
4. **docs/API_SPECIFICATION.md** でAPI仕様を確認

### 3. 環境構築

**.env.example** を参考に環境変数を設定してください。

## 📂 必要なファイル一覧

このプロジェクトには以下のファイルが必要です：

\`\`\`
project/
├── src/
│   ├── components/
│   │   ├── AdminPanel.tsx
│   │   ├── ChatScreen.tsx
│   │   ├── DeviceAnalyticsDashboard.tsx
│   │   ├── InstallBanner.tsx
│   │   ├── InstallPrompt.tsx
│   │   ├── LandingPage.tsx
│   │   ├── RegisterScreen.tsx
│   │   ├── RoomList.tsx
│   │   └── SafariPrompt.tsx
│   ├── lib/
│   │   ├── admin.ts
│   │   ├── analytics.ts
│   │   ├── device.ts
│   │   ├── export.ts
│   │   ├── image.ts
│   │   ├── messages.ts
│   │   ├── notification.ts
│   │   ├── project-export.ts
│   │   ├── room.ts
│   │   ├── supabase.ts
│   │   └── user.ts
│   ├── App.tsx
│   ├── main.tsx
│   ├── index.css
│   └── vite-env.d.ts
├── public/
│   ├── manifest.json
│   ├── sw.js
│   ├── robots.txt
│   ├── sitemap.xml
│   ├── security.txt
│   ├── _headers
│   └── icons/
├── supabase/
│   ├── migrations/
│   │   ├── 20260112164121_create_anonymous_chat_schema.sql
│   │   ├── 20260112165110_optimize_performance_and_add_ttl.sql
│   │   ├── 20260114093123_fix_rls_policies.sql
│   │   ├── 20260114094010_fix_messages_select_policy.sql
│   │   ├── 20260114095216_fix_ip_blocks_rls_policy.sql
│   │   ├── 20260115035200_add_room_support.sql
│   │   └── 20260115092915_add_device_analytics.sql
│   └── functions/
│       └── admin-operations/
│           └── index.ts
├── package.json
├── package-lock.json
├── tsconfig.json
├── tsconfig.app.json
├── tsconfig.node.json
├── vite.config.ts
├── tailwind.config.js
├── postcss.config.js
├── eslint.config.js
├── index.html
├── .gitignore
└── .env (秘密情報なので除外)
\`\`\`

## 🔑 重要な設定ファイル

### package.json
プロジェクトの依存関係が定義されています。

### .env
環境変数（機密情報を含む）。**.env.example** を参考に作成してください。

### supabase/migrations/
データベーススキーマ定義。順番に実行してください。

## 💡 ヒント

- 全てのドキュメントは **docs/** フォルダにあります
- 困ったら **HANDOVER_README.md** に戻ってください
- セットアップ中に問題が発生したら **docs/SETUP_GUIDE.md** のトラブルシューティングセクションを確認

---

**作成日**: ${new Date().toISOString()}
`;
}

function generateHandoverReadme(): string {
  return `# Anonymous Chat PWA - プロジェクト引き継ぎドキュメント

## 📋 プロジェクト概要

完全匿名のチャットアプリケーション（PWA）です。
ユーザー登録不要、表示名のみで参加できるリアルタイムチャットシステム。

### 主な機能

- ✅ 完全匿名チャット（メール不要、登録不要）
- ✅ リアルタイムメッセージング（Supabase Realtime）
- ✅ ルーム機能（複数のチャットルーム）
- ✅ 画像送信機能
- ✅ 管理者機能（ユーザーブロック、メッセージ削除、監査ログ）
- ✅ デバイス分析
- ✅ PWA対応（オフライン対応、インストール可能）
- ✅ レート制限（スパム防止）
- ✅ IPベースのブロック機能
- ✅ データエクスポート機能

## 🛠️ 技術スタック

### フロントエンド
- React 18.3
- TypeScript 5.5
- Vite 5.4
- Tailwind CSS 3.4
- Lucide React 0.344
- QRCode 1.5
- JSZip

### バックエンド・インフラ
- Supabase（Database、Auth、Realtime、Edge Functions）
- PostgreSQL
- Deno（Edge Functions実行環境）

### PWA機能
- Service Worker
- Web Manifest
- オフライン対応

## 🚀 クイックスタート

### 1. 依存関係のインストール
\`\`\`bash
npm install
\`\`\`

### 2. 環境変数の設定
\`.env.example\` を \`.env\` にコピーして値を設定：
\`\`\`bash
cp .env.example .env
\`\`\`

### 3. Supabaseプロジェクトの作成
https://supabase.com でプロジェクトを作成し、URLとAnon Keyを取得

### 4. データベースマイグレーション
Supabaseダッシュボードで \`supabase/migrations/\` 内のSQLファイルを順番に実行

### 5. 開発サーバー起動
\`\`\`bash
npm run dev
\`\`\`

## 📚 ドキュメント

- **docs/SETUP_GUIDE.md** - 詳細なセットアップ手順
- **docs/DEPLOY_GUIDE.md** - デプロイ手順（Vercel、Netlify等）
- **docs/API_SPECIFICATION.md** - API仕様書
- **docs/ARCHITECTURE.md** - アーキテクチャ設計書
- **docs/FILE_STRUCTURE.md** - ファイル構造

## 🔐 環境変数

\`\`\`
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_ADMIN_PASSWORD=admin123
VITE_APP_URL=http://localhost:5173
\`\`\`

## 🗄️ データベース

### 主なテーブル
- \`anonymous_users\` - 匿名ユーザー
- \`messages\` - メッセージ
- \`rooms\` - チャットルーム
- \`ip_blocks\` - IPブロックリスト
- \`device_analytics\` - デバイス分析データ
- \`audit_logs\` - 監査ログ
- \`rate_limits\` - レート制限

### RLS（Row Level Security）
全テーブルでRLSが有効化されています。

## 🎯 次のステップ

1. [ ] 本番環境用の管理者パスワード変更
2. [ ] ログ監視システムの導入
3. [ ] バックアップ戦略の策定
4. [ ] スケーリング戦略の検討
5. [ ] セキュリティ監査の実施

## 📞 トラブルシューティング

問題が発生した場合は **docs/SETUP_GUIDE.md** のトラブルシューティングセクションを確認してください。

---

**作成日**: ${new Date().toISOString()}
**バージョン**: 1.0.0
`;
}

function generateEnvExample(): string {
  return `# Supabase Configuration
# Required: Get these from your Supabase project dashboard
# https://app.supabase.com/project/_/settings/api
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Admin Configuration
# Required: Set a strong password for admin access
VITE_ADMIN_PASSWORD=admin123

# Application Configuration
# Optional: Set your production URL
VITE_APP_URL=http://localhost:5173

# Notes:
# 1. NEVER commit .env file to git
# 2. Keep your SUPABASE_ANON_KEY secure
# 3. Change ADMIN_PASSWORD for production
# 4. All VITE_ prefixed variables are exposed to the browser
# 5. Do NOT put sensitive secrets in VITE_ variables
`;
}

function generateApiSpec(): string {
  return `# API Specification - Anonymous Chat PWA

## Overview

このプロジェクトはSupabase Database + Realtime + Edge Functionsを使用しています。
従来のREST APIではなく、Supabase Clientライブラリ経由でデータベースに直接アクセスします。

## Authentication

**認証方式**: 匿名（IPアドレスベース）
- ユーザー登録不要
- メール認証不要
- IPアドレスで識別
- Row Level Security (RLS)で保護

## データアクセスパターン

### Supabase Client

\`\`\`typescript
import { supabase } from './lib/supabase';

// SELECT
const { data, error } = await supabase
  .from('messages')
  .select('*')
  .order('created_at', { ascending: false });

// INSERT
const { data, error } = await supabase
  .from('messages')
  .insert({ content: 'Hello', user_id: userId });

// REALTIME
const channel = supabase
  .channel('messages')
  .on('postgres_changes', {
    event: '*',
    schema: 'public',
    table: 'messages'
  }, (payload) => {
    console.log('Change received!', payload);
  })
  .subscribe();
\`\`\`

## データベーステーブル

### 1. anonymous_users
匿名ユーザー情報

### 2. messages
チャットメッセージ

### 3. rooms
チャットルーム

### 4. ip_blocks
IPブロックリスト

### 5. device_analytics
デバイス分析データ

### 6. audit_logs
監査ログ

### 7. rate_limits
レート制限

詳細は各テーブルのマイグレーションファイルを参照してください。

---

**Last Updated**: ${new Date().toISOString()}
`;
}

function generateSetupGuide(): string {
  return `# Setup Guide - Anonymous Chat PWA

## 前提条件

- Node.js 18+（推奨: 20.x LTS）
- npm 9+
- Supabaseアカウント（無料プランでOK）
- モダンブラウザ（Chrome、Firefox、Safari、Edge最新版）

## ステップ1: プロジェクトのセットアップ

### 1.1 依存関係のインストール

\`\`\`bash
npm install
\`\`\`

### 1.2 Node.jsバージョン確認

\`\`\`bash
node --version  # v18.0.0 以上
npm --version   # v9.0.0 以上
\`\`\`

## ステップ2: Supabaseプロジェクトの作成

1. https://supabase.com にアクセス
2. 「Start your project」をクリック
3. 新規プロジェクト作成
4. プロジェクトURLとAnon Keyを取得

## ステップ3: 環境変数の設定

\`\`\`bash
cp .env.example .env
\`\`\`

\`.env\` ファイルを編集：

\`\`\`
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_ADMIN_PASSWORD=admin123
VITE_APP_URL=http://localhost:5173
\`\`\`

## ステップ4: データベースのセットアップ

Supabaseダッシュボードの「SQL Editor」で、以下のファイルを順番に実行：

1. \`20260112164121_create_anonymous_chat_schema.sql\`
2. \`20260112165110_optimize_performance_and_add_ttl.sql\`
3. \`20260114093123_fix_rls_policies.sql\`
4. \`20260114094010_fix_messages_select_policy.sql\`
5. \`20260114095216_fix_ip_blocks_rls_policy.sql\`
6. \`20260115035200_add_room_support.sql\`
7. \`20260115092915_add_device_analytics.sql\`

## ステップ5: 開発サーバーの起動

\`\`\`bash
npm run dev
\`\`\`

http://localhost:5173 をブラウザで開く

## トラブルシューティング

### npm install が失敗する

\`\`\`bash
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
\`\`\`

### Supabaseに接続できない

1. \`.env\` ファイルが存在するか確認
2. 環境変数が正しいか確認
3. 開発サーバーを再起動

---

**Last Updated**: ${new Date().toISOString()}
`;
}

function generateDeployGuide(): string {
  return `# Deploy Guide - Anonymous Chat PWA

## デプロイ先の選択

1. **Vercel** ⭐ 推奨（最も簡単）
2. **Netlify** ⭐ 推奨
3. **Cloudflare Pages**
4. **その他**

## Vercelでのデプロイ（推奨）

### ステップ1: GitHubリポジトリの作成

\`\`\`bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/your-username/anonymous-chat-pwa.git
git push -u origin main
\`\`\`

### ステップ2: Vercelでインポート

1. https://vercel.com にアクセス
2. 「Add New Project」をクリック
3. GitHubリポジトリを選択

### ステップ3: ビルド設定

- Framework Preset: Vite
- Build Command: \`npm run build\`
- Output Directory: \`dist\`

### ステップ4: 環境変数の設定

\`\`\`
VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
VITE_ADMIN_PASSWORD
VITE_APP_URL
\`\`\`

### ステップ5: デプロイ

「Deploy」ボタンをクリック

## デプロイ前チェックリスト

- [ ] \`npm run build\` が成功する
- [ ] 全ての環境変数が設定されている
- [ ] 管理者パスワードが強力である
- [ ] Supabase URLが正しい
- [ ] データベースマイグレーションが完了している

---

**Last Updated**: ${new Date().toISOString()}
`;
}

function generateArchitectureDoc(): string {
  return `# Architecture Document - Anonymous Chat PWA

## システムアーキテクチャ概要

**Jamstack**アーキテクチャを採用した完全匿名のリアルタイムチャットアプリケーション。

\`\`\`
┌─────────────────────────────────────┐
│     Client (Browser)                 │
│  React + TypeScript + Tailwind      │
│  Supabase Client Library            │
└─────────────────────────────────────┘
              ↕ HTTPS/WSS
┌─────────────────────────────────────┐
│     Supabase (BaaS)                 │
│  PostgreSQL + Realtime + Edge Fns   │
│  Row Level Security (RLS)           │
└─────────────────────────────────────┘
\`\`\`

## レイヤー構成

### 1. Presentation Layer
- React 18.3
- TypeScript
- Tailwind CSS

### 2. Business Logic Layer
- TypeScript modules
- Validation
- Error handling

### 3. Data Access Layer
- Supabase Client
- Realtime subscriptions

### 4. Infrastructure Layer
- Supabase (PostgreSQL)
- Edge Functions

## セキュリティアーキテクチャ

### Row Level Security (RLS)

全テーブルでRLSが有効化されています。

### レート制限
- メッセージ送信: 10件/分
- ルーム作成: 5件/時間

### IPブロック

ブロックされたIPは送信不可、読み取りのみ可能。

---

**Last Updated**: ${new Date().toISOString()}
`;
}

function generateFileStructure(): string {
  return `# File Structure - Anonymous Chat PWA

## プロジェクト全体構造

\`\`\`
anonymous-chat-pwa/
├── src/
│   ├── components/          # Reactコンポーネント
│   ├── lib/                 # ビジネスロジック
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── public/                  # 静的ファイル
├── supabase/
│   ├── functions/           # Edge Functions
│   └── migrations/          # DBマイグレーション
├── package.json
├── vite.config.ts
└── tsconfig.json
\`\`\`

## 主要ディレクトリ

### src/components/
Reactコンポーネント

### src/lib/
ビジネスロジックとユーティリティ

### supabase/migrations/
データベースマイグレーション

---

**Last Updated**: ${new Date().toISOString()}
`;
}

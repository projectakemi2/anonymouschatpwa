import { supabase } from './supabase';

export interface ProjectExport {
  export_info: {
    timestamp: string;
    version: string;
    project_name: string;
  };
  database_schema: string;
  database_data: {
    anonymous_users: any[];
    messages: any[];
    rooms: any[];
    ip_blocks: any[];
    device_analytics: any[];
    audit_logs: any[];
    rate_limits: any[];
  };
  project_files: {
    [key: string]: string;
  };
  environment: {
    supabase_url: string;
    app_url: string;
  };
  statistics: {
    total_users: number;
    total_messages: number;
    total_rooms: number;
    total_blocks: number;
    total_analytics: number;
  };
}

export async function exportAllProjectData(): Promise<ProjectExport> {
  try {
    const [
      usersResult,
      messagesResult,
      roomsResult,
      blocksResult,
      analyticsResult,
      auditLogsResult,
      rateLimitsResult
    ] = await Promise.all([
      supabase.from('anonymous_users').select('*').order('created_at', { ascending: false }),
      supabase.from('messages').select('*, user:anonymous_users(display_name, is_admin)').order('created_at', { ascending: false }),
      supabase.from('rooms').select('*').order('created_at', { ascending: false }),
      supabase.from('ip_blocks').select('*, blocker:blocked_by(display_name)').order('created_at', { ascending: false }),
      supabase.from('device_analytics').select('*, user:anonymous_users(display_name)').order('created_at', { ascending: false }),
      supabase.from('audit_logs').select('*, admin:admin_id(display_name)').order('created_at', { ascending: false }),
      supabase.from('rate_limits').select('*').order('created_at', { ascending: false })
    ]);

    const users = usersResult.data || [];
    const messages = messagesResult.data || [];
    const rooms = roomsResult.data || [];
    const blocks = blocksResult.data || [];
    const analytics = analyticsResult.data || [];
    const auditLogs = auditLogsResult.data || [];
    const rateLimits = rateLimitsResult.data || [];

    const databaseSchema = await fetchDatabaseSchema();

    const projectExport: ProjectExport = {
      export_info: {
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        project_name: 'Anonymous Chat PWA'
      },
      database_schema: databaseSchema,
      database_data: {
        anonymous_users: users,
        messages: messages,
        rooms: rooms,
        ip_blocks: blocks,
        device_analytics: analytics,
        audit_logs: auditLogs,
        rate_limits: rateLimits
      },
      project_files: {
        note: 'プロジェクトファイルはCOMPLETE_SOURCE_CODE.mdとDATABASE_SCHEMA.sqlを参照してください'
      },
      environment: {
        supabase_url: import.meta.env.VITE_SUPABASE_URL || '',
        app_url: import.meta.env.VITE_APP_URL || ''
      },
      statistics: {
        total_users: users.length,
        total_messages: messages.length,
        total_rooms: rooms.length,
        total_blocks: blocks.length,
        total_analytics: analytics.length
      }
    };

    return projectExport;
  } catch (error) {
    console.error('Export error:', error);
    throw new Error('データのエクスポートに失敗しました');
  }
}

async function fetchDatabaseSchema(): Promise<string> {
  try {
    const response = await fetch('/DATABASE_SCHEMA.sql');
    if (response.ok) {
      return await response.text();
    }
    return 'スキーマファイルが見つかりません';
  } catch (error) {
    return 'スキーマの取得に失敗しました';
  }
}

export function downloadJSON(data: any, filename: string) {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function exportDatabaseSchema(): Promise<string> {
  const { data, error } = await supabase.rpc('get_database_schema');

  if (error) {
    console.warn('RPC call failed, using fallback schema');
    return await fetchDatabaseSchema();
  }

  return data || await fetchDatabaseSchema();
}

export async function exportTableData(tableName: string): Promise<any[]> {
  const { data, error } = await supabase.from(tableName).select('*');

  if (error) {
    console.error(`Failed to export ${tableName}:`, error);
    return [];
  }

  return data || [];
}

export function generateExportFilename(): string {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
  return `anonymous-chat-export-${timestamp}.json`;
}

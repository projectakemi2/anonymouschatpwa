const CACHE_NAME = 'anonymous-chat-v10';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png'
];

const SUPABASE_URL = 'https://bgridzofylgxvopinici.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJncmlkem9meWxneHZvcGluaWNpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgyMjgxNTEsImV4cCI6MjA4MzgwNDE1MX0.6phM-YRhfhKnlOuo2F39ltXby2eMQ7bdA-L9yL6kc9o';

let currentUserId = null;
let currentRoomId = null;
let lastMessageTimestamp = null;
let checkInterval = null;

self.addEventListener('install', (event) => {
  console.log('SW: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(urlsToCache);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  console.log('SW: Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('SW: Activated and ready');
      return self.clients.claim();
    })
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (!response || response.status !== 200 || response.type === 'error') {
          return response;
        }

        const responseToCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });

        return response;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );
});

self.addEventListener('message', async (event) => {
  console.log('SW: Received message:', event.data);

  if (event.data && event.data.type === 'SET_USER_INFO') {
    currentUserId = event.data.userId;
    currentRoomId = event.data.roomId;

    console.log('SW: User info set:', { currentUserId, currentRoomId });

    // 既存のインターバルをクリア
    if (checkInterval) {
      clearInterval(checkInterval);
    }

    // 最新のメッセージのタイムスタンプを取得
    await initializeLastMessageTimestamp();

    // メッセージチェックを開始（3秒間隔で頻繁にチェック）
    checkInterval = setInterval(() => {
      checkForNewMessages();
    }, 3000);

    // 即座に一度チェック
    checkForNewMessages();

    console.log('SW: Started checking for new messages');
  }

  if (event.data && event.data.type === 'STOP_CHECKING') {
    if (checkInterval) {
      clearInterval(checkInterval);
      checkInterval = null;
      console.log('SW: Stopped checking for messages');
    }
  }
});

async function initializeLastMessageTimestamp() {
  if (!currentRoomId) return;

  try {
    // 最新のメッセージを1件取得
    const url = `${SUPABASE_URL}/rest/v1/messages?room_id=eq.${currentRoomId}&order=created_at.desc&limit=1&select=created_at`;

    const response = await fetch(url, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      const messages = await response.json();
      if (messages.length > 0) {
        lastMessageTimestamp = messages[0].created_at;
        console.log('SW: Initialized lastMessageTimestamp:', lastMessageTimestamp);
      } else {
        // メッセージがない場合は現在時刻
        lastMessageTimestamp = new Date().toISOString();
        console.log('SW: No existing messages, using current time');
      }
    } else {
      lastMessageTimestamp = new Date().toISOString();
      console.log('SW: Failed to fetch last message, using current time');
    }
  } catch (error) {
    console.error('SW: Error initializing timestamp:', error);
    lastMessageTimestamp = new Date().toISOString();
  }
}

async function checkForNewMessages() {
  if (!currentRoomId || !currentUserId || !lastMessageTimestamp) {
    console.log('SW: Missing required data for checking messages');
    return;
  }

  try {
    const url = `${SUPABASE_URL}/rest/v1/messages?room_id=eq.${currentRoomId}&created_at=gt.${lastMessageTimestamp}&order=created_at.asc&select=id,content,user_id,created_at,users(display_name)`;

    const response = await fetch(url, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      }
    });

    if (!response.ok) {
      console.error('SW: Failed to fetch messages:', response.status);
      return;
    }

    const messages = await response.json();

    if (messages.length > 0) {
      console.log(`SW: Found ${messages.length} new messages`);
    }

    for (const message of messages) {
      // 自分以外のメッセージだけ通知
      if (message.user_id !== currentUserId) {
        const displayName = message.users?.display_name || '匿名ユーザー';
        const messageContent = message.content || '画像を送信しました';

        console.log('SW: Showing notification for message:', message.id);

        await self.registration.showNotification(displayName, {
          body: messageContent.substring(0, 100),
          icon: '/icon-192.png',
          badge: '/icon-192.png',
          vibrate: [300, 100, 300, 100, 300],
          tag: `message-${message.id}`,
          requireInteraction: false,
          silent: false,
          data: {
            url: self.location.origin,
            messageId: message.id
          }
        });

        console.log('✅ SW: Notification shown for message from:', displayName);
      }

      // タイムスタンプを更新
      lastMessageTimestamp = message.created_at;
    }
  } catch (error) {
    console.error('SW: Error checking messages:', error);
  }
}

self.addEventListener('push', (event) => {
  console.log('SW: Push event received');
  const data = event.data ? event.data.json() : {};

  const options = {
    body: data.body || '新しいメッセージがあります',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    vibrate: [200, 100, 200],
    data: {
      url: data.url || '/',
      message_id: data.message_id,
      room_id: data.room_id,
      campaign_id: data.campaign_id,
      subscription_id: data.subscription_id
    },
    requireInteraction: false,
    tag: data.message_id ? `message-${data.message_id}` : `notification-${Date.now()}`
  };

  event.waitUntil(
    self.registration.showNotification(data.title || '参加者オープンチャット', options)
  );
});

self.addEventListener('notificationclick', (event) => {
  console.log('SW: Notification clicked');
  event.notification.close();

  const notificationData = event.notification.data || {};

  event.waitUntil(
    (async () => {
      if (notificationData.subscription_id) {
        try {
          await fetch(`${SUPABASE_URL}/functions/v1/track-notification-event`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            },
            body: JSON.stringify({
              subscription_id: notificationData.subscription_id,
              campaign_id: notificationData.campaign_id,
              event_type: 'clicked'
            })
          });
          console.log('SW: Tracked notification click');
        } catch (error) {
          console.error('SW: Failed to track click:', error);
        }
      }

      const clientList = await clients.matchAll({ type: 'window', includeUncontrolled: true });
      const urlToOpen = notificationData.url || self.location.origin;

      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          return client.focus();
        }
      }

      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })()
  );
});

self.addEventListener('notificationclose', (event) => {
  console.log('SW: Notification dismissed');

  const notificationData = event.notification.data || {};

  if (notificationData.subscription_id) {
    event.waitUntil(
      fetch(`${SUPABASE_URL}/functions/v1/track-notification-event`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          subscription_id: notificationData.subscription_id,
          campaign_id: notificationData.campaign_id,
          event_type: 'dismissed'
        })
      }).catch(error => {
        console.error('SW: Failed to track dismiss:', error);
      })
    );
  }
});

self.addEventListener('pushsubscriptionchange', (event) => {
  console.log('SW: Push subscription changed');

  event.waitUntil(
    (async () => {
      try {
        const newSubscription = await self.registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: 'BKyhAA-s_Lb4jQ4IsJugCLi0bE0oNR95PngSJnTfCwF0xs25v3czEhSKCbLGZktGFwmuGzy99HsaOX73KOWrVZI'
        });

        const oldEndpoint = event.oldSubscription?.endpoint;

        const subscriptionData = {
          endpoint: newSubscription.endpoint,
          keys: {
            p256dh: arrayBufferToBase64(newSubscription.getKey('p256dh')),
            auth: arrayBufferToBase64(newSubscription.getKey('auth'))
          }
        };

        const response = await fetch(`${SUPABASE_URL}/functions/v1/update-push-subscription`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            oldEndpoint: oldEndpoint,
            newSubscription: subscriptionData
          })
        });

        if (response.ok) {
          console.log('SW: Successfully updated push subscription');
        } else {
          console.error('SW: Failed to update push subscription:', await response.text());
        }
      } catch (error) {
        console.error('SW: Error handling subscription change:', error);
      }
    })()
  );
});

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return self.btoa(binary);
}

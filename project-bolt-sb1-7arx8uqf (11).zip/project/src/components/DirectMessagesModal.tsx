import { useState, useEffect, useRef, useMemo } from 'react';
import { X, Send, ArrowLeft, Image as ImageIcon, X as XIcon, Trash2, Users } from 'lucide-react';
import {
  DirectMessage,
  DMThread,
  getDMThreads,
  getDirectMessages,
  sendDirectMessage,
  markThreadAsRead,
  getAdminUsers,
  subscribeToDirectMessages,
  deleteDirectMessage,
  broadcastToRepliedUsers,
  getUsersWhoReplied,
  broadcastToUnrepliedUsers,
  getActiveUsersWithoutReply,
} from '../lib/direct-messages';
import { linkifyText } from '../lib/text-utils';

interface DirectMessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserId: string;
  currentUserName: string;
  isAdmin: boolean;
  roomId: string | null;
}

export function DirectMessagesModal({
  isOpen,
  onClose,
  currentUserId,
  currentUserName,
  isAdmin,
  roomId,
}: DirectMessagesModalProps) {
  const [view, setView] = useState<'threads' | 'chat' | 'broadcast'>('threads');
  const [broadcastType, setBroadcastType] = useState<'replied' | 'unreplied'>('replied');
  const [threads, setThreads] = useState<DMThread[]>([]);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [selectedThread, setSelectedThread] = useState<DMThread | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [adminUsers, setAdminUsers] = useState<Array<{ id: string; display_name: string }>>([]);
  const [selectedImage, setSelectedImage] = useState<{ url: string; name: string } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [repliedUsersCount, setRepliedUsersCount] = useState(0);
  const [unrepliedUsersCount, setUnrepliedUsersCount] = useState(0);
  const [isSendingBroadcast, setIsSendingBroadcast] = useState(false);
  const [expandedImage, setExpandedImage] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [showUnreadOnly, setShowUnreadOnly] = useState(false);
  const [filterNeverReceived, setFilterNeverReceived] = useState(false);
  const [searchName, setSearchName] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      loadThreads();
      if (!isAdmin) {
        loadAdminUsers();
      } else {
        loadRepliedUsersCount();
        loadUnrepliedUsersCount();
      }
    }
  }, [isOpen, currentUserId]);

  useEffect(() => {
    if (isAdmin && isOpen) {
      loadUnrepliedUsersCount();
    }
  }, [startDate, endDate, filterNeverReceived]);

  const loadRepliedUsersCount = async () => {
    if (!isAdmin) return;
    const users = await getUsersWhoReplied(currentUserId);
    setRepliedUsersCount(users.length);
  };

  const loadUnrepliedUsersCount = async () => {
    if (!isAdmin) return;
    const users = await getActiveUsersWithoutReply(startDate || undefined, endDate || undefined, filterNeverReceived);
    setUnrepliedUsersCount(users.length);
  };

  useEffect(() => {
    if (!isOpen) return;

    const channel = subscribeToDirectMessages(currentUserId, (newMsg) => {
      if (selectedThread &&
          (newMsg.sender_id === selectedThread.user_id || newMsg.recipient_id === selectedThread.user_id)) {
        setMessages(prev => [...prev, newMsg]);
        markThreadAsRead(currentUserId, selectedThread.user_id);
      }
      loadThreads();
    });

    return () => {
      channel.unsubscribe();
    };
  }, [isOpen, currentUserId, selectedThread]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadThreads = async () => {
    const data = await getDMThreads(currentUserId);
    setThreads(data);
  };

  const loadAdminUsers = async () => {
    const data = await getAdminUsers();
    setAdminUsers(data);
  };

  const filteredThreads = useMemo(() => {
    return threads.filter(thread => {
      const matchesUnread = !showUnreadOnly || thread.unread_count > 0;
      const matchesSearch = !searchName || thread.user_name.toLowerCase().includes(searchName.toLowerCase());
      return matchesUnread && matchesSearch;
    });
  }, [threads, showUnreadOnly, searchName]);

  const dateRangeLabel = useMemo(() => {
    if (!startDate || !endDate) return null;

    const start = new Date(startDate).toLocaleDateString('ja-JP', { month: 'numeric', day: 'numeric' });
    const end = new Date(endDate);
    end.setDate(end.getDate() - 1);
    const endStr = end.toLocaleDateString('ja-JP', { month: 'numeric', day: 'numeric' });

    return start === endStr ? start : `${start}～${endStr}`;
  }, [startDate, endDate]);

  const openThread = async (thread: DMThread) => {
    setSelectedThread(thread);
    const msgs = await getDirectMessages(currentUserId, thread.user_id);
    setMessages(msgs);
    setView('chat');
    await markThreadAsRead(currentUserId, thread.user_id);
    await loadThreads();
  };

  const startNewThreadWithAdmin = async (adminId: string, adminName: string) => {
    const thread: DMThread = {
      user_id: adminId,
      user_name: adminName,
      is_admin: true,
      last_message: '',
      last_message_at: new Date().toISOString(),
      unread_count: 0,
    };
    setSelectedThread(thread);
    const msgs = await getDirectMessages(currentUserId, adminId);
    setMessages(msgs);
    setView('chat');
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('画像ファイルのみアップロード可能です');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('画像サイズは5MB以下にしてください');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage({
        url: event.target?.result as string,
        name: file.name,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!newMessage.trim() && !selectedImage) || !selectedThread) return;

    const message = await sendDirectMessage(
      currentUserId,
      selectedThread.user_id,
      newMessage.trim(),
      roomId,
      selectedImage?.url,
      selectedImage?.name
    );

    if (message) {
      setMessages(prev => [...prev, message]);
      setNewMessage('');
      setSelectedImage(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      await loadThreads();
    }
  };

  const backToThreads = () => {
    setView('threads');
    setSelectedThread(null);
    setMessages([]);
    setNewMessage('');
    setSelectedImage(null);
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!confirm('このメッセージを削除しますか？')) return;

    const success = await deleteDirectMessage(messageId);
    if (success) {
      setMessages(prev => prev.filter(msg => msg.id !== messageId));
      await loadThreads();
    } else {
      alert('メッセージの削除に失敗しました');
    }
  };

  const openBroadcast = () => {
    setView('broadcast');
    setNewMessage('');
    setSelectedImage(null);
  };

  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!newMessage.trim() && !selectedImage) || isSendingBroadcast) return;

    const targetCount = broadcastType === 'replied' ? repliedUsersCount : unrepliedUsersCount;

    let targetLabel = '';
    if (broadcastType === 'replied') {
      targetLabel = '返信があった';
    } else {
      const filterSuffix = filterNeverReceived ? 'メール未受信の' : '未返信の';
      targetLabel = dateRangeLabel ? `${dateRangeLabel}にログインした${filterSuffix}` : `本日ログイン・${filterSuffix}`;
    }

    if (!confirm(`${targetLabel}${targetCount}人に一斉送信しますか？`)) return;

    setIsSendingBroadcast(true);

    const result = broadcastType === 'replied'
      ? await broadcastToRepliedUsers(
          currentUserId,
          newMessage.trim(),
          roomId,
          selectedImage?.url,
          selectedImage?.name
        )
      : await broadcastToUnrepliedUsers(
          currentUserId,
          newMessage.trim(),
          roomId,
          selectedImage?.url,
          selectedImage?.name,
          startDate || undefined,
          endDate || undefined,
          filterNeverReceived
        );

    setIsSendingBroadcast(false);

    if (result.success > 0) {
      alert(`${result.success}/${result.total}人に送信しました`);
      setNewMessage('');
      setSelectedImage(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      setView('threads');
      await loadThreads();
      await loadUnrepliedUsersCount();
    } else {
      alert('送信に失敗しました');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files).filter(file => file.type.startsWith('image/'));
    if (files.length === 0) {
      alert('画像ファイルのみアップロード可能です');
      return;
    }

    const file = files[0];

    if (file.size > 5 * 1024 * 1024) {
      alert('画像サイズは5MB以下にしてください');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage({
        url: event.target?.result as string,
        name: file.name,
      });
    };
    reader.readAsDataURL(file);
  };

  if (!isOpen) return null;

  return (
    <>
      {expandedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-[60] p-4"
          onClick={() => setExpandedImage(null)}
        >
          <button
            onClick={() => setExpandedImage(null)}
            className="absolute top-4 right-4 p-2 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
          <img
            src={expandedImage}
            alt="拡大画像"
            className="max-w-full max-h-full object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          {(view === 'chat' || view === 'broadcast') && (
            <button
              onClick={backToThreads}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-xl font-bold flex-1">
            {view === 'threads'
              ? 'ダイレクトメッセージ'
              : view === 'broadcast'
              ? `一斉送信 (${broadcastType === 'replied' ? repliedUsersCount : unrepliedUsersCount}人)`
              : selectedThread?.user_name}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {view === 'threads' ? (
          <div className="flex-1 overflow-y-auto">
            {isAdmin && (
              <div className="p-4 border-b bg-gradient-to-r from-green-50 to-teal-50">
                <div className="mb-3 space-y-2">
                  <label className="block text-sm font-semibold text-gray-700">対象日時を指定</label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">開始日</label>
                      <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">終了日</label>
                      <input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const today = new Date().toISOString().split('T')[0];
                        const tomorrow = new Date();
                        tomorrow.setDate(tomorrow.getDate() + 1);
                        setStartDate(today);
                        setEndDate(tomorrow.toISOString().split('T')[0]);
                      }}
                      className="px-3 py-1 text-xs bg-white border border-green-300 text-green-700 rounded hover:bg-green-50 transition-colors"
                    >
                      本日
                    </button>
                    <button
                      onClick={() => {
                        const yesterday = new Date();
                        yesterday.setDate(yesterday.getDate() - 1);
                        const today = new Date();
                        setStartDate(yesterday.toISOString().split('T')[0]);
                        setEndDate(today.toISOString().split('T')[0]);
                      }}
                      className="px-3 py-1 text-xs bg-white border border-green-300 text-green-700 rounded hover:bg-green-50 transition-colors"
                    >
                      昨日
                    </button>
                    <button
                      onClick={() => {
                        setStartDate('');
                        setEndDate('');
                      }}
                      className="px-3 py-1 text-xs bg-white border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                    >
                      クリア
                    </button>
                  </div>
                </div>
                <div className="mt-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filterNeverReceived}
                      onChange={(e) => setFilterNeverReceived(e.target.checked)}
                      className="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 rounded focus:ring-green-500 focus:ring-2"
                    />
                    <span className="text-sm font-medium text-gray-700">
                      一度も個別メールを受信したことがないユーザーのみ
                    </span>
                  </label>
                </div>
              </div>
            )}
            {isAdmin && unrepliedUsersCount > 0 && (
              <div className="p-4 border-b bg-gradient-to-r from-green-50 to-teal-50">
                <button
                    onClick={() => {
                      setBroadcastType('unreplied');
                      setView('broadcast');
                      setNewMessage('一度こちらになんでもいいので返信してください。');
                      setSelectedImage(null);
                    }}
                    className="w-full p-4 bg-white hover:bg-green-50 rounded-lg transition-colors border-2 border-green-300 shadow-sm"
                  >
                    <div className="flex items-center justify-center gap-2">
                      <Users className="w-5 h-5 text-green-600" />
                      <span className="font-bold text-green-600">
                        {startDate && endDate ? (
                          filterNeverReceived ? (
                            <>指定期間ログイン・メール未受信ユーザーに一斉送信 ({unrepliedUsersCount}人)</>
                          ) : (
                            <>指定期間ログイン・未返信ユーザーに一斉送信 ({unrepliedUsersCount}人)</>
                          )
                        ) : (
                          filterNeverReceived ? (
                            <>本日ログイン・メール未受信ユーザーに一斉送信 ({unrepliedUsersCount}人)</>
                          ) : (
                            <>本日ログイン・未返信ユーザーに一斉送信 ({unrepliedUsersCount}人)</>
                          )
                        )}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {startDate && endDate ? (
                        filterNeverReceived ? (
                          <>指定した期間にログインしたが、まだ一度も個別メールを受信していないユーザーに送信</>
                        ) : (
                          <>指定した期間にログインしたが、まだ一度も返信していないユーザーに送信</>
                        )
                      ) : (
                        filterNeverReceived ? (
                          <>本日ログインしたが、まだ一度も個別メールを受信していないユーザーに送信</>
                        ) : (
                          <>本日ログインしたが、まだ一度も返信していないユーザーに送信</>
                        )
                      )}
                    </div>
                  </button>
                {unrepliedUsersCount === 0 && (
                  <div className="p-4 bg-white rounded-lg border border-gray-200 text-center text-gray-500">
                    対象ユーザーがいません
                  </div>
                )}
              </div>
            )}
            {isAdmin && repliedUsersCount > 0 && (
              <div className="p-4 border-b bg-gradient-to-r from-purple-50 to-blue-50">
                <button
                  onClick={() => {
                    setBroadcastType('replied');
                    openBroadcast();
                  }}
                  className="w-full p-4 bg-white hover:bg-blue-50 rounded-lg transition-colors border-2 border-blue-300 shadow-sm"
                >
                  <div className="flex items-center justify-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    <span className="font-bold text-blue-600">
                      返信があったユーザーに一斉送信 ({repliedUsersCount}人)
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    個別メッセージで返信があった全員に同時送信できます
                  </div>
                </button>
              </div>
            )}

            {!isAdmin && adminUsers.length > 0 && (
              <div className="p-4 border-b bg-gray-50">
                <h3 className="text-sm font-semibold text-gray-700 mb-2">管理者に連絡</h3>
                <div className="space-y-2">
                  {adminUsers.map((admin) => (
                    <button
                      key={admin.id}
                      onClick={() => startNewThreadWithAdmin(admin.id, admin.display_name)}
                      className="w-full text-left p-3 bg-white hover:bg-blue-50 rounded-lg transition-colors border border-gray-200"
                    >
                      <div className="font-medium text-blue-600">{admin.display_name}</div>
                      <div className="text-sm text-gray-500">新しいメッセージを送信</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {threads.length > 0 && (
              <div className="p-3 border-b bg-gray-50">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowUnreadOnly(false)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        !showUnreadOnly
                          ? 'bg-blue-500 text-white'
                          : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-300'
                      }`}
                    >
                      すべて
                    </button>
                    <button
                      onClick={() => setShowUnreadOnly(true)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        showUnreadOnly
                          ? 'bg-blue-500 text-white'
                          : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-300'
                      }`}
                    >
                      未読のみ
                    </button>
                  </div>
                  <span className="text-sm text-gray-600">
                    {filteredThreads.length}件
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    value={searchName}
                    onChange={(e) => setSearchName(e.target.value)}
                    placeholder="名前で検索..."
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 pl-4"
                  />
                  {searchName && (
                    <button
                      onClick={() => setSearchName('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      title="クリア"
                    >
                      <XIcon className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            )}

            {threads.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <p>メッセージはありません</p>
                {!isAdmin && adminUsers.length > 0 && (
                  <p className="mt-2 text-sm">上の管理者から選択してメッセージを送信できます</p>
                )}
              </div>
            ) : filteredThreads.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <p>未読メッセージはありません</p>
              </div>
            ) : (
              <div className="divide-y">
                {filteredThreads.map((thread) => (
                  <button
                    key={thread.user_id}
                    onClick={() => openThread(thread)}
                    className="w-full text-left p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{thread.user_name}</span>
                          {thread.is_admin && (
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">
                              管理者
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 truncate mt-1">{thread.last_message}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(thread.last_message_at).toLocaleString('ja-JP')}
                        </p>
                      </div>
                      {thread.unread_count > 0 && (
                        <span className="ml-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                          {thread.unread_count}
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : view === 'chat' ? (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <p>メッセージを送信して会話を始めましょう</p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isOwnMessage = msg.sender_id === currentUserId;
                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-2 items-end ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg p-3 ${
                          isOwnMessage
                            ? 'bg-blue-500 text-white'
                            : 'bg-white border border-gray-200'
                        }`}
                      >
                        {msg.image_url && (
                          <div className="mb-2">
                            <img
                              src={msg.image_url}
                              alt={msg.image_name || '添付画像'}
                              onClick={() => setExpandedImage(msg.image_url!)}
                              className="max-w-full rounded-lg max-h-96 object-contain cursor-pointer hover:opacity-90 transition-opacity"
                            />
                          </div>
                        )}
                        {msg.content && (
                          <p className="whitespace-pre-wrap break-words">
                            {linkifyText(msg.content).map((part, idx) =>
                              part.type === 'link' ? (
                                <a
                                  key={part.index || idx}
                                  href={part.content}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="underline hover:opacity-80"
                                >
                                  {part.content}
                                </a>
                              ) : (
                                <span key={idx}>{part.content}</span>
                              )
                            )}
                          </p>
                        )}
                        <p
                          className={`text-xs mt-1 ${
                            isOwnMessage ? 'text-blue-100' : 'text-gray-400'
                          }`}
                        >
                          {new Date(msg.created_at).toLocaleTimeString('ja-JP', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                      {isAdmin && (
                        <button
                          onClick={() => handleDeleteMessage(msg.id)}
                          className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors flex-shrink-0"
                          title="メッセージを削除"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            <form
              onSubmit={handleSendMessage}
              className="p-4 border-t bg-white relative"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              {isDragging && (
                <div className="absolute inset-0 bg-blue-500 bg-opacity-20 border-4 border-blue-500 border-dashed rounded-lg z-10 flex items-center justify-center pointer-events-none">
                  <div className="bg-white px-6 py-4 rounded-lg shadow-lg">
                    <p className="text-lg font-bold text-blue-600">画像をドロップして添付</p>
                  </div>
                </div>
              )}
              {selectedImage && (
                <div className="mb-3 relative inline-block">
                  <img
                    src={selectedImage.url}
                    alt={selectedImage.name}
                    className="max-h-32 rounded-lg border border-gray-300"
                  />
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <XIcon className="w-4 h-4" />
                  </button>
                </div>
              )}
              <div className="flex gap-2 items-end">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-shrink-0 p-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                  title="画像を添付"
                >
                  <ImageIcon className="w-5 h-5" />
                </button>
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage(e);
                    }
                  }}
                  placeholder="メッセージを入力... (Shift+Enterで改行)"
                  className="flex-1 min-w-0 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  maxLength={10000}
                  rows={3}
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim() && !selectedImage}
                  className="flex-shrink-0 p-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  title="送信"
                >
                  <Send className="w-5 h-5" />
                  <span className="hidden sm:inline">送信</span>
                </button>
              </div>
            </form>
          </>
        ) : view === 'broadcast' ? (
          <>
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
              <div className="bg-white rounded-lg p-6 border border-gray-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-3 ${broadcastType === 'replied' ? 'bg-blue-100' : 'bg-green-100'} rounded-full`}>
                    <Users className={`w-6 h-6 ${broadcastType === 'replied' ? 'text-blue-600' : 'text-green-600'}`} />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">一斉送信</h3>
                    <p className="text-sm text-gray-600">
                      {broadcastType === 'replied'
                        ? `個別メッセージで返信があった${repliedUsersCount}人に同時送信されます`
                        : dateRangeLabel
                        ? filterNeverReceived
                          ? `${dateRangeLabel}にログイン・メール未受信の${unrepliedUsersCount}人に同時送信されます`
                          : `${dateRangeLabel}にログイン・未返信の${unrepliedUsersCount}人に同時送信されます`
                        : filterNeverReceived
                        ? `本日ログイン・メール未受信の${unrepliedUsersCount}人に同時送信されます`
                        : `本日ログイン・未返信の${unrepliedUsersCount}人に同時送信されます`
                      }
                    </p>
                  </div>
                </div>
                <div className={`${broadcastType === 'replied' ? 'bg-blue-50 border-blue-200' : 'bg-green-50 border-green-200'} border rounded-lg p-4 mt-4`}>
                  <p className={`text-sm ${broadcastType === 'replied' ? 'text-blue-800' : 'text-green-800'}`}>
                    {broadcastType === 'replied'
                      ? 'このメッセージは、あなたに個別メッセージで返信したことがある全てのユーザーに送信されます。'
                      : dateRangeLabel
                      ? filterNeverReceived
                        ? `このメッセージは、${dateRangeLabel}にログインしたが、まだ一度も個別メッセージを受信していない全てのユーザーに送信されます。`
                        : `このメッセージは、${dateRangeLabel}にログインしたが、まだ一度も個別メッセージを送信していない全てのユーザーに送信されます。`
                      : filterNeverReceived
                      ? 'このメッセージは、本日ログインしたが、まだ一度も個別メッセージを受信していない全てのユーザーに送信されます。'
                      : 'このメッセージは、本日ログインしたが、まだ一度も個別メッセージを送信していない全てのユーザーに送信されます。'
                    }
                  </p>
                </div>
              </div>
            </div>

            <form
              onSubmit={handleSendBroadcast}
              className="p-4 border-t bg-white relative"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              {isDragging && (
                <div className="absolute inset-0 bg-blue-500 bg-opacity-20 border-4 border-blue-500 border-dashed rounded-lg z-10 flex items-center justify-center pointer-events-none">
                  <div className="bg-white px-6 py-4 rounded-lg shadow-lg">
                    <p className="text-lg font-bold text-blue-600">画像をドロップして添付</p>
                  </div>
                </div>
              )}
              {selectedImage && (
                <div className="mb-3 relative inline-block">
                  <img
                    src={selectedImage.url}
                    alt={selectedImage.name}
                    className="max-h-32 rounded-lg border border-gray-300"
                  />
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <XIcon className="w-4 h-4" />
                  </button>
                </div>
              )}
              <div className="flex gap-2 items-end">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-shrink-0 p-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                  title="画像を添付"
                >
                  <ImageIcon className="w-5 h-5" />
                </button>
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendBroadcast(e);
                    }
                  }}
                  placeholder="メッセージを入力... (Shift+Enterで改行)"
                  className="flex-1 min-w-0 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  maxLength={10000}
                  rows={3}
                />
                <button
                  type="submit"
                  disabled={(!newMessage.trim() && !selectedImage) || isSendingBroadcast}
                  className="flex-shrink-0 p-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  title="一斉送信"
                >
                  {isSendingBroadcast ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <Users className="w-5 h-5" />
                      <span className="hidden sm:inline">送信</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </>
        ) : null}
      </div>
    </div>
    </>
  );
}

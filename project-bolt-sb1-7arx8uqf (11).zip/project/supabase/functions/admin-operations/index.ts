import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const ADMIN_PASSWORD = 'admin123';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    // Use service role key to bypass RLS
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      },
      db: {
        schema: 'public'
      }
    });

    const { action, password, adminId, ...params } = await req.json();

    // Verify admin password
    if (password !== ADMIN_PASSWORD) {
      return new Response(
        JSON.stringify({ error: 'Invalid admin password' }),
        {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Verify user is admin
    const { data: admin } = await supabase
      .from('anonymous_users')
      .select('is_admin')
      .eq('id', adminId)
      .maybeSingle();

    if (!admin || !admin.is_admin) {
      return new Response(
        JSON.stringify({ error: 'User is not an admin' }),
        {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    let result;

    switch (action) {
      case 'block_ip': {
        const { ipAddress, reason } = params;

        if (ipAddress === 'unknown' || ipAddress.startsWith('temp_')) {
          return new Response(
            JSON.stringify({ error: 'Cannot block invalid or temporary IP addresses' }),
            {
              status: 400,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            }
          );
        }

        // Check if IP is already blocked
        const { data: existing } = await supabase
          .from('ip_blocks')
          .select('id')
          .eq('ip_address', ipAddress)
          .maybeSingle();

        if (!existing) {
          const { error: blockError } = await supabase
            .from('ip_blocks')
            .insert({
              ip_address: ipAddress,
              blocked_by: adminId,
              reason: reason || ''
            });

          if (blockError) {
            throw blockError;
          }
        }

        // Log the action
        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'block_ip',
          target_ip: ipAddress,
          details: { reason }
        });

        result = { success: true };
        break;
      }

      case 'unblock_ip': {
        const { ipAddress } = params;
        
        const { error: unblockError } = await supabase
          .from('ip_blocks')
          .delete()
          .eq('ip_address', ipAddress);

        if (unblockError) throw unblockError;

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'unblock_ip',
          target_ip: ipAddress,
          details: {}
        });

        result = { success: true };
        break;
      }

      case 'delete_message': {
        const { messageId } = params;
        
        const { error: deleteError } = await supabase
          .from('messages')
          .update({
            deleted_at: new Date().toISOString(),
            deleted_by: adminId
          })
          .eq('id', messageId);

        if (deleteError) throw deleteError;

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'delete_message',
          details: { message_id: messageId }
        });

        result = { success: true };
        break;
      }

      case 'delete_messages': {
        const { messageIds } = params;
        
        const { error: deleteError } = await supabase
          .from('messages')
          .update({
            deleted_at: new Date().toISOString(),
            deleted_by: adminId
          })
          .in('id', messageIds);

        if (deleteError) throw deleteError;

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'delete_messages',
          details: { message_ids: messageIds, count: messageIds.length }
        });

        result = { success: true };
        break;
      }

      case 'promote_admin': {
        const { userId } = params;

        const { error: promoteError } = await supabase
          .from('anonymous_users')
          .update({ is_admin: true })
          .eq('id', userId);

        if (promoteError) throw promoteError;

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'promote_admin',
          target_user_id: userId,
          details: {}
        });

        result = { success: true };
        break;
      }

      case 'block_device': {
        const { deviceId, reason } = params;

        if (!deviceId || deviceId.startsWith('temp_')) {
          return new Response(
            JSON.stringify({ error: '一時的なデバイスIDはブロックできません' }),
            {
              status: 400,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            }
          );
        }

        // Check if device is already blocked
        const { data: existing } = await supabase
          .from('device_blocks')
          .select('id')
          .eq('device_id', deviceId)
          .maybeSingle();

        if (!existing) {
          const { error: blockError } = await supabase
            .from('device_blocks')
            .insert({
              device_id: deviceId,
              blocked_by: adminId,
              reason: reason || ''
            });

          if (blockError) {
            throw blockError;
          }
        }

        // Log the action
        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'block_device',
          details: { device_id: deviceId, reason }
        });

        result = { success: true };
        break;
      }

      case 'unblock_device': {
        const { deviceId } = params;

        const { error: unblockError } = await supabase
          .from('device_blocks')
          .delete()
          .eq('device_id', deviceId);

        if (unblockError) throw unblockError;

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'unblock_device',
          details: { device_id: deviceId }
        });

        result = { success: true };
        break;
      }

      case 'block_by_name': {
        const { displayName, reason } = params;

        if (!displayName || displayName.trim() === '') {
          return new Response(
            JSON.stringify({ error: '表示名を入力してください' }),
            {
              status: 400,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            }
          );
        }

        const { data: users, error: searchError } = await supabase
          .from('anonymous_users')
          .select('id, device_id, display_name')
          .eq('display_name', displayName);

        if (searchError) throw searchError;

        if (!users || users.length === 0) {
          return new Response(
            JSON.stringify({ error: `「${displayName}」というユーザーが見つかりませんでした` }),
            {
              status: 404,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            }
          );
        }

        let blockedCount = 0;
        const blockedDevices: string[] = [];

        for (const user of users) {
          if (user.device_id.startsWith('temp_')) {
            continue;
          }

          const { data: existing } = await supabase
            .from('device_blocks')
            .select('id')
            .eq('device_id', user.device_id)
            .maybeSingle();

          if (!existing) {
            const { error: blockError } = await supabase
              .from('device_blocks')
              .insert({
                device_id: user.device_id,
                blocked_by: adminId,
                reason: reason || `名前「${displayName}」でブロック`
              });

            if (!blockError) {
              blockedCount++;
              blockedDevices.push(user.device_id);
            }
          }
        }

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'block_by_name',
          details: {
            display_name: displayName,
            reason,
            blocked_count: blockedCount,
            blocked_devices: blockedDevices
          }
        });

        result = {
          success: true,
          blockedCount,
          totalFound: users.length,
          message: `「${displayName}」というユーザー ${blockedCount}人をブロックしました`
        };
        break;
      }

      case 'block_display_name': {
        const { displayName, reason } = params;

        if (!displayName || displayName.trim() === '') {
          return new Response(
            JSON.stringify({ error: '表示名を入力してください' }),
            {
              status: 400,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            }
          );
        }

        const { data: existing } = await supabase
          .from('blocked_display_names')
          .select('id')
          .eq('display_name', displayName)
          .maybeSingle();

        if (existing) {
          return new Response(
            JSON.stringify({ error: 'この名前は既にブロックリストに登録されています' }),
            {
              status: 400,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            }
          );
        }

        const { error: blockError } = await supabase
          .from('blocked_display_names')
          .insert({
            display_name: displayName,
            blocked_by: adminId,
            reason: reason || ''
          });

        if (blockError) throw blockError;

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'block_display_name',
          details: { display_name: displayName, reason }
        });

        result = { success: true };
        break;
      }

      case 'unblock_display_name': {
        const { displayName } = params;

        const { error: unblockError } = await supabase
          .from('blocked_display_names')
          .delete()
          .eq('display_name', displayName);

        if (unblockError) throw unblockError;

        await supabase.from('audit_logs').insert({
          admin_id: adminId,
          action_type: 'unblock_display_name',
          details: { display_name: displayName }
        });

        result = { success: true };
        break;
      }

      default:
        return new Response(
          JSON.stringify({ error: 'Invalid action' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
    }

    return new Response(
      JSON.stringify(result),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Admin operation error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
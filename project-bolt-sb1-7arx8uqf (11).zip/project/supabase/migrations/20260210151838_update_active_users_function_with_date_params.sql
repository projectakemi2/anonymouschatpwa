/*
  # Update RPC function to accept date range parameters

  1. Changes
    - Modify `get_active_users_without_reply()` function to accept optional date parameters
    - Add `start_date` parameter (default: CURRENT_DATE)
    - Add `end_date` parameter (default: CURRENT_DATE + 1 day)
    - Allow filtering users who logged in within the specified date range
    - Maintain backward compatibility by using current date as default

  2. Purpose
    - Enable admins to send broadcasts to users who logged in on specific dates
    - Support date range queries for more flexible user targeting
    - Help identify users from previous days who haven't replied
*/

CREATE OR REPLACE FUNCTION get_active_users_without_reply(
  start_date timestamp with time zone DEFAULT CURRENT_DATE,
  end_date timestamp with time zone DEFAULT (CURRENT_DATE + interval '1 day')
)
RETURNS TABLE (
  id uuid,
  display_name text
) 
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    au.id,
    au.display_name
  FROM anonymous_users au
  LEFT JOIN (
    SELECT sender_id, COUNT(*) as count
    FROM direct_messages
    GROUP BY sender_id
  ) dm_count ON au.id = dm_count.sender_id
  WHERE au.last_seen_at >= start_date
    AND au.last_seen_at < end_date
    AND COALESCE(dm_count.count, 0) = 0
    AND au.is_admin = false
  ORDER BY au.last_seen_at DESC;
$$;

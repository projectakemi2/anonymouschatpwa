/*
  # device_analyticsテーブルにフィンガープリント情報を追加

  1. 新規カラムの追加
    - `canvas_fingerprint` (text) - Canvas fingerprint
    - `webgl_fingerprint` (text) - WebGL fingerprint
    - `screen_resolution` (text) - 画面解像度
    - `color_depth` (text) - 色深度
    - `timezone` (text) - タイムゾーン
    - `languages` (text) - ブラウザ言語
    - `hardware_concurrency` (integer) - CPUコア数
    - `device_memory` (integer) - デバイスメモリ
    - `touch_support` (boolean) - タッチサポート
    - `device_fingerprint_hash` (text) - デバイスフィンガープリントハッシュ

  2. 目的
    - より詳細なデバイス追跡
    - 分析精度の向上
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'canvas_fingerprint'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN canvas_fingerprint text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'webgl_fingerprint'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN webgl_fingerprint text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'screen_resolution'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN screen_resolution text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'color_depth'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN color_depth text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'timezone'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN timezone text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'languages'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN languages text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'hardware_concurrency'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN hardware_concurrency integer DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'device_memory'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN device_memory integer DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'touch_support'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN touch_support boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'device_analytics' AND column_name = 'device_fingerprint_hash'
  ) THEN
    ALTER TABLE device_analytics ADD COLUMN device_fingerprint_hash text DEFAULT '';
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_device_analytics_canvas_fp ON device_analytics(canvas_fingerprint);
CREATE INDEX IF NOT EXISTS idx_device_analytics_webgl_fp ON device_analytics(webgl_fingerprint);
CREATE INDEX IF NOT EXISTS idx_device_analytics_device_fp_hash ON device_analytics(device_fingerprint_hash);

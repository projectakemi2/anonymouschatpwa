/*
  # Add Device ID Blocking Support

  1. New Tables
    - `device_blocks`
      - `id` (uuid, primary key) - Block record identifier
      - `device_id` (text, unique) - Blocked device ID
      - `blocked_by` (uuid, foreign key) - Admin who blocked
      - `reason` (text) - Block reason
      - `created_at` (timestamptz) - Block timestamp

  2. Security
    - Enable RLS on `device_blocks` table
    - Anyone can view device blocks
    - Only admins can insert/delete device blocks

  3. Changes
    - Add function to check device blocks in message policy
*/

-- Create device_blocks table
CREATE TABLE IF NOT EXISTS device_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  blocked_by uuid NOT NULL REFERENCES anonymous_users(id),
  reason text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_device_blocks_device_id ON device_blocks(device_id);

-- Enable Row Level Security
ALTER TABLE device_blocks ENABLE ROW LEVEL SECURITY;

-- RLS Policies for device_blocks
CREATE POLICY "Anyone can view device blocks"
  ON device_blocks FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert device blocks"
  ON device_blocks FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true
    )
  );

CREATE POLICY "Admins can delete device blocks"
  ON device_blocks FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true
    )
  );

-- Update messages insert policy to also check device blocks
DROP POLICY IF EXISTS "Users can insert messages" ON messages;

CREATE POLICY "Users can insert messages"
  ON messages FOR INSERT
  WITH CHECK (
    NOT EXISTS (
      SELECT 1 FROM ip_blocks
      WHERE ip_blocks.ip_address = messages.ip_address
    )
    AND NOT EXISTS (
      SELECT 1 FROM device_blocks
      JOIN anonymous_users ON anonymous_users.device_id = device_blocks.device_id
      WHERE anonymous_users.id = messages.user_id
    )
  );

-- Enable Realtime for device_blocks table
ALTER PUBLICATION supabase_realtime ADD TABLE device_blocks;

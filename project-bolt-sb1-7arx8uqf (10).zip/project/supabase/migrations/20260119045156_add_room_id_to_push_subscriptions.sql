/*
  # プッシュ通知サブスクリプションに部屋ID追加

  1. 変更内容
    - `push_subscriptions`テーブルに`room_id`カラムを追加
    - デフォルト値は'default'（既存レコードのため）
    - インデックスを追加してパフォーマンス向上
  
  2. 理由
    - 部屋ごとに通知登録者を分けるため
    - 特定の部屋のユーザーのみに通知を送信できるようにする
  
  3. 注意事項
    - 既存のサブスクリプションは自動的に'default'部屋に割り当てられます
*/

-- room_idカラムを追加
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'room_id'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN room_id text NOT NULL DEFAULT 'default';
  END IF;
END $$;

-- room_idのインデックスを追加
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_room_id ON push_subscriptions(room_id);

-- room_idとuser_idの複合インデックス（特定の部屋の特定ユーザーの検索を高速化）
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_room_user ON push_subscriptions(room_id, user_id);
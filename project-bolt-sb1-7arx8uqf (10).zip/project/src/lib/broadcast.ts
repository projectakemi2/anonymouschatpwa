export async function sendBroadcastNotification(
  title: string = '新着メッセージ',
  message: string = '新しいメッセージがあります。チェックしてください！',
  roomId: string = 'default'
): Promise<{ success: boolean; sent: number; total: number; message: string }> {
  try {
    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/broadcast-notification`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          title,
          message,
          room_id: roomId,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || '通知の送信に失敗しました');
    }

    return await response.json();
  } catch (error) {
    console.error('Error sending broadcast notification:', error);
    throw error;
  }
}

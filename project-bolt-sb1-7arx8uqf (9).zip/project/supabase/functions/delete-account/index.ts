import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      },
      db: {
        schema: 'public'
      }
    });

    const { userId, deviceId } = await req.json();

    if (!userId || !deviceId) {
      return new Response(
        JSON.stringify({ error: 'ユーザーIDとデバイスIDが必要です' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Verify user exists and device_id matches
    const { data: user, error: userError } = await supabase
      .from('anonymous_users')
      .select('id, device_id, display_name')
      .eq('id', userId)
      .eq('device_id', deviceId)
      .maybeSingle();

    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'ユーザーが見つからないか、デバイスIDが一致しません' }),
        {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Delete or nullify audit logs first to avoid foreign key constraint errors
    await supabase
      .from('audit_logs')
      .update({ admin_id: null })
      .eq('admin_id', userId);

    // Nullify deleted_by references in messages
    await supabase
      .from('messages')
      .update({ deleted_by: null })
      .eq('deleted_by', userId);

    // Delete push subscriptions (will CASCADE delete notification_events)
    await supabase
      .from('push_subscriptions')
      .delete()
      .eq('user_id', userId);

    // Keep messages but nullify user_id (messages remain visible after account deletion)
    await supabase
      .from('messages')
      .update({ user_id: null })
      .eq('user_id', userId);

    // Delete rate limits
    await supabase
      .from('rate_limits')
      .delete()
      .eq('user_id', userId);

    // If user is admin, remove their blocks
    await supabase
      .from('ip_blocks')
      .delete()
      .eq('blocked_by', userId);

    await supabase
      .from('device_blocks')
      .delete()
      .eq('blocked_by', userId);

    // Finally delete user
    const { error: deleteError } = await supabase
      .from('anonymous_users')
      .delete()
      .eq('id', userId)
      .eq('device_id', deviceId);

    if (deleteError) {
      throw deleteError;
    }

    return new Response(
      JSON.stringify({ success: true, message: '退会が完了しました' }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Delete account error:', error);
    return new Response(
      JSON.stringify({ error: error.message || '退会処理に失敗しました' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

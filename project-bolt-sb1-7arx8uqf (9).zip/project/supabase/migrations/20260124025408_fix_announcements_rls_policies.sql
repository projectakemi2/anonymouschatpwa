/*
  # アナウンステーブルのRLSポリシーを修正

  1. 変更内容
    - 既存のRLSポリシーを削除
    - 匿名ユーザーシステムに対応した新しいポリシーを作成
    - `TO authenticated` と `auth.uid()` を削除
    - シンプルな条件ベースのポリシーに変更

  2. 新しいポリシー
    - 誰でもアクティブなアナウンスを閲覧可能
    - 管理者のみが全てのアナウンスを閲覧可能
    - 管理者のみが作成・更新・削除可能
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view active announcements" ON announcements;
DROP POLICY IF EXISTS "Admins can view all announcements" ON announcements;
DROP POLICY IF EXISTS "Admins can create announcements" ON announcements;
DROP POLICY IF EXISTS "Admins can update announcements" ON announcements;
DROP POLICY IF EXISTS "Admins can delete announcements" ON announcements;

-- Policy: Everyone can view active announcements
CREATE POLICY "Anyone can view active announcements"
  ON announcements
  FOR SELECT
  USING (is_active = true);

-- Policy: Admins can view all announcements
CREATE POLICY "Admins can view all announcements"
  ON announcements
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true
    )
  );

-- Policy: Admins can insert announcements
CREATE POLICY "Admins can create announcements"
  ON announcements
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = created_by
      AND anonymous_users.is_admin = true
    )
  );

-- Policy: Admins can update announcements
CREATE POLICY "Admins can update announcements"
  ON announcements
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users au
      WHERE au.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users au
      WHERE au.is_admin = true
    )
  );

-- Policy: Admins can delete announcements
CREATE POLICY "Admins can delete announcements"
  ON announcements
  FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users au
      WHERE au.is_admin = true
    )
  );
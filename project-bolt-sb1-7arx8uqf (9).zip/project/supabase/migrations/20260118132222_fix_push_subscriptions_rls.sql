/*
  # プッシュ通知サブスクリプションのRLSポリシー修正

  1. 問題
    - 現在のポリシーはJWTベースで、匿名ユーザーでは機能しない
    - 匿名ユーザーはJWTトークンを持っていない

  2. 修正内容
    - すべての匿名ユーザー（anon role）に対して、自由にINSERT/UPDATE/DELETE可能に変更
    - Service roleは引き続き全アクセス可能
    - SELECTは管理者機能のため、広く許可

  3. セキュリティ
    - 匿名ユーザーは自分のuser_idを知っている必要がある
    - エンドポイント（endpoint）でユニーク制約があるため重複登録は防止される
*/

DROP POLICY IF EXISTS "Users can create own subscriptions" ON push_subscriptions;
DROP POLICY IF EXISTS "Users can update own subscriptions" ON push_subscriptions;
DROP POLICY IF EXISTS "Users can delete own subscriptions" ON push_subscriptions;
DROP POLICY IF EXISTS "Users can view own subscriptions" ON push_subscriptions;

CREATE POLICY "Anyone can insert push subscriptions"
  ON push_subscriptions FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update push subscriptions"
  ON push_subscriptions FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete push subscriptions"
  ON push_subscriptions FOR DELETE
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can view push subscriptions"
  ON push_subscriptions FOR SELECT
  TO anon, authenticated
  USING (true);

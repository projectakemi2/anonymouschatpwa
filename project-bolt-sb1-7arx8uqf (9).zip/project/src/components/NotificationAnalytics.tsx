import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Users, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface SubscriptionStats {
  total_subscriptions: number;
  active_subscriptions: number;
  inactive_subscriptions: number;
  avg_health_score: number;
  avg_engagement_rate: number;
  total_sent: number;
  total_delivered: number;
  total_clicked: number;
  total_dismissed: number;
}

interface TopSubscription {
  id: string;
  user_id: string;
  health_score: number;
  engagement_rate: number;
  total_sent: number;
  success_count: number;
  total_clicked: number;
  created_at: string;
}

export default function NotificationAnalytics() {
  const [stats, setStats] = useState<SubscriptionStats | null>(null);
  const [topSubscriptions, setTopSubscriptions] = useState<TopSubscription[]>([]);
  const [lowHealthSubscriptions, setLowHealthSubscriptions] = useState<TopSubscription[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const { data: subscriptions } = await supabase
        .from('push_subscriptions')
        .select('*');

      if (subscriptions) {
        const active = subscriptions.filter(s => s.is_active);
        const inactive = subscriptions.filter(s => !s.is_active);

        const totalSent = subscriptions.reduce((sum, s) => sum + (s.total_sent || 0), 0);
        const totalDelivered = subscriptions.reduce((sum, s) => sum + (s.success_count || 0), 0);
        const totalClicked = subscriptions.reduce((sum, s) => sum + (s.total_clicked || 0), 0);
        const totalDismissed = subscriptions.reduce((sum, s) => sum + (s.total_dismissed || 0), 0);

        const avgHealth = active.length > 0
          ? active.reduce((sum, s) => sum + (parseFloat(s.health_score) || 0), 0) / active.length
          : 0;

        const avgEngagement = active.length > 0
          ? active.reduce((sum, s) => sum + (parseFloat(s.engagement_rate) || 0), 0) / active.length
          : 0;

        setStats({
          total_subscriptions: subscriptions.length,
          active_subscriptions: active.length,
          inactive_subscriptions: inactive.length,
          avg_health_score: avgHealth,
          avg_engagement_rate: avgEngagement,
          total_sent: totalSent,
          total_delivered: totalDelivered,
          total_clicked: totalClicked,
          total_dismissed: totalDismissed
        });

        const sortedByEngagement = [...active]
          .filter(s => (s.total_sent || 0) > 5)
          .sort((a, b) => (parseFloat(b.engagement_rate) || 0) - (parseFloat(a.engagement_rate) || 0))
          .slice(0, 10);
        setTopSubscriptions(sortedByEngagement);

        const lowHealth = [...subscriptions]
          .filter(s => (parseFloat(s.health_score) || 0) < 50 && s.is_active)
          .sort((a, b) => (parseFloat(a.health_score) || 0) - (parseFloat(b.health_score) || 0))
          .slice(0, 10);
        setLowHealthSubscriptions(lowHealth);
      }
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!stats) return null;

  const deliveryRate = stats.total_sent > 0
    ? ((stats.total_delivered / stats.total_sent) * 100).toFixed(1)
    : '0.0';

  const clickRate = stats.total_delivered > 0
    ? ((stats.total_clicked / stats.total_delivered) * 100).toFixed(1)
    : '0.0';

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Subscriptions</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total_subscriptions}</p>
            </div>
            <Users className="w-8 h-8 text-blue-500" />
          </div>
          <div className="mt-2 flex items-center text-sm">
            <CheckCircle className="w-4 h-4 text-green-500 mr-1" />
            <span className="text-green-600">{stats.active_subscriptions} active</span>
            <XCircle className="w-4 h-4 text-red-500 ml-3 mr-1" />
            <span className="text-red-600">{stats.inactive_subscriptions} inactive</span>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Health Score</p>
              <p className="text-2xl font-bold text-gray-900">{stats.avg_health_score.toFixed(1)}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-green-500" />
          </div>
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-500 h-2 rounded-full"
                style={{ width: `${stats.avg_health_score}%` }}
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Delivery Rate</p>
              <p className="text-2xl font-bold text-gray-900">{deliveryRate}%</p>
            </div>
            <CheckCircle className="w-8 h-8 text-purple-500" />
          </div>
          <div className="mt-2 text-sm text-gray-600">
            {stats.total_delivered} / {stats.total_sent} sent
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Click Rate</p>
              <p className="text-2xl font-bold text-gray-900">{clickRate}%</p>
            </div>
            <TrendingUp className="w-8 h-8 text-orange-500" />
          </div>
          <div className="mt-2 text-sm text-gray-600">
            {stats.total_clicked} clicks
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow">
          <div className="p-4 border-b">
            <h3 className="font-semibold text-gray-900 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-green-500" />
              Top Performing Subscriptions
            </h3>
          </div>
          <div className="p-4">
            {topSubscriptions.length === 0 ? (
              <p className="text-gray-500 text-sm">No data available</p>
            ) : (
              <div className="space-y-2">
                {topSubscriptions.map((sub) => (
                  <div key={sub.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">
                        {sub.user_id.substring(0, 8)}...
                      </p>
                      <p className="text-xs text-gray-500">
                        {sub.total_clicked}/{sub.total_sent} clicks
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-green-600">
                        {parseFloat(sub.engagement_rate).toFixed(1)}%
                      </p>
                      <p className="text-xs text-gray-500">
                        Health: {parseFloat(sub.health_score).toFixed(0)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="p-4 border-b">
            <h3 className="font-semibold text-gray-900 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
              Low Health Subscriptions
            </h3>
          </div>
          <div className="p-4">
            {lowHealthSubscriptions.length === 0 ? (
              <p className="text-gray-500 text-sm">All subscriptions healthy!</p>
            ) : (
              <div className="space-y-2">
                {lowHealthSubscriptions.map((sub) => (
                  <div key={sub.id} className="flex items-center justify-between p-3 bg-red-50 rounded">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">
                        {sub.user_id.substring(0, 8)}...
                      </p>
                      <p className="text-xs text-gray-500">
                        {sub.success_count}/{sub.total_sent} delivered
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-red-600">
                        {parseFloat(sub.health_score).toFixed(0)}
                      </p>
                      <p className="text-xs text-gray-500">health score</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

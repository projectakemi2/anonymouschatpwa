import { supabase } from './supabase';

export interface Campaign {
  id: string;
  name: string;
  subscriber_count: number;
  created_at: string;
}

export async function getCampaigns(): Promise<Campaign[]> {
  const { data, error } = await supabase
    .from('push_subscriptions')
    .select('campaign_id')
    .not('campaign_id', 'is', null);

  if (error) {
    console.error('Error fetching campaigns:', error);
    return [];
  }

  const campaignMap = new Map<string, number>();
  data?.forEach(sub => {
    if (sub.campaign_id) {
      campaignMap.set(sub.campaign_id, (campaignMap.get(sub.campaign_id) || 0) + 1);
    }
  });

  return Array.from(campaignMap.entries()).map(([id, count]) => ({
    id,
    name: `キャンペーン: ${id}`,
    subscriber_count: count,
    created_at: new Date().toISOString()
  }));
}

export async function sendCampaignNotification(
  campaignId: string,
  title: string,
  body: string
): Promise<{ sent: number; total: number; failed: number }> {
  const { data: subscriptions, error } = await supabase
    .from('push_subscriptions')
    .select('*')
    .eq('campaign_id', campaignId);

  if (error) {
    throw new Error(`通知の取得に失敗: ${error.message}`);
  }

  if (!subscriptions || subscriptions.length === 0) {
    return { sent: 0, total: 0, failed: 0 };
  }

  const results = await Promise.allSettled(
    subscriptions.map(async (subscription) => {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-push-notification`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            subscriptionId: subscription.id,
            title,
            body,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to send notification: ${response.statusText}`);
      }

      return response.json();
    })
  );

  const sent = results.filter(r => r.status === 'fulfilled').length;
  const failed = results.filter(r => r.status === 'rejected').length;

  return { sent, total: subscriptions.length, failed };
}

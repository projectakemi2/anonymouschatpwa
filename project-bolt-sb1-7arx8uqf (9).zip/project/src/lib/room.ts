import { supabase } from './supabase';

export interface Room {
  id: string;
  name: string;
  created_at: string;
  created_by: string;
}

export type URLFormat = 'hash' | 'query' | 'path';

export function getRoomIdFromURL(): string {
  const hash = window.location.hash.slice(1);
  if (hash) return hash;

  const params = new URLSearchParams(window.location.search);
  const queryRoom = params.get('room');
  if (queryRoom) return queryRoom;

  const path = window.location.pathname;
  const pathMatch = path.match(/\/([^\/]+)$/);
  if (pathMatch && pathMatch[1] && pathMatch[1] !== 'index.html') {
    return pathMatch[1];
  }

  return 'default';
}

export function getCurrentRoomId(): string {
  return getRoomIdFromURL();
}

export function generateRoomId(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 12; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export async function createRoom(name: string, createdBy: string = ''): Promise<Room> {
  const roomId = generateRoomId();

  const { data, error } = await supabase
    .from('rooms')
    .insert({
      id: roomId,
      name,
      created_by: createdBy
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function getRoom(roomId: string): Promise<Room | null> {
  const { data } = await supabase
    .from('rooms')
    .select('*')
    .eq('id', roomId)
    .maybeSingle();

  return data;
}

export async function getAllRooms(): Promise<Room[]> {
  const { data, error } = await supabase
    .from('rooms')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function getRoomName(roomId: string): Promise<string> {
  if (roomId === 'default') {
    return '参加者オープンチャット';
  }

  if (roomId === 'chat10') {
    return '参加者チャット１０';
  }

  const room = await getRoom(roomId);
  return room?.name || `チャットルーム (${roomId})`;
}

export function getCurrentRoomName(): string {
  const roomId = getCurrentRoomId();
  if (roomId === 'default') {
    return '参加者オープンチャット';
  }

  if (roomId === 'chat10') {
    return '参加者チャット１０';
  }

  return `チャットルーム (${roomId})`;
}

export function getRoomURL(roomId: string, format: URLFormat = 'hash'): string {
  const productionURL = import.meta.env.VITE_APP_URL || window.location.origin;
  const baseURL = productionURL.replace(/\/$/, '');

  if (roomId === 'default') {
    return baseURL;
  }

  switch (format) {
    case 'hash':
      return `${baseURL}#${roomId}`;
    case 'query':
      return `${baseURL}?room=${roomId}`;
    case 'path':
      return `${baseURL}/${roomId}`;
    default:
      return `${baseURL}#${roomId}`;
  }
}

export function getFormatLabel(format: URLFormat): string {
  switch (format) {
    case 'hash':
      return 'ハッシュ形式 (#roomId)';
    case 'query':
      return 'クエリ形式 (?room=roomId)';
    case 'path':
      return 'パス形式 (/roomId)';
    default:
      return 'ハッシュ形式';
  }
}

export function getFormatDescription(format: URLFormat): string {
  switch (format) {
    case 'hash':
      return '推奨：最も互換性が高い形式';
    case 'query':
      return '標準的なクエリパラメータ形式';
    case 'path':
      return '試験的：一部の環境で動作しない可能性';
    default:
      return '';
  }
}

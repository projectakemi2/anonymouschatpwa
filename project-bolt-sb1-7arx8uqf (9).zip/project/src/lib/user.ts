import { supabase } from './supabase';
import { generateDeviceId, getClientIP, getDeviceInfo } from './device';

export interface AnonymousUser {
  id: string;
  device_id: string;
  display_name: string;
  ip_address: string;
  is_admin: boolean;
  is_visible: boolean;
  created_at: string;
  last_seen_at: string;
  user_agent?: string;
  platform?: string;
  os_version?: string;
  browser?: string;
  browser_version?: string;
  is_pwa?: boolean;
}

const ADMIN_PASSWORD = 'admin123';

export async function registerAnonymousUser(displayName: string, adminPassword?: string): Promise<AnonymousUser> {
  const deviceId = generateDeviceId();
  const isAdmin = adminPassword === ADMIN_PASSWORD;

  const ipAddress = await getClientIP();

  if (ipAddress !== 'unknown' && !ipAddress.startsWith('temp_')) {
    const { data: blocked } = await supabase
      .from('ip_blocks')
      .select('*')
      .eq('ip_address', ipAddress)
      .maybeSingle();

    if (blocked) {
      throw new Error('このIPアドレスはブロックされています');
    }
  }

  if (!deviceId.startsWith('temp_')) {
    const { data: deviceBlocked } = await supabase
      .from('device_blocks')
      .select('*')
      .eq('device_id', deviceId)
      .maybeSingle();

    if (deviceBlocked) {
      throw new Error('このデバイスはブロックされています');
    }
  }

  const { data: existingUser } = await supabase
    .from('anonymous_users')
    .select('*')
    .eq('device_id', deviceId)
    .maybeSingle();

  const deviceInfo = await getDeviceInfo();

  if (existingUser) {
    const updateData: any = {
      display_name: displayName,
      ip_address: ipAddress,
      last_seen_at: new Date().toISOString(),
      user_agent: deviceInfo.userAgent,
      platform: deviceInfo.platform,
      os_version: deviceInfo.osVersion,
      browser: deviceInfo.browser,
      browser_version: deviceInfo.browserVersion,
      is_pwa: deviceInfo.isStandalone,
      canvas_fingerprint: deviceInfo.canvasFingerprint,
      webgl_fingerprint: deviceInfo.webglFingerprint,
      screen_resolution: deviceInfo.screenResolution,
      color_depth: deviceInfo.colorDepth,
      timezone: deviceInfo.timezone,
      languages: deviceInfo.languages,
      hardware_concurrency: deviceInfo.hardwareConcurrency,
      device_memory: deviceInfo.deviceMemory,
      touch_support: deviceInfo.touchSupport,
      device_fingerprint_hash: deviceInfo.deviceFingerprintHash
    };

    if (isAdmin) {
      updateData.is_admin = true;
      updateData.is_visible = true;
    }

    const { data: updatedUser, error } = await supabase
      .from('anonymous_users')
      .update(updateData)
      .eq('device_id', deviceId)
      .select()
      .single();

    if (error) throw error;
    localStorage.setItem('current_user', JSON.stringify(updatedUser));
    return updatedUser;
  }

  const { data: newUser, error } = await supabase
    .from('anonymous_users')
    .insert({
      device_id: deviceId,
      display_name: displayName,
      ip_address: ipAddress,
      is_admin: isAdmin,
      is_visible: isAdmin,
      user_agent: deviceInfo.userAgent,
      platform: deviceInfo.platform,
      os_version: deviceInfo.osVersion,
      browser: deviceInfo.browser,
      browser_version: deviceInfo.browserVersion,
      is_pwa: deviceInfo.isStandalone,
      canvas_fingerprint: deviceInfo.canvasFingerprint,
      webgl_fingerprint: deviceInfo.webglFingerprint,
      screen_resolution: deviceInfo.screenResolution,
      color_depth: deviceInfo.colorDepth,
      timezone: deviceInfo.timezone,
      languages: deviceInfo.languages,
      hardware_concurrency: deviceInfo.hardwareConcurrency,
      device_memory: deviceInfo.deviceMemory,
      touch_support: deviceInfo.touchSupport,
      device_fingerprint_hash: deviceInfo.deviceFingerprintHash
    })
    .select()
    .single();

  if (error) throw error;

  localStorage.setItem('current_user', JSON.stringify(newUser));
  return newUser;
}

export function getCurrentUser(): AnonymousUser | null {
  const userStr = localStorage.getItem('current_user');
  if (!userStr) return null;

  try {
    return JSON.parse(userStr);
  } catch {
    return null;
  }
}

export async function validateCurrentUser(): Promise<AnonymousUser | null> {
  const user = getCurrentUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('anonymous_users')
    .select('*')
    .eq('id', user.id)
    .maybeSingle();

  if (error || !data) {
    clearCurrentUser();
    return null;
  }

  const ipAddress = await getClientIP();

  if (ipAddress !== 'unknown' && !ipAddress.startsWith('temp_')) {
    const { data: ipBlocked } = await supabase
      .from('ip_blocks')
      .select('id')
      .eq('ip_address', ipAddress)
      .maybeSingle();

    if (ipBlocked) {
      clearCurrentUser();
      throw new Error('このIPアドレスはブロックされています');
    }
  }

  if (data.device_id && !data.device_id.startsWith('temp_')) {
    const { data: deviceBlocked } = await supabase
      .from('device_blocks')
      .select('id')
      .eq('device_id', data.device_id)
      .maybeSingle();

    if (deviceBlocked) {
      clearCurrentUser();
      throw new Error('このデバイスはブロックされています');
    }
  }

  localStorage.setItem('current_user', JSON.stringify(data));
  return data;
}

export function clearCurrentUser(): void {
  localStorage.removeItem('current_user');
}

export async function updateLastSeen(userId: string): Promise<void> {
  await supabase
    .from('anonymous_users')
    .update({ last_seen_at: new Date().toISOString() })
    .eq('id', userId);
}

export async function checkIPBlocked(): Promise<boolean> {
  const ipAddress = await getClientIP();
  const { data } = await supabase
    .from('ip_blocks')
    .select('*')
    .eq('ip_address', ipAddress)
    .maybeSingle();

  return !!data;
}

export async function checkDeviceBlocked(): Promise<boolean> {
  const deviceId = generateDeviceId();
  if (deviceId.startsWith('temp_')) {
    return false;
  }

  const { data } = await supabase
    .from('device_blocks')
    .select('*')
    .eq('device_id', deviceId)
    .maybeSingle();

  return !!data;
}

export async function deleteAccount(userId: string): Promise<void> {
  const user = getCurrentUser();
  if (!user || user.id !== userId) {
    throw new Error('ユーザー情報が一致しません');
  }

  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-account`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      userId: user.id,
      deviceId: user.device_id
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || '退会に失敗しました');
  }

  clearCurrentUser();
}

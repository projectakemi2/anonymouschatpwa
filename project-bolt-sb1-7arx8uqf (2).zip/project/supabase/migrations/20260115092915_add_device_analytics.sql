/*
  # Add Device Analytics Table

  1. New Tables
    - device_analytics
      - id (uuid, primary key)
      - device_id (text) - unique device identifier
      - user_agent (text) - browser user agent string
      - platform (text) - OS platform (iOS, Android, Windows, etc.)
      - browser (text) - browser name
      - browser_version (text) - browser version
      - os_version (text) - OS version
      - is_standalone (boolean) - if app is in standalone mode
      - is_installable (boolean) - if beforeinstallprompt fired
      - install_button_shown (boolean) - if install button was shown
      - install_attempted (boolean) - if user clicked install
      - install_succeeded (boolean) - if install succeeded
      - event_type (text) - type of event (page_load, install_click, etc.)
      - error_message (text) - any error messages
      - ip_address (text) - client IP address
      - created_at (timestamptz)

  2. Security
    - Enable RLS on device_analytics table
    - Allow anyone to insert analytics data
    - Only allow authenticated users to read their own data
*/

CREATE TABLE IF NOT EXISTS device_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text NOT NULL,
  user_agent text DEFAULT '',
  platform text DEFAULT '',
  browser text DEFAULT '',
  browser_version text DEFAULT '',
  os_version text DEFAULT '',
  is_standalone boolean DEFAULT false,
  is_installable boolean DEFAULT false,
  install_button_shown boolean DEFAULT false,
  install_attempted boolean DEFAULT false,
  install_succeeded boolean DEFAULT false,
  event_type text DEFAULT '',
  error_message text DEFAULT '',
  ip_address text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE device_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert analytics"
  ON device_analytics FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read all analytics"
  ON device_analytics FOR SELECT
  TO authenticated
  USING (true);
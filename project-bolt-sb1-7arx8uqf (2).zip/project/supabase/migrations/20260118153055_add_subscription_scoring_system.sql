/*
  # Add Subscription Scoring System

  ## Overview
  Implements a comprehensive scoring and health tracking system for push notification subscriptions,
  similar to what professional adult sites and high-volume notification services use.

  ## Changes Made

  1. **New Columns Added to push_subscriptions**
     - `success_count` (integer): Number of successful notification deliveries
     - `total_sent` (integer): Total notifications sent to this subscription
     - `health_score` (numeric): Calculated health score (0-100)
     - `total_clicked` (integer): Number of times user clicked notifications
     - `total_dismissed` (integer): Number of times user dismissed without clicking
     - `engagement_rate` (numeric): Click-through rate percentage
     - `is_active` (boolean): Whether subscription is active (auto-disabled if health < 30)

  2. **New Table: notification_events**
     - Tracks all notification interactions (sent, delivered, clicked, dismissed)
     - Enables detailed analytics and engagement tracking
     - Links to campaigns and subscriptions

  3. **Health Score Calculation Function**
     - Automatically calculates subscription health based on:
       * Success rate (successful deliveries / total sent)
       * Recency (days since last success)
       * Engagement rate (clicks / total sent)
     - Formula: (success_rate * 40) + (engagement_rate * 40) + (recency_score * 20)

  4. **Auto-cleanup Trigger**
     - Automatically marks low-health subscriptions as inactive
     - Subscriptions with health_score < 30 are disabled
     - Runs after every stats update

  5. **Security**
     - RLS policies updated for new tables
     - Only authenticated users and service role can access

  ## Important Notes
  - Health scores are calculated automatically via database function
  - Low-scoring subscriptions (< 30) are auto-disabled to maintain delivery reputation
  - All notification events are logged for analytics
  - Engagement tracking enables A/B testing and optimization
*/

-- Add new scoring columns to push_subscriptions
DO $$
BEGIN
  -- success_count
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'success_count'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN success_count integer DEFAULT 0;
  END IF;

  -- total_sent
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'total_sent'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN total_sent integer DEFAULT 0;
  END IF;

  -- health_score
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'health_score'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN health_score numeric DEFAULT 100;
  END IF;

  -- total_clicked
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'total_clicked'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN total_clicked integer DEFAULT 0;
  END IF;

  -- total_dismissed
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'total_dismissed'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN total_dismissed integer DEFAULT 0;
  END IF;

  -- engagement_rate
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'engagement_rate'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN engagement_rate numeric DEFAULT 0;
  END IF;

  -- is_active
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'is_active'
  ) THEN
    ALTER TABLE push_subscriptions ADD COLUMN is_active boolean DEFAULT true;
  END IF;
END $$;

-- Create notification_events table for tracking
CREATE TABLE IF NOT EXISTS notification_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid REFERENCES push_subscriptions(id) ON DELETE CASCADE,
  campaign_id text,
  event_type text NOT NULL CHECK (event_type IN ('sent', 'delivered', 'clicked', 'dismissed', 'failed')),
  error_code text,
  created_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Enable RLS
ALTER TABLE notification_events ENABLE ROW LEVEL SECURITY;

-- RLS Policies for notification_events
CREATE POLICY "Service role can manage notification events"
  ON notification_events FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view their notification events"
  ON notification_events FOR SELECT
  TO authenticated
  USING (
    subscription_id IN (
      SELECT id FROM push_subscriptions WHERE user_id = auth.uid()
    )
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_notification_events_subscription 
  ON notification_events(subscription_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notification_events_campaign 
  ON notification_events(campaign_id, event_type);
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_health 
  ON push_subscriptions(health_score, is_active) WHERE is_active = true;

-- Function to calculate health score
CREATE OR REPLACE FUNCTION calculate_subscription_health(sub_id uuid)
RETURNS numeric AS $$
DECLARE
  success_rate numeric;
  recency_score numeric;
  engage_rate numeric;
  days_since_success integer;
  total integer;
  success_cnt integer;
BEGIN
  -- Get subscription stats
  SELECT 
    total_sent,
    success_count,
    engagement_rate,
    COALESCE(EXTRACT(DAY FROM (now() - last_success_at)), 0)
  INTO total, success_cnt, engage_rate, days_since_success
  FROM push_subscriptions
  WHERE id = sub_id;

  -- Avoid division by zero
  IF total = 0 OR total IS NULL THEN
    RETURN 100;
  END IF;

  -- Calculate success rate percentage
  success_rate := (COALESCE(success_cnt, 0)::numeric / total) * 100;

  -- Calculate recency score (decays over time)
  recency_score := GREATEST(0, 100 - (days_since_success * 5));

  -- Calculate final health score
  -- Formula: 40% success rate + 40% engagement + 20% recency
  RETURN LEAST(100, (success_rate * 0.4) + (COALESCE(engage_rate, 0) * 0.4) + (recency_score * 0.2));
END;
$$ LANGUAGE plpgsql;

-- Function to update subscription stats
CREATE OR REPLACE FUNCTION update_subscription_stats(
  sub_id uuid,
  event text,
  should_increment_failure boolean DEFAULT false
)
RETURNS void AS $$
BEGIN
  IF event = 'sent' THEN
    UPDATE push_subscriptions
    SET total_sent = total_sent + 1
    WHERE id = sub_id;
    
  ELSIF event = 'success' THEN
    UPDATE push_subscriptions
    SET 
      success_count = success_count + 1,
      last_success_at = now(),
      failure_count = 0  -- Reset failure count on success
    WHERE id = sub_id;
    
  ELSIF event = 'failed' AND should_increment_failure THEN
    UPDATE push_subscriptions
    SET failure_count = failure_count + 1
    WHERE id = sub_id;
    
  ELSIF event = 'clicked' THEN
    UPDATE push_subscriptions
    SET 
      total_clicked = total_clicked + 1,
      engagement_rate = CASE 
        WHEN total_sent > 0 THEN ((total_clicked + 1)::numeric / total_sent) * 100
        ELSE 0
      END
    WHERE id = sub_id;
    
  ELSIF event = 'dismissed' THEN
    UPDATE push_subscriptions
    SET total_dismissed = total_dismissed + 1
    WHERE id = sub_id;
  END IF;

  -- Recalculate health score
  UPDATE push_subscriptions
  SET health_score = calculate_subscription_health(sub_id)
  WHERE id = sub_id;

  -- Auto-disable if health is too low
  UPDATE push_subscriptions
  SET is_active = false
  WHERE id = sub_id AND health_score < 30;
END;
$$ LANGUAGE plpgsql;

-- Initialize existing subscriptions with default values
UPDATE push_subscriptions
SET 
  success_count = COALESCE(success_count, 0),
  total_sent = COALESCE(total_sent, 0),
  health_score = COALESCE(health_score, 100),
  total_clicked = COALESCE(total_clicked, 0),
  total_dismissed = COALESCE(total_dismissed, 0),
  engagement_rate = COALESCE(engagement_rate, 0),
  is_active = COALESCE(is_active, true)
WHERE success_count IS NULL OR total_sent IS NULL;
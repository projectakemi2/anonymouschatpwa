import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import webpush from 'npm:web-push@3.6.7';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PushSubscription {
  id: string;
  user_id: string;
  endpoint: string;
  p256dh: string;
  auth: string;
  failure_count: number;
  is_active: boolean;
  health_score: number;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function sendWebPushWithRetry(
  subscription: PushSubscription,
  basePayload: any,
  vapidPublicKey: string,
  vapidPrivateKey: string,
  supabase: any,
  campaignId?: string,
  maxRetries = 5
) {
  const payload = {
    ...basePayload,
    data: {
      ...basePayload.data,
      subscription_id: subscription.id
    }
  };

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const pushSubscription = {
        endpoint: subscription.endpoint,
        keys: {
          p256dh: subscription.p256dh,
          auth: subscription.auth,
        },
      };

      webpush.setVapidDetails(
        'mailto:admin@aiprojectakemi2.com',
        vapidPublicKey,
        vapidPrivateKey
      );

      await supabase.rpc('update_subscription_stats', {
        sub_id: subscription.id,
        event: 'sent',
        should_increment_failure: false
      });

      await supabase.from('notification_events').insert({
        subscription_id: subscription.id,
        campaign_id: campaignId,
        event_type: 'sent',
        metadata: { attempt: attempt + 1 }
      });

      await webpush.sendNotification(
        pushSubscription,
        JSON.stringify(payload)
      );

      await supabase.rpc('update_subscription_stats', {
        sub_id: subscription.id,
        event: 'success',
        should_increment_failure: false
      });

      await supabase.from('notification_events').insert({
        subscription_id: subscription.id,
        campaign_id: campaignId,
        event_type: 'delivered'
      });

      return { success: true, shouldIncrementFailure: false, errorCode: null };
    } catch (error: any) {
      console.error(`Push notification error (attempt ${attempt + 1}/${maxRetries}):`, {
        statusCode: error.statusCode,
        message: error.message,
        endpoint: subscription.endpoint,
        body: error.body
      });

      const isPermanentFailure = error.statusCode === 404 || error.statusCode === 410;
      const isRateLimitOrServerError = error.statusCode === 429 || error.statusCode === 503;

      await supabase.from('notification_events').insert({
        subscription_id: subscription.id,
        campaign_id: campaignId,
        event_type: 'failed',
        error_code: error.statusCode?.toString(),
        metadata: {
          attempt: attempt + 1,
          message: error.message,
          permanent: isPermanentFailure
        }
      });

      if (isPermanentFailure) {
        console.log(`Permanent failure (${error.statusCode}) - will increment failure count`);
        await supabase.rpc('update_subscription_stats', {
          sub_id: subscription.id,
          event: 'failed',
          should_increment_failure: true
        });

        await supabase.from('in_app_notifications').insert({
          user_id: subscription.user_id,
          title: payload.title,
          body: payload.body,
          url: payload.data?.url,
          icon: payload.icon,
          campaign_id: campaignId,
          metadata: {
            reason: 'push_failed',
            error_code: error.statusCode,
            fallback: true
          }
        });
        console.log('Created fallback in-app notification');

        return { success: false, shouldIncrementFailure: true, errorCode: error.statusCode };
      }

      if (attempt < maxRetries - 1) {
        const baseDelay = Math.pow(2, attempt) * 1000;
        const jitter = Math.random() * 1000;
        const delay = baseDelay + jitter;

        console.log(`Error (${error.statusCode || 'unknown'}) - retrying after ${delay.toFixed(0)}ms (attempt ${attempt + 1}/${maxRetries})`);
        await sleep(delay);
        continue;
      }

      console.log(`Error after ${maxRetries} attempts - creating fallback notification`);

      await supabase.from('in_app_notifications').insert({
        user_id: subscription.user_id,
        title: payload.title,
        body: payload.body,
        url: payload.data?.url,
        icon: payload.icon,
        campaign_id: campaignId,
        metadata: {
          reason: 'push_failed_after_retries',
          error_code: error.statusCode,
          attempts: maxRetries,
          fallback: true
        }
      });

      return { success: false, shouldIncrementFailure: false, errorCode: error.statusCode };
    }
  }

  return { success: false, shouldIncrementFailure: false, errorCode: null };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const vapidPublicKey = Deno.env.get('VAPID_PUBLIC_KEY') || 'BKyhAA-s_Lb4jQ4IsJugCLi0bE0oNR95PngSJnTfCwF0xs25v3czEhSKCbLGZktGFwmuGzy99HsaOX73KOWrVZI';
    const vapidPrivateKey = Deno.env.get('VAPID_PRIVATE_KEY') || '24BNMn0DkzABG1Q78ugR6k8XkvhFMhkmcuVHXgM4Ez0';

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { title, message, body, url, user_ids, campaign_id, room_id } = await req.json();

    let query = supabase.from('push_subscriptions').select('*').eq('is_active', true);

    if (room_id) {
      query = query.eq('room_id', room_id);
    }

    if (user_ids && Array.isArray(user_ids) && user_ids.length > 0) {
      query = query.in('user_id', user_ids);
    }

    const { data: subscriptions, error: subError } = await query;

    if (subError || !subscriptions || subscriptions.length === 0) {
      return new Response(
        JSON.stringify({ success: true, sent: 0, message: 'No subscriptions found' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    const payload = {
      title: title || '新着メッセージ',
      body: body || message || '新しいメッセージがあります。チェックしてください！',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      data: {
        url: url || '/',
        timestamp: Date.now(),
        campaign_id: campaign_id,
      },
    };

    let sentCount = 0;
    const toDelete: string[] = [];

    const chunkSize = 10;

    for (let i = 0; i < subscriptions.length; i += chunkSize) {
      const chunk = subscriptions.slice(i, i + chunkSize);

      const results = await Promise.allSettled(
        chunk.map(sub => sendWebPushWithRetry(sub, payload, vapidPublicKey, vapidPrivateKey, supabase, campaign_id))
      );

      results.forEach((result, index) => {
        const sub = chunk[index];

        if (result.status === 'fulfilled' && result.value.success) {
          sentCount++;
        } else if (result.status === 'fulfilled' && result.value.shouldIncrementFailure) {
          const newFailureCount = (sub.failure_count || 0) + 1;

          if (newFailureCount >= 5) {
            toDelete.push(sub.id);
          }
        }
      });

      if (i + chunkSize < subscriptions.length) {
        await sleep(500);
      }
    }

    if (toDelete.length > 0) {
      await supabase
        .from('push_subscriptions')
        .delete()
        .in('id', toDelete);
    }

    return new Response(
      JSON.stringify({
        success: true,
        sent: sentCount,
        total: subscriptions.length,
        message: `${sentCount}件の通知を送信しました`
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

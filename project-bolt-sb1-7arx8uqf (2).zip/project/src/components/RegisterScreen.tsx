import { useState } from 'react';
import { MessageCircle, AlertCircle } from 'lucide-react';
import { registerAnonymousUser, checkIPBlocked, checkDeviceBlocked } from '../lib/user';
import { requestNotificationPermission } from '../lib/notification';
import { subscribeToPushNotifications } from '../lib/push';
import { getCurrentRoomName } from '../lib/room';
import InstallBanner from './InstallBanner';

interface RegisterScreenProps {
  onRegistered: () => void;
  roomId?: string;
}

export default function RegisterScreen({ onRegistered, roomId = 'default' }: RegisterScreenProps) {
  const [displayName, setDisplayName] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!displayName.trim()) {
      setError('表示名を入力してください');
      return;
    }

    if (displayName.length > 20) {
      setError('表示名は20文字以内で入力してください');
      return;
    }

    setLoading(true);

    try {
      const isIPBlocked = await checkIPBlocked();
      if (isIPBlocked) {
        setError('このIPアドレスはブロックされています');
        setLoading(false);
        return;
      }

      const isDeviceBlocked = await checkDeviceBlocked();
      if (isDeviceBlocked) {
        setError('このデバイスはブロックされています');
        setLoading(false);
        return;
      }

      const user = await registerAnonymousUser(displayName.trim(), adminPassword || undefined);

      const permissionGranted = await requestNotificationPermission();
      if (permissionGranted && user?.id) {
        const subscribed = await subscribeToPushNotifications(user.id, roomId);
        console.log('🔔 Push subscription result for room:', roomId, subscribed);
      } else {
        console.warn('⚠️ Push notification permission denied or user ID missing');
      }

      onRegistered();
    } catch (err: any) {
      setError(err.message || '登録に失敗しました');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex flex-col">
      <InstallBanner />
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-block p-4 bg-blue-500 rounded-full mb-4">
            <MessageCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{getCurrentRoomName()}</h1>
          <p className="text-gray-600">表示名を入力してチャットに参加</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 mb-2">
              表示名
            </label>
            <input
              id="displayName"
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="ニックネームを入力"
              maxLength={20}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={loading}
            />
            <p className="text-xs text-gray-500 mt-1">{displayName.length}/20文字</p>
          </div>

          <div>
            <label htmlFor="adminPassword" className="block text-sm font-medium text-gray-700 mb-2">
              管理者パスワード（任意）
            </label>
            <input
              id="adminPassword"
              type="password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              placeholder="管理者の場合のみ入力"
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
              disabled={loading}
            />
            <p className="text-xs text-gray-500 mt-1">管理者権限が必要な場合のみ入力してください</p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !displayName.trim()}
            className="w-full bg-blue-600 text-white rounded-xl py-4 font-semibold hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            {loading ? '登録中...' : 'チャットに参加'}
          </button>
        </form>

        <div className="mt-6">
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-semibold text-gray-900 mb-2 text-sm">利用上の注意</h3>
            <ul className="text-xs text-gray-600 space-y-1">
              <li>• ログイン不要で簡単参加</li>
              <li>• 端末を変更すると引き継ぎできません</li>
              <li>• 不適切な行為はIPブロックされます</li>
              <li>• 投稿は2秒に1回まで</li>
            </ul>
          </div>
        </div>
        </div>
      </div>
    </div>
  );
}

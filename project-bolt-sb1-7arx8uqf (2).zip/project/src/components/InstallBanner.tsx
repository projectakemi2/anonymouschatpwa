import { useState, useEffect } from 'react';
import { Download, Share } from 'lucide-react';
import { isIOS, isAndroid, isStandalone } from '../lib/device';
import { logDeviceAnalytics } from '../lib/analytics';

export default function InstallBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [isIOSDevice, setIsIOSDevice] = useState(false);
  const [isAndroidDevice, setIsAndroidDevice] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    if (isStandalone()) {
      setIsVisible(false);
      return;
    }

    const iosDevice = isIOS();
    const androidDevice = isAndroid();

    setIsIOSDevice(iosDevice);
    setIsAndroidDevice(androidDevice);

    if ((window as any).deferredPrompt) {
      setDeferredPrompt((window as any).deferredPrompt);
      setIsVisible(true);
      return;
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      (window as any).deferredPrompt = e;
      setIsVisible(true);

      logDeviceAnalytics({
        eventType: 'beforeinstallprompt_fired',
        isInstallable: true,
        installButtonShown: true,
      });
    };

    window.addEventListener('beforeinstallprompt', handler);

    logDeviceAnalytics({
      eventType: 'page_load',
      isInstallable: !!(window as any).deferredPrompt,
      installButtonShown: false,
    });

    if (androidDevice) {
      const timer = setTimeout(() => {
        if (!(window as any).deferredPrompt) {
          setIsVisible(true);

          logDeviceAnalytics({
            eventType: 'install_button_shown_without_prompt',
            isInstallable: false,
            installButtonShown: true,
          });
        }
      }, 3000);

      return () => {
        clearTimeout(timer);
        window.removeEventListener('beforeinstallprompt', handler);
      };
    } else {
      setIsVisible(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstallClick = async () => {
    logDeviceAnalytics({
      eventType: 'install_button_clicked',
      isInstallable: !!deferredPrompt,
      installButtonShown: true,
      installAttempted: true,
    });

    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;

        if (outcome === 'accepted') {
          setIsVisible(false);

          logDeviceAnalytics({
            eventType: 'install_accepted',
            isInstallable: true,
            installButtonShown: true,
            installAttempted: true,
            installSucceeded: true,
          });
        } else {
          logDeviceAnalytics({
            eventType: 'install_rejected',
            isInstallable: true,
            installButtonShown: true,
            installAttempted: true,
            installSucceeded: false,
          });
        }

        setDeferredPrompt(null);
        (window as any).deferredPrompt = null;
      } catch (error) {
        console.error('Install prompt error:', error);

        logDeviceAnalytics({
          eventType: 'install_error',
          isInstallable: true,
          installButtonShown: true,
          installAttempted: true,
          installSucceeded: false,
          errorMessage: error instanceof Error ? error.message : String(error),
        });

        alert('画面右上のメニュー（⋮）をタップして、「アプリをインストール」または「ホーム画面に追加」を選択してください');
      }
    } else if (isAndroidDevice) {
      let attempts = 0;
      const maxAttempts = 25;
      const checkInterval = 200;
      let manualInstallShown = false;

      const showManualInstall = () => {
        if (!manualInstallShown) {
          manualInstallShown = true;

          logDeviceAnalytics({
            eventType: 'manual_install_instructions_shown',
            isInstallable: false,
            installButtonShown: true,
            installAttempted: true,
            installSucceeded: false,
            errorMessage: 'beforeinstallprompt not fired after 5 seconds',
          });

          const overlay = document.createElement('div');
          overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.9);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;';

          const content = document.createElement('div');
          content.style.cssText = 'background:white;border-radius:20px;padding:28px;max-width:420px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.3);';
          content.innerHTML = `
            <div style="background:linear-gradient(135deg, #4CAF50 0%, #45a049 100%);width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:48px;color:white;box-shadow:0 4px 12px rgba(76,175,80,0.3);">⋮</div>
            <div style="font-size:22px;font-weight:bold;margin-bottom:16px;color:#1a1a1a;">アプリをインストール</div>
            <div style="background:#f5f5f5;border-radius:12px;padding:20px;margin-bottom:20px;text-align:left;">
              <div style="font-size:14px;color:#333;line-height:1.8;">
                <div style="display:flex;align-items:start;margin-bottom:12px;">
                  <span style="background:#4CAF50;color:white;border-radius:50%;width:24px;height:24px;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:12px;margin-right:12px;flex-shrink:0;">1</span>
                  <span>画面<strong style="color:#4CAF50;">右上の「⋮」メニュー</strong>をタップ</span>
                </div>
                <div style="display:flex;align-items:start;">
                  <span style="background:#4CAF50;color:white;border-radius:50%;width:24px;height:24px;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:12px;margin-right:12px;flex-shrink:0;">2</span>
                  <span><strong style="color:#4CAF50;">「アプリをインストール」</strong><br>または<br><strong style="color:#4CAF50;">「ホーム画面に追加」</strong>を選択</span>
                </div>
              </div>
            </div>
            <div style="background:#fff3cd;border-left:4px solid #ffc107;padding:12px;border-radius:8px;margin-bottom:20px;text-align:left;">
              <div style="font-size:12px;color:#856404;line-height:1.5;">
                <strong>💡 ヒント:</strong> メニューに表示されない場合は、既にインストール済みか、ブラウザが対応していません。そのままWebで使えます！
              </div>
            </div>
            <button id="closeInstallHelp" style="background:linear-gradient(135deg, #4CAF50 0%, #45a049 100%);color:white;border:none;padding:14px 32px;border-radius:12px;font-size:17px;font-weight:bold;cursor:pointer;width:100%;box-shadow:0 4px 12px rgba(76,175,80,0.3);transition:transform 0.2s;">インストール方法を理解しました</button>
          `;

          overlay.appendChild(content);
          document.body.appendChild(overlay);

          const button = document.getElementById('closeInstallHelp')!;
          button.onclick = () => {
            document.body.removeChild(overlay);
          };

          button.onmouseover = () => {
            button.style.transform = 'scale(1.02)';
          };

          button.onmouseout = () => {
            button.style.transform = 'scale(1)';
          };

          overlay.onclick = (e) => {
            if (e.target === overlay) {
              document.body.removeChild(overlay);
            }
          };
        }
      };

      const waitForPrompt = setInterval(() => {
        attempts++;
        const prompt = (window as any).deferredPrompt;

        if (prompt) {
          clearInterval(waitForPrompt);
          setDeferredPrompt(prompt);
          prompt.prompt();
          prompt.userChoice.then((choiceResult: any) => {
            if (choiceResult.outcome === 'accepted') {
              setIsVisible(false);
            }
            setDeferredPrompt(null);
            (window as any).deferredPrompt = null;
          });
        } else if (attempts >= maxAttempts) {
          clearInterval(waitForPrompt);
          showManualInstall();
        }
      }, checkInterval);
    } else if (isIOSDevice) {
      const userAgent = window.navigator.userAgent.toLowerCase();
      const isInAppBrowser = /line|fban|fbav|instagram|twitter/.test(userAgent);

      if (isInAppBrowser) {
        const currentUrl = window.location.href;
        const safariUrl = currentUrl.replace(/^https?:\/\//, 'x-safari-https://');
        window.location.href = safariUrl;

        setTimeout(() => {
          alert('画面右上のメニュー（···）から「Safariで開く」を選択してください');
        }, 500);
      } else {
        alert('画面下部の共有ボタン（□に↑）をタップして、「ホーム画面に追加」を選択してください');
      }
    } else {
      alert('画面右上のメニュー（⋮）をタップして、「アプリをインストール」または「ホーム画面に追加」を選択してください');
    }
  };

  if (!isVisible) return null;

  const showGreen = deferredPrompt !== null || isAndroidDevice;

  return (
    <div className={`w-full px-4 py-3 flex items-center justify-between shadow-lg ${
      showGreen
        ? 'bg-gradient-to-r from-green-500 to-green-600'
        : 'bg-gradient-to-r from-blue-500 to-blue-600'
    }`}>
      <div className="flex items-center gap-3 flex-1">
        {showGreen ? (
          <Download className="w-6 h-6 text-white flex-shrink-0" />
        ) : (
          <Share className="w-6 h-6 text-white flex-shrink-0" />
        )}
        <div className="flex-1">
          <p className="text-white font-bold text-sm">アプリをインストール</p>
          <p className={`text-xs ${showGreen ? 'text-green-50' : 'text-blue-50'}`}>
            {showGreen
              ? 'ワンタップでホーム画面に追加'
              : '共有ボタンからホーム画面に追加'
            }
          </p>
        </div>
      </div>
      <button
        onClick={handleInstallClick}
        className={`px-4 py-1.5 bg-white text-sm font-bold rounded-lg transition-colors shadow-md ${
          showGreen
            ? 'text-green-600 hover:bg-green-50'
            : 'text-blue-600 hover:bg-blue-50'
        }`}
      >
        {showGreen ? 'インストール' : '手順を見る'}
      </button>
    </div>
  );
}

# 匿名チャットPWA - 完全引き継ぎドキュメント

**作成日:** 2026年1月17日
**バージョン:** 1.0.0
**プロジェクト名:** 参加者オープンチャット（Anonymous Chat PWA）

---

## 目次

1. [プロジェクト概要](#プロジェクト概要)
2. [技術スタック](#技術スタック)
3. [プロジェクト構造](#プロジェクト構造)
4. [環境変数](#環境変数)
5. [データベース設計](#データベース設計)
6. [認証システム](#認証システム)
7. [API仕様](#api仕様)
8. [セットアップ手順](#セットアップ手順)
9. [デプロイ手順](#デプロイ手順)
10. [テスト・動作確認](#テスト動作確認)
11. [トラブルシューティング](#トラブルシューティング)

---

## プロジェクト概要

### アプリケーション概要
匿名でチャットできるPWA（Progressive Web App）です。ログイン不要で、端末ごとに匿名ユーザーを作成し、リアルタイムでメッセージをやり取りできます。

### 主な機能
- 匿名ユーザー登録（デバイスID ベース）
- リアルタイムチャット（Supabase Realtime）
- 画像アップロード（最大4枚、自動リサイズ）
- 複数チャットルーム対応
- 管理者パネル（ユーザー管理、IPブロック、メッセージ削除）
- PWAインストール対応（iOS/Android）
- プッシュ通知（Service Worker）
- デバイス分析ダッシュボード
- 完全データエクスポート機能

### セキュリティ機能
- Row Level Security（RLS）による厳格なアクセス制御
- IPベースのブロック機能
- 管理者権限システム
- レート制限（2秒に1回まで）
- セキュリティヘッダー実装（CSP、XSS対策等）

---

## 技術スタック

### フロントエンド
- **React 18.3.1** - UIフレームワーク
- **TypeScript 5.5.3** - 型安全性
- **Vite 5.4.2** - ビルドツール
- **Tailwind CSS 3.4.1** - スタイリング
- **Lucide React 0.344.0** - アイコン
- **QRCode 1.5.4** - QRコード生成

### バックエンド
- **Supabase** - BaaS（Backend as a Service）
  - PostgreSQL データベース
  - Realtime（リアルタイム通信）
  - Storage（画像保存）
  - Edge Functions（サーバーレス関数）

### インフラ
- **Service Worker** - オフライン対応・プッシュ通知
- **PWA Manifest** - ホーム画面へのインストール

---

## プロジェクト構造

```
anonymous-chat-pwa/
├── .env                           # 環境変数
├── .gitignore                     # Git除外設定
├── package.json                   # 依存関係定義
├── package-lock.json              # 依存関係ロックファイル
├── tsconfig.json                  # TypeScript設定（ルート）
├── tsconfig.app.json              # TypeScript設定（アプリ）
├── tsconfig.node.json             # TypeScript設定（Node）
├── vite.config.ts                 # Vite設定
├── tailwind.config.js             # Tailwind CSS設定
├── postcss.config.js              # PostCSS設定
├── eslint.config.js               # ESLint設定
├── index.html                     # エントリーHTML
├── README.md                      # プロジェクト説明
├── SETUP.md                       # セットアップ手順
├── PERFORMANCE.md                 # パフォーマンス最適化
├── DATABASE_SCHEMA.sql            # DBスキーマエクスポート
├── COMPLETE_SOURCE_CODE.md        # ソースコード完全版
├── HANDOVER_DOCUMENT.md           # 本ドキュメント
│
├── public/                        # 静的ファイル
│   ├── manifest.json              # PWA マニフェスト
│   ├── sw.js                      # Service Worker
│   ├── icon.svg                   # アイコン（SVG）
│   ├── icon-192.png               # アイコン（192x192）
│   ├── icon-512.png               # アイコン（512x512）
│   ├── chat-icon.png              # チャットアイコン
│   ├── robots.txt                 # クローラー制御
│   ├── sitemap.xml                # サイトマップ
│   ├── security.txt               # セキュリティポリシー
│   ├── _headers                   # HTTPヘッダー設定
│   ├── DATABASE_SCHEMA.sql        # DBスキーマ（公開用）
│   ├── COMPLETE_SOURCE_CODE.md    # ソースコード（公開用）
│   └── .well-known/
│       └── security.txt           # セキュリティポリシー（標準位置）
│
├── src/                           # ソースコード
│   ├── main.tsx                   # エントリーポイント
│   ├── App.tsx                    # ルートコンポーネント
│   ├── index.css                  # グローバルCSS
│   ├── vite-env.d.ts              # Vite型定義
│   │
│   ├── components/                # Reactコンポーネント
│   │   ├── LandingPage.tsx        # ランディングページ
│   │   ├── RegisterScreen.tsx     # ユーザー登録画面
│   │   ├── ChatScreen.tsx         # チャット画面
│   │   ├── RoomList.tsx           # ルーム一覧
│   │   ├── AdminPanel.tsx         # 管理者パネル
│   │   ├── DeviceAnalyticsDashboard.tsx  # デバイス分析
│   │   ├── InstallPrompt.tsx      # インストールプロンプト
│   │   ├── InstallBanner.tsx      # インストールバナー
│   │   └── SafariPrompt.tsx       # Safari誘導画面
│   │
│   └── lib/                       # ユーティリティライブラリ
│       ├── supabase.ts            # Supabaseクライアント
│       ├── user.ts                # ユーザー管理
│       ├── messages.ts            # メッセージ管理
│       ├── room.ts                # ルーム管理
│       ├── admin.ts               # 管理者機能
│       ├── device.ts              # デバイス情報取得
│       ├── image.ts               # 画像処理
│       ├── notification.ts        # 通知管理
│       ├── analytics.ts           # デバイス分析
│       └── export.ts              # データエクスポート
│
├── supabase/                      # Supabase設定
│   ├── functions/                 # Edge Functions
│   │   └── admin-operations/
│   │       └── index.ts           # 管理者操作API
│   │
│   └── migrations/                # DBマイグレーション
│       ├── 20260112164121_create_anonymous_chat_schema.sql
│       ├── 20260112165110_optimize_performance_and_add_ttl.sql
│       ├── 20260114093123_fix_rls_policies.sql
│       ├── 20260114094010_fix_messages_select_policy.sql
│       ├── 20260114095216_fix_ip_blocks_rls_policy.sql
│       ├── 20260115035200_add_room_support.sql
│       └── 20260115092915_add_device_analytics.sql
│
└── scripts/                       # スクリプト
    └── generate-icons.html        # アイコン生成ツール
```

---

## 環境変数

### `.env` ファイル

```bash
# Supabase接続情報
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_ANON_KEY

# アプリケーションURL（PWA・QRコード生成用）
VITE_APP_URL=https://your-app-domain.com
```

### 環境変数の取得方法

1. **Supabaseプロジェクトを作成**
   - https://supabase.com/ にアクセス
   - 新規プロジェクトを作成

2. **接続情報を取得**
   - Supabaseダッシュボード > Settings > API
   - `Project URL` をコピー → `VITE_SUPABASE_URL`
   - `anon public` keyをコピー → `VITE_SUPABASE_ANON_KEY`

3. **アプリURLを設定**
   - デプロイ先のURLを設定（ローカルの場合は `http://localhost:5173`）

### 注意事項
- **`.env` ファイルはGitにコミットしない**（`.gitignore` に含まれています）
- `VITE_SUPABASE_ANON_KEY` は公開鍵なので、フロントエンドに含めても安全です
- サービスロールキー（`service_role_key`）は**絶対にフロントエンドに含めない**

---

## データベース設計

### テーブル一覧

#### 1. `anonymous_users` - 匿名ユーザー
```sql
CREATE TABLE anonymous_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  display_name text NOT NULL,
  ip_address text NOT NULL,
  is_admin boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  last_seen_at timestamptz DEFAULT now()
);
```

**用途:** 端末ごとに匿名ユーザーを管理

#### 2. `messages` - メッセージ
```sql
CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (char_length(content) <= 10000),
  images jsonb DEFAULT '[]'::jsonb,
  room_id text NOT NULL DEFAULT 'default',
  ip_address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  deleted_at timestamptz,
  deleted_by uuid REFERENCES anonymous_users(id)
);
```

**用途:** チャットメッセージを保存（ソフトデリート対応）

#### 3. `rooms` - チャットルーム
```sql
CREATE TABLE rooms (
  id text PRIMARY KEY,
  name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by text NOT NULL
);
```

**用途:** 管理者が作成したチャットルームを管理

#### 4. `ip_blocks` - IPブロック
```sql
CREATE TABLE ip_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address text UNIQUE NOT NULL,
  blocked_by uuid NOT NULL REFERENCES anonymous_users(id),
  reason text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
```

**用途:** 不適切なユーザーをIPでブロック

#### 5. `audit_logs` - 監査ログ
```sql
CREATE TABLE audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES anonymous_users(id),
  action_type text NOT NULL,
  target_user_id uuid REFERENCES anonymous_users(id),
  target_ip text,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);
```

**用途:** 管理者の操作履歴を記録

#### 6. `rate_limits` - レート制限
```sql
CREATE TABLE rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  last_message_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);
```

**用途:** メッセージ送信のレート制限（2秒に1回）

#### 7. `device_analytics` - デバイス分析
```sql
CREATE TABLE device_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text NOT NULL,
  user_agent text DEFAULT '',
  platform text DEFAULT '',
  browser text DEFAULT '',
  browser_version text DEFAULT '',
  os_version text DEFAULT '',
  is_standalone boolean DEFAULT false,
  is_installable boolean DEFAULT false,
  install_button_shown boolean DEFAULT false,
  install_attempted boolean DEFAULT false,
  install_succeeded boolean DEFAULT false,
  event_type text DEFAULT '',
  error_message text DEFAULT '',
  ip_address text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
```

**用途:** PWAインストールの成功率を分析

### Row Level Security (RLS) ポリシー

すべてのテーブルでRLSが有効化されています。主要なポリシー：

- **anonymous_users:** 全員閲覧可、自分のデータのみ更新可
- **messages:** 削除されていないメッセージは全員閲覧可、管理者のみ削除可
- **ip_blocks:** 全員閲覧可、管理者のみ追加・削除可
- **audit_logs:** 全員閲覧可、管理者のみ追加可
- **rate_limits:** 全員が閲覧・更新可（レート制限チェック用）
- **device_analytics:** 全員が追加可、管理者のみ閲覧可

### Realtime設定

以下のテーブルでRealtimeが有効：
- `messages`
- `anonymous_users`
- `ip_blocks`

---

## 認証システム

### 認証方式

このアプリケーションは**匿名認証**を採用しています。

#### 仕組み
1. ユーザーが初回訪問時に表示名を入力
2. 端末ごとに一意の`device_id`を生成（LocalStorageに保存）
3. `device_id`とIPアドレスを組み合わせてユーザーを識別
4. ユーザー情報はLocalStorageに保存され、次回訪問時に自動ログイン

#### 管理者認証
- 登録時に特定のパスワード（`admin123`）を入力すると管理者権限を取得
- 管理者は以下の操作が可能：
  - ユーザーのIPブロック/解除
  - メッセージの削除
  - 他のユーザーを管理者に昇格
  - 監査ログの確認
  - チャットルームの作成

#### セキュリティ考慮事項
- IPブロックされたユーザーはアプリを利用できない
- 管理者パスワードは環境変数ではなく、コード内にハードコード（`src/lib/user.ts`）
- 本番環境では管理者パスワードを変更すること

### 認証フロー

```mermaid
graph TD
    A[アプリ起動] --> B{LocalStorageにユーザー情報？}
    B -->|あり| C{ユーザーが有効？}
    B -->|なし| D[登録画面]
    C -->|有効| E[チャット画面]
    C -->|無効| D
    D --> F{管理者パスワード入力？}
    F -->|あり| G[管理者として登録]
    F -->|なし| H[一般ユーザーとして登録]
    G --> E
    H --> E
```

---

## API仕様

### Edge Function: `admin-operations`

**エンドポイント:** `https://YOUR_PROJECT_ID.supabase.co/functions/v1/admin-operations`

**認証:** 管理者パスワード必須

#### リクエスト形式

```typescript
interface AdminOperationRequest {
  action: 'block_ip' | 'unblock_ip' | 'delete_message' | 'delete_messages' | 'promote_admin';
  password: string;         // 管理者パスワード
  adminId: string;          // 管理者のユーザーID
  // action に応じた追加パラメータ
  ipAddress?: string;       // IPブロック/解除時
  reason?: string;          // ブロック理由
  messageId?: string;       // メッセージ削除時
  messageIds?: string[];    // 一括削除時
  userId?: string;          // 管理者昇格時
}
```

#### レスポンス形式

```typescript
interface AdminOperationResponse {
  success: boolean;
  error?: string;
}
```

#### エラーコード

- `403` - 管理者パスワードが間違っている、または管理者権限がない
- `400` - 無効なアクション
- `500` - サーバーエラー

#### 使用例

```typescript
const response = await fetch(
  'https://YOUR_PROJECT_ID.supabase.co/functions/v1/admin-operations',
  {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
    },
    body: JSON.stringify({
      action: 'block_ip',
      password: 'admin123',
      adminId: 'user-id-here',
      ipAddress: '192.168.1.1',
      reason: '不適切な投稿'
    })
  }
);
```

### Supabase Client API

このアプリはSupabase JavaScript Clientを使用してデータベース操作を行います。

#### メッセージ取得
```typescript
const { data, error } = await supabase
  .from('messages')
  .select('*, user:anonymous_users(display_name, is_admin)')
  .eq('room_id', roomId)
  .is('deleted_at', null)
  .order('created_at', { ascending: true });
```

#### メッセージ送信
```typescript
const { error } = await supabase
  .from('messages')
  .insert({
    user_id: userId,
    content: messageContent,
    images: imageUrls,
    room_id: roomId,
    ip_address: clientIP
  });
```

#### Realtime購読
```typescript
const channel = supabase
  .channel('messages_channel')
  .on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'messages',
      filter: `room_id=eq.${roomId}`
    },
    (payload) => {
      // 新しいメッセージを処理
    }
  )
  .subscribe();
```

---

## セットアップ手順

### 前提条件

- **Node.js**: v18以上
- **npm**: v9以上
- **Supabaseアカウント**

### 1. リポジトリのクローン

```bash
git clone <repository-url>
cd anonymous-chat-pwa
```

### 2. 依存関係のインストール

```bash
npm install
```

### 3. Supabaseプロジェクトの作成

1. https://supabase.com/ にアクセス
2. 新規プロジェクトを作成
3. プロジェクト名、データベースパスワード、リージョンを設定

### 4. 環境変数の設定

`.env` ファイルを作成：

```bash
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_ANON_KEY
VITE_APP_URL=http://localhost:5173
```

### 5. データベースマイグレーションの実行

Supabaseダッシュボード > SQL Editor で以下のファイルを順番に実行：

1. `supabase/migrations/20260112164121_create_anonymous_chat_schema.sql`
2. `supabase/migrations/20260112165110_optimize_performance_and_add_ttl.sql`
3. `supabase/migrations/20260114093123_fix_rls_policies.sql`
4. `supabase/migrations/20260114094010_fix_messages_select_policy.sql`
5. `supabase/migrations/20260114095216_fix_ip_blocks_rls_policy.sql`
6. `supabase/migrations/20260115035200_add_room_support.sql`
7. `supabase/migrations/20260115092915_add_device_analytics.sql`

または、`DATABASE_SCHEMA.sql` を一括実行することも可能です。

### 6. Realtimeの有効化

Supabaseダッシュボード > Database > Replication で以下のテーブルを有効化：
- `messages`
- `anonymous_users`
- `ip_blocks`

### 7. Edge Functionのデプロイ（オプション）

管理者操作をEdge Function経由で行う場合：

Supabaseダッシュボード > Edge Functions > Create Function で：
- Function名: `admin-operations`
- コード: `supabase/functions/admin-operations/index.ts` の内容をコピー

### 8. 開発サーバーの起動

```bash
npm run dev
```

ブラウザで http://localhost:5173 にアクセス

### 9. ビルド

```bash
npm run build
```

`dist/` フォルダに本番用ファイルが生成されます。

---

## デプロイ手順

### Vercelへのデプロイ（推奨）

#### 1. Vercelアカウントの作成
https://vercel.com/ でアカウントを作成

#### 2. プロジェクトのインポート
1. Vercel Dashboard > New Project
2. GitHubリポジトリを選択
3. Framework Preset: Vite
4. Build Command: `npm run build`
5. Output Directory: `dist`

#### 3. 環境変数の設定
Vercel Dashboard > Settings > Environment Variables で以下を追加：
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_APP_URL` (Vercelが割り当てたURL)

#### 4. デプロイ
`Deploy` ボタンをクリック

### その他のデプロイ先

#### Netlify
1. `netlify.toml` を作成：
```toml
[build]
  command = "npm run build"
  publish = "dist"
```
2. Netlify Dashboard > New Site from Git
3. 環境変数を設定
4. デプロイ

#### Render
1. Render Dashboard > New Static Site
2. Build Command: `npm run build`
3. Publish Directory: `dist`
4. 環境変数を設定

#### Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

### HTTPSの設定

**重要:** PWAとService Workerは**HTTPS必須**です。すべてのデプロイ先で必ずHTTPSを有効にしてください。

---

## テスト・動作確認

### 基本動作確認

#### 1. ユーザー登録
- [ ] 表示名を入力して「チャットに参加」ボタンをクリック
- [ ] チャット画面に遷移する
- [ ] LocalStorageに `current_user` が保存される

#### 2. メッセージ送信
- [ ] テキストメッセージを入力して送信
- [ ] メッセージが画面に表示される
- [ ] データベースに保存される

#### 3. 画像送信
- [ ] 画像を選択（最大4枚）
- [ ] プレビューが表示される
- [ ] 画像付きメッセージを送信
- [ ] 画像が表示される

#### 4. リアルタイム同期
- [ ] 別のブラウザ/デバイスでアクセス
- [ ] 片方でメッセージを送信
- [ ] もう片方でメッセージが即座に表示される

#### 5. ルーム機能
- [ ] ルーム一覧を開く
- [ ] 別のルームに参加
- [ ] URLのハッシュが変わる (#roomId)
- [ ] 各ルームで独立したチャットができる

#### 6. 管理者機能
- [ ] 管理者パスワード（`admin123`）で登録
- [ ] 管理者パネルが開ける
- [ ] ユーザーをブロックできる
- [ ] メッセージを削除できる
- [ ] 監査ログが記録される

#### 7. PWAインストール
- [ ] iPhoneのSafariでアクセス
- [ ] 「共有」→「ホーム画面に追加」
- [ ] ホーム画面にアイコンが追加される
- [ ] アイコンからアプリを起動
- [ ] スタンドアロンモードで動作する

#### 8. プッシュ通知
- [ ] 通知を許可
- [ ] 別のユーザーがメッセージを送信
- [ ] 通知が表示される

### パフォーマンステスト

#### Lighthouse
1. Chrome DevTools > Lighthouse
2. Performance, Accessibility, Best Practices, SEO, PWA を実行
3. すべて90点以上を目指す

#### ネットワークテスト
- [ ] Service Workerが動作している
- [ ] オフライン時にキャッシュから読み込める
- [ ] 画像が適切に圧縮されている（各画像 < 500KB）

### セキュリティテスト

- [ ] RLSが正しく動作している（他のユーザーのデータにアクセスできない）
- [ ] IPブロックが機能している
- [ ] CSPヘッダーが設定されている
- [ ] XSS攻撃が防げている

---

## トラブルシューティング

### よくある問題

#### 1. Supabase接続エラー
**症状:** `Failed to fetch` エラー

**解決方法:**
- `.env` ファイルが正しく設定されているか確認
- Supabase URLとAnon Keyが正しいか確認
- Supabaseプロジェクトが起動しているか確認

#### 2. Realtimeが動作しない
**症状:** 新しいメッセージが自動で表示されない

**解決方法:**
- Supabase Dashboard > Database > Replication でRealtimeを有効化
- RLSポリシーが正しく設定されているか確認
- ブラウザのコンソールでエラーを確認

#### 3. 画像アップロードエラー
**症状:** 画像が送信できない

**解決方法:**
- 画像サイズが5MB以下か確認
- 画像形式がJPEG/PNG/GIF/WebPか確認
- ブラウザのコンソールでエラーを確認

#### 4. PWAインストールできない（iOS）
**症状:** 「ホーム画面に追加」が表示されない

**解決方法:**
- Safariでアクセスしているか確認（Chrome等は不可）
- HTTPSでアクセスしているか確認
- `manifest.json` が正しく設定されているか確認

#### 5. Service Workerエラー
**症状:** Service Workerが登録されない

**解決方法:**
- HTTPSでアクセスしているか確認（localhostは例外）
- `sw.js` が正しくデプロイされているか確認
- ブラウザのキャッシュをクリア

### デバッグ方法

#### コンソールログ
```typescript
console.log('User:', user);
console.log('Messages:', messages);
```

#### Supabase Query
```typescript
const { data, error } = await supabase.from('messages').select('*');
console.log('Data:', data);
console.log('Error:', error);
```

#### ネットワークタブ
Chrome DevTools > Network で以下を確認：
- Supabaseへのリクエスト
- レスポンスステータス
- レスポンス内容

---

## サポート・連絡先

### ドキュメント
- プロジェクトREADME: `README.md`
- セットアップ手順: `SETUP.md`
- データベーススキーマ: `DATABASE_SCHEMA.sql`
- ソースコード: `COMPLETE_SOURCE_CODE.md`

### 外部リンク
- Supabase公式ドキュメント: https://supabase.com/docs
- React公式ドキュメント: https://react.dev/
- Vite公式ドキュメント: https://vitejs.dev/

---

**このドキュメントは定期的に更新してください。**

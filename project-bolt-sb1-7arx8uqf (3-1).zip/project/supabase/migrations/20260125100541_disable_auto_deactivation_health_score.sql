/*
  # Disable Auto-deactivation Based on Health Score

  ## Overview
  Removes the automatic deactivation of push subscriptions based on health_score.
  The previous system was too aggressive and deactivated valid subscriptions just
  because no notifications were sent recently.

  ## Changes Made

  1. **Modified update_subscription_stats Function**
     - Removed automatic is_active = false when health_score < 30
     - is_active should only be managed manually based on actual failures
     - Health score is still calculated but doesn't trigger auto-deactivation

  2. **Modified calculate_subscription_health Function**
     - Relaxed recency penalty (5 points/day → 1 point/day)
     - Subscriptions with no sends maintain 100 health score
     - More forgiving to inactive but valid subscriptions

  3. **Data Cleanup**
     - Re-activate all subscriptions with health_score >= 30
     - Only keep deactivated those with consistent failures (failure_count >= 3)

  ## Important Notes
  - Subscriptions are now only deactivated by manual admin action or consistent failures
  - Health score is still tracked for analytics but doesn't affect is_active status
  - This prevents legitimate subscribers from being incorrectly deactivated
*/

-- Update the health calculation function to be more lenient
CREATE OR REPLACE FUNCTION calculate_subscription_health(sub_id uuid)
RETURNS numeric AS $$
DECLARE
  success_rate numeric;
  recency_score numeric;
  engage_rate numeric;
  days_since_success integer;
  total integer;
  success_cnt integer;
BEGIN
  -- Get subscription stats
  SELECT 
    total_sent,
    success_count,
    engagement_rate,
    COALESCE(EXTRACT(DAY FROM (now() - last_success_at)), 0)
  INTO total, success_cnt, engage_rate, days_since_success
  FROM push_subscriptions
  WHERE id = sub_id;

  -- If never sent, maintain perfect health
  IF total = 0 OR total IS NULL THEN
    RETURN 100;
  END IF;

  -- Calculate success rate percentage
  success_rate := (COALESCE(success_cnt, 0)::numeric / total) * 100;

  -- Calculate recency score with more lenient decay (1 point per day instead of 5)
  -- This means it takes 100 days to reach 0 instead of 20 days
  recency_score := GREATEST(0, 100 - days_since_success);

  -- Calculate final health score
  -- Formula: 40% success rate + 40% engagement + 20% recency
  RETURN LEAST(100, (success_rate * 0.4) + (COALESCE(engage_rate, 0) * 0.4) + (recency_score * 0.2));
END;
$$ LANGUAGE plpgsql;

-- Update subscription stats function WITHOUT auto-deactivation
CREATE OR REPLACE FUNCTION update_subscription_stats(
  sub_id uuid,
  event text,
  should_increment_failure boolean DEFAULT false
)
RETURNS void AS $$
BEGIN
  IF event = 'sent' THEN
    UPDATE push_subscriptions
    SET total_sent = total_sent + 1
    WHERE id = sub_id;
    
  ELSIF event = 'success' THEN
    UPDATE push_subscriptions
    SET 
      success_count = success_count + 1,
      last_success_at = now(),
      failure_count = 0  -- Reset failure count on success
    WHERE id = sub_id;
    
  ELSIF event = 'failed' AND should_increment_failure THEN
    UPDATE push_subscriptions
    SET 
      failure_count = failure_count + 1,
      last_failure_at = now()
    WHERE id = sub_id;
    
    -- Only deactivate if there are 5+ consecutive failures
    -- This indicates a real problem, not just temporary issues
    UPDATE push_subscriptions
    SET is_active = false
    WHERE id = sub_id AND failure_count >= 5;
    
  ELSIF event = 'clicked' THEN
    UPDATE push_subscriptions
    SET 
      total_clicked = total_clicked + 1,
      engagement_rate = CASE 
        WHEN total_sent > 0 THEN ((total_clicked + 1)::numeric / total_sent) * 100
        ELSE 0
      END
    WHERE id = sub_id;
    
  ELSIF event = 'dismissed' THEN
    UPDATE push_subscriptions
    SET total_dismissed = total_dismissed + 1
    WHERE id = sub_id;
  END IF;

  -- Recalculate health score (for analytics only, doesn't affect is_active)
  UPDATE push_subscriptions
  SET health_score = calculate_subscription_health(sub_id)
  WHERE id = sub_id;

  -- NO AUTO-DEACTIVATION based on health_score
  -- is_active is only changed by explicit failures or admin action
END;
$$ LANGUAGE plpgsql;

-- Recalculate health scores for all subscriptions with new formula
UPDATE push_subscriptions
SET health_score = calculate_subscription_health(id);

-- Re-activate subscriptions that were incorrectly deactivated
-- Only keep deactivated those with serious failure patterns
UPDATE push_subscriptions
SET is_active = true
WHERE is_active = false 
  AND health_score >= 30
  AND failure_count < 3;

-- Summary of changes
DO $$
DECLARE
  reactivated_count integer;
  total_active integer;
  total_count integer;
BEGIN
  SELECT COUNT(*) INTO reactivated_count
  FROM push_subscriptions
  WHERE is_active = true AND health_score >= 30;
  
  SELECT COUNT(*) INTO total_active
  FROM push_subscriptions
  WHERE is_active = true;
  
  SELECT COUNT(*) INTO total_count
  FROM push_subscriptions;
  
  RAISE NOTICE 'Migration complete:';
  RAISE NOTICE '- Total subscriptions: %', total_count;
  RAISE NOTICE '- Active subscriptions: %', total_active;
  RAISE NOTICE '- Reactivation completed for subscriptions with health >= 30';
END $$;

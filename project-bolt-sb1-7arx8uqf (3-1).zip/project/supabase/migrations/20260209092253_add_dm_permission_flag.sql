/*
  # 個別メール許可フラグの追加

  1. 変更内容
    - `anonymous_users`テーブルに`allow_direct_messages`カラムを追加
    - デフォルトはfalse（許可しない）
    - 管理者が明示的に許可した場合のみtrueになる
  
  2. 目的
    - 管理者が多すぎる場合に、DM受信を希望する管理者だけを表示できるようにする
    - 一般ユーザーには許可した管理者のみが表示される
*/

-- allow_direct_messagesカラムを追加
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'anonymous_users' AND column_name = 'allow_direct_messages'
  ) THEN
    ALTER TABLE anonymous_users 
    ADD COLUMN allow_direct_messages boolean DEFAULT false NOT NULL;
  END IF;
END $$;

-- デフォルトの管理者（佐藤明美と藤本なぎさ）は自動的に許可
UPDATE anonymous_users
SET allow_direct_messages = true
WHERE device_id IN ('admin_satou_akemi', 'admin_fujimoto_nagisa');
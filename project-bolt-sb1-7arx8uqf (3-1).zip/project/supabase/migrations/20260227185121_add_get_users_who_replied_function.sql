/*
  # Add optimized get_users_who_replied function

  1. New Function
    - `get_users_who_replied(admin_user_id uuid)` returns table (id uuid, display_name text)
    - Uses DISTINCT ON to efficiently get unique senders without fetching all message data
    - Avoids transferring image_url/content data over the wire

  2. Performance
    - Replaces client-side deduplication of potentially thousands of DM rows
    - Uses existing indexes on direct_messages (recipient_id, sender_id)
*/

CREATE OR REPLACE FUNCTION get_users_who_replied(admin_user_id uuid)
RETURNS TABLE (id uuid, display_name text)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT DISTINCT au.id, au.display_name
  FROM direct_messages dm
  JOIN anonymous_users au ON au.id = dm.sender_id
  WHERE dm.recipient_id = admin_user_id
    AND dm.sender_id != admin_user_id
  ORDER BY au.display_name;
$$;

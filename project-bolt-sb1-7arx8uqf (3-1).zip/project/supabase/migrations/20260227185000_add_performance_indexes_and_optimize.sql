/*
  # Performance optimization: Add missing indexes and optimize queries

  1. New Indexes
    - `idx_push_subscriptions_user_room_active` on push_subscriptions (user_id, room_id) WHERE is_active = true
      - Speeds up push subscription lookups which had only 41% index usage
    - `idx_direct_messages_thread` on direct_messages (sender_id, recipient_id, created_at DESC)
      - Speeds up thread message retrieval
    - `idx_device_analytics_created_at` on device_analytics (created_at DESC)
      - Allows time-based queries on analytics

  2. Maintenance
    - ANALYZE device_analytics to update planner statistics (never previously analyzed)
    - ANALYZE direct_messages to update planner statistics
    - ANALYZE messages to update planner statistics

  3. Notes
    - ip_blocks already has a unique index on ip_address but RLS policy causes seq scans;
      the fix is in RLS policy optimization (handled separately in app code)
    - device_analytics had zero seq_scan/idx_scan meaning it's only written to, not queried heavily
*/

CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user_room_active
  ON push_subscriptions (user_id, room_id)
  WHERE is_active = true;

CREATE INDEX IF NOT EXISTS idx_direct_messages_thread
  ON direct_messages (sender_id, recipient_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_device_analytics_created_at
  ON device_analytics (created_at DESC);

ANALYZE device_analytics;
ANALYZE direct_messages;
ANALYZE messages;
ANALYZE push_subscriptions;
ANALYZE anonymous_users;
ANALYZE ip_blocks;

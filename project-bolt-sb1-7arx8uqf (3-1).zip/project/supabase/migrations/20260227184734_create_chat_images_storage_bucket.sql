/*
  # Create chat-images storage bucket

  1. Storage
    - Create `chat-images` public bucket for storing chat and DM images
    - Configure public access for reading images
    - Add storage policies for upload/read access

  2. Security
    - Anyone can read images (public bucket)
    - Only anon and authenticated users can upload
    - File size limit enforced at application level
*/

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'chat-images',
  'chat-images',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Anyone can read chat images"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'chat-images');

CREATE POLICY "Anyone can upload chat images"
  ON storage.objects FOR INSERT
  TO anon, authenticated
  WITH CHECK (bucket_id = 'chat-images');

CREATE POLICY "Anyone can delete own chat images"
  ON storage.objects FOR DELETE
  TO anon, authenticated
  USING (bucket_id = 'chat-images');

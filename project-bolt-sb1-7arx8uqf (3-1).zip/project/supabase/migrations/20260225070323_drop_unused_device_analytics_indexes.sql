/*
  # Drop unused device_analytics indexes

  1. Changes
    - Drop `idx_device_analytics_device_fp_hash` (624KB, 0 uses)
    - Drop `idx_device_analytics_canvas_fp` (592KB, 0 uses)
    - Drop `idx_device_analytics_webgl_fp` (560KB, 0 uses)

  2. Reason
    - These indexes consume ~1.8MB total but have never been used
    - Removing them will speed up INSERT operations on device_analytics
    - The table has 64,521 rows and is frequently written to
*/

DROP INDEX IF EXISTS idx_device_analytics_device_fp_hash;
DROP INDEX IF EXISTS idx_device_analytics_canvas_fp;
DROP INDEX IF EXISTS idx_device_analytics_webgl_fp;

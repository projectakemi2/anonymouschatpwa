/*
  # プッシュ通知サブスクリプション管理テーブル

  1. 新規テーブル
    - `push_subscriptions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to anonymous_users)
      - `endpoint` (text, unique) - プッシュ通知のエンドポイント
      - `p256dh` (text) - 暗号化キー
      - `auth` (text) - 認証シークレット
      - `user_agent` (text) - デバイス情報
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  
  2. セキュリティ
    - RLSを有効化
    - ユーザーは自分のサブスクリプションのみ管理可能
    - サービスロールキーで全アクセス可能（通知送信用）
*/

-- プッシュ通知サブスクリプションテーブル
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  endpoint text NOT NULL,
  p256dh text NOT NULL,
  auth text NOT NULL,
  user_agent text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(endpoint)
);

-- インデックス
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user_id ON push_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_endpoint ON push_subscriptions(endpoint);

-- RLSを有効化
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

-- ユーザーは自分のサブスクリプションのみ閲覧可能
CREATE POLICY "Users can view own subscriptions"
  ON push_subscriptions FOR SELECT
  TO authenticated, anon
  USING (user_id = (SELECT id FROM anonymous_users WHERE id::text = current_setting('request.jwt.claims', true)::json->>'sub'));

-- ユーザーは自分のサブスクリプションを作成可能
CREATE POLICY "Users can create own subscriptions"
  ON push_subscriptions FOR INSERT
  TO authenticated, anon
  WITH CHECK (user_id = (SELECT id FROM anonymous_users WHERE id::text = current_setting('request.jwt.claims', true)::json->>'sub'));

-- ユーザーは自分のサブスクリプションを更新可能
CREATE POLICY "Users can update own subscriptions"
  ON push_subscriptions FOR UPDATE
  TO authenticated, anon
  USING (user_id = (SELECT id FROM anonymous_users WHERE id::text = current_setting('request.jwt.claims', true)::json->>'sub'))
  WITH CHECK (user_id = (SELECT id FROM anonymous_users WHERE id::text = current_setting('request.jwt.claims', true)::json->>'sub'));

-- ユーザーは自分のサブスクリプションを削除可能
CREATE POLICY "Users can delete own subscriptions"
  ON push_subscriptions FOR DELETE
  TO authenticated, anon
  USING (user_id = (SELECT id FROM anonymous_users WHERE id::text = current_setting('request.jwt.claims', true)::json->>'sub'));

-- サービスロールは全アクセス可能（Edge Functionから通知送信するため）
CREATE POLICY "Service role has full access"
  ON push_subscriptions FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

/*
  # Add Image Support to Direct Messages

  1. Changes
    - Add `image_url` column to direct_messages table to store image data URLs
    - Add `image_name` column to store original filename
  
  2. Notes
    - Images will be stored as data URLs (base64) for simplicity
    - No additional storage configuration needed
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'direct_messages' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE direct_messages ADD COLUMN image_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'direct_messages' AND column_name = 'image_name'
  ) THEN
    ALTER TABLE direct_messages ADD COLUMN image_name text;
  END IF;
END $$;

/*
  # デフォルト管理者ユーザーの追加

  1. 新規データ
    - 管理者ユーザー「佐藤明美」を追加
    - 管理者ユーザー「藤本なぎさ」を追加
  
  2. 詳細
    - これらのユーザーはDM専用の管理者アカウント
    - device_idは固定値を使用
    - is_adminフラグをtrueに設定
    - 一般ユーザーがDMを送信する際の宛先として表示される
*/

-- 佐藤明美（管理者）を追加
INSERT INTO anonymous_users (id, device_id, display_name, ip_address, is_admin, created_at, last_seen_at)
VALUES (
  '00000000-0000-0000-0000-000000000001'::uuid,
  'admin_satou_akemi',
  '佐藤明美',
  '127.0.0.1',
  true,
  now(),
  now()
)
ON CONFLICT (device_id) DO UPDATE
SET display_name = '佐藤明美',
    is_admin = true;

-- 藤本なぎさ（管理者）を追加
INSERT INTO anonymous_users (id, device_id, display_name, ip_address, is_admin, created_at, last_seen_at)
VALUES (
  '00000000-0000-0000-0000-000000000002'::uuid,
  'admin_fujimoto_nagisa',
  '藤本なぎさ',
  '127.0.0.1',
  true,
  now(),
  now()
)
ON CONFLICT (device_id) DO UPDATE
SET display_name = '藤本なぎさ',
    is_admin = true;
# プロジェクト完全エクスポート - 匿名チャットPWA

## プロジェクト概要

このドキュメントは、匿名チャットPWAの完全な構造とデータベーススキーマをエクスポートしたものです。

## 1. プロジェクト構造

```
project/
├── public/                          # 静的ファイル
│   ├── manifest.json               # PWAマニフェスト
│   ├── sw.js                       # Service Worker
│   ├── icon-192.png                # アプリアイコン (192x192)
│   ├── icon-512.png                # アプリアイコン (512x512)
│   ├── icon.svg                    # SVGアイコン
│   ├── chat-icon.png               # チャットアイコン
│   ├── _headers                    # セキュリティヘッダー
│   ├── robots.txt                  # 検索エンジン制御
│   └── security.txt                # セキュリティ情報
│
├── src/                            # ソースコード
│   ├── components/                 # Reactコンポーネント
│   │   ├── AdminPanel.tsx         # 管理者パネル
│   │   ├── ChatScreen.tsx         # チャット画面
│   │   ├── DeviceAnalyticsDashboard.tsx  # デバイス分析ダッシュボード
│   │   ├── InstallBanner.tsx      # インストールバナー
│   │   ├── InstallPrompt.tsx      # インストールプロンプト
│   │   ├── LandingPage.tsx        # ランディングページ
│   │   ├── RegisterScreen.tsx     # ユーザー登録画面
│   │   ├── RoomList.tsx           # ルームリスト
│   │   └── SafariPrompt.tsx       # Safari用プロンプト
│   │
│   ├── lib/                        # ユーティリティライブラリ
│   │   ├── admin.ts               # 管理者機能
│   │   ├── analytics.ts           # アナリティクス
│   │   ├── device.ts              # デバイス情報
│   │   ├── image.ts               # 画像処理
│   │   ├── messages.ts            # メッセージ管理
│   │   ├── notification.ts        # 通知機能
│   │   ├── room.ts                # ルーム管理
│   │   ├── supabase.ts            # Supabase接続
│   │   └── user.ts                # ユーザー管理
│   │
│   ├── App.tsx                     # メインアプリケーション
│   ├── main.tsx                    # エントリーポイント
│   ├── index.css                   # グローバルスタイル
│   └── vite-env.d.ts              # 型定義
│
├── supabase/                       # Supabaseバックエンド
│   ├── migrations/                 # データベースマイグレーション
│   │   ├── 20260112164121_create_anonymous_chat_schema.sql
│   │   ├── 20260112165110_optimize_performance_and_add_ttl.sql
│   │   ├── 20260114093123_fix_rls_policies.sql
│   │   ├── 20260114094010_fix_messages_select_policy.sql
│   │   ├── 20260114095216_fix_ip_blocks_rls_policy.sql
│   │   ├── 20260115035200_add_room_support.sql
│   │   └── 20260115092915_add_device_analytics.sql
│   │
│   └── functions/                  # Edge Functions
│       └── admin-operations/
│           └── index.ts
│
├── .env                            # 環境変数
├── package.json                    # 依存関係
├── tsconfig.json                   # TypeScript設定
├── vite.config.ts                  # Vite設定
├── tailwind.config.js              # Tailwind CSS設定
├── postcss.config.js               # PostCSS設定
└── eslint.config.js                # ESLint設定
```

## 2. データベース構造

### 2.1 テーブル一覧

#### `anonymous_users` - 匿名ユーザー
```sql
CREATE TABLE anonymous_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  username text NOT NULL,
  avatar_color text DEFAULT '#3B82F6',
  created_at timestamptz DEFAULT now(),
  last_active timestamptz DEFAULT now(),
  is_admin boolean DEFAULT false,
  is_blocked boolean DEFAULT false,
  ip_address text
);
```

**インデックス:**
- `idx_anonymous_users_device_id` ON device_id
- `idx_anonymous_users_ip` ON ip_address
- `idx_anonymous_users_last_active` ON last_active

#### `messages` - メッセージ
```sql
CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES anonymous_users(id) ON DELETE CASCADE,
  content text NOT NULL,
  image_url text,
  room_id text DEFAULT 'default',
  created_at timestamptz DEFAULT now()
);
```

**インデックス:**
- `idx_messages_room_created` ON room_id, created_at DESC
- `idx_messages_user_id` ON user_id
- `idx_messages_created_at` ON created_at

#### `rooms` - チャットルーム
```sql
CREATE TABLE rooms (
  id text PRIMARY KEY,
  name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by text NOT NULL
);
```

**インデックス:**
- `idx_rooms_created_at` ON created_at DESC

#### `ip_blocks` - IPブロック
```sql
CREATE TABLE ip_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address text UNIQUE NOT NULL,
  reason text,
  blocked_at timestamptz DEFAULT now(),
  blocked_by uuid REFERENCES anonymous_users(id)
);
```

**インデックス:**
- `idx_ip_blocks_ip` ON ip_address

#### `device_analytics` - デバイス分析
```sql
CREATE TABLE device_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES anonymous_users(id) ON DELETE CASCADE,
  device_type text NOT NULL,
  browser text,
  os text,
  screen_width integer,
  screen_height integer,
  user_agent text,
  language text,
  timezone text,
  connection_type text,
  is_mobile boolean DEFAULT false,
  is_tablet boolean DEFAULT false,
  is_desktop boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
```

**インデックス:**
- `idx_device_analytics_user` ON user_id
- `idx_device_analytics_created` ON created_at DESC
- `idx_device_analytics_device_type` ON device_type

### 2.2 Row Level Security (RLS) ポリシー

すべてのテーブルでRLSが有効化されています。

**anonymous_users:**
- `anonymous_users_select_policy` - 全員が全ユーザーを閲覧可能
- `anonymous_users_insert_policy` - 全員が新規ユーザーを作成可能
- `anonymous_users_update_policy` - 自分のユーザー情報のみ更新可能

**messages:**
- `messages_select_policy` - 全員が全メッセージを閲覧可能
- `messages_insert_policy` - 全員がメッセージを投稿可能

**rooms:**
- `rooms_select_policy` - 全員が全ルームを閲覧可能
- `rooms_insert_policy` - 管理者のみルームを作成可能

**ip_blocks:**
- `ip_blocks_select_policy` - 全員がブロック情報を閲覧可能
- `ip_blocks_insert_policy` - 管理者のみIPブロックを追加可能

**device_analytics:**
- `device_analytics_select_policy` - 管理者のみ閲覧可能
- `device_analytics_insert_policy` - 全員が自分のデバイス情報を記録可能

### 2.3 自動クリーンアップ機能

pg_cronを使用した自動削除:
- 古いメッセージ: 7日間経過後に削除
- 非アクティブユーザー: 30日間非アクティブ後に削除

## 3. 主要機能

### 3.1 ユーザー管理
- デバイスIDベースの匿名認証
- ユーザー名とアバター色のカスタマイズ
- 管理者権限システム
- IPブロック機能

### 3.2 チャット機能
- リアルタイムメッセージング (Supabase Realtime)
- 画像アップロード対応
- 複数ルーム対応
- ルームコードによる参加

### 3.3 PWA機能
- オフライン対応
- インストール可能
- プッシュ通知対応
- Service Worker

### 3.4 管理機能
- ユーザー管理パネル
- IPブロック管理
- デバイス分析ダッシュボード
- メッセージ監視

### 3.5 URL形式
3つのURL形式に対応:
1. ハッシュ形式: `https://example.com#roomId`
2. クエリ形式: `https://example.com?room=roomId`
3. パス形式: `https://example.com/roomId`

## 4. 環境変数

```env
VITE_SUPABASE_URL=https://bgridzofylgxvopinici.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_APP_URL=https://anonymous-chat-pwa-a-u2hf.bolt.host
```

## 5. 依存関係

### 主要パッケージ
```json
{
  "dependencies": {
    "@supabase/supabase-js": "^2.57.4",
    "lucide-react": "^0.344.0",
    "qrcode": "^1.5.4",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "tailwindcss": "^3.4.1",
    "typescript": "^5.5.3",
    "vite": "^5.4.2"
  }
}
```

## 6. ビルドとデプロイ

### 開発環境
```bash
npm install
npm run dev
```

### 本番ビルド
```bash
npm run build
```

ビルド成果物は `dist/` ディレクトリに出力されます。

### デプロイ先
- フロントエンド: Bolt.host
- バックエンド: Supabase
- 本番URL: https://anonymous-chat-pwa-a-u2hf.bolt.host

## 7. セキュリティ機能

### フロントエンド
- Content Security Policy (CSP)
- HTTPS強制
- XSS対策
- CSRF対策

### バックエンド
- Row Level Security (RLS)
- IPブロック機能
- 管理者権限システム
- 入力値検証

## 8. パフォーマンス最適化

### データベース
- 適切なインデックス設定
- 自動データクリーンアップ
- リアルタイム購読の最適化

### フロントエンド
- コード分割
- 画像最適化
- Service Workerキャッシング
- Lazy Loading

## 9. エクスポート方法

### 方法1: プロジェクトフォルダ全体をダウンロード
プロジェクトディレクトリ全体をzip圧縮してダウンロード

### 方法2: Gitリポジトリとして管理
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-repo-url>
git push -u origin main
```

### 方法3: データベーススキーマのエクスポート
Supabaseダッシュボード > SQL Editor > すべてのマイグレーションを実行

## 10. 復元手順

1. 新しいプロジェクトディレクトリを作成
2. すべてのファイルをコピー
3. `npm install` で依存関係をインストール
4. `.env` ファイルを設定
5. Supabaseで新しいプロジェクトを作成
6. マイグレーションファイルを順番に実行
7. `npm run dev` で開発サーバーを起動

## 11. 技術スタック

- **フロントエンド:** React 18 + TypeScript + Vite
- **スタイリング:** Tailwind CSS
- **バックエンド:** Supabase (PostgreSQL + Realtime + Storage + Edge Functions)
- **認証:** 匿名認証 (デバイスIDベース)
- **デプロイ:** Bolt.host
- **PWA:** Service Worker + Manifest

## 12. 今後の拡張案

- ファイル共有機能
- 音声メッセージ
- ユーザープロフィール拡張
- ルーム内検索機能
- メッセージ編集・削除機能
- リアクション機能
- メンション機能

---

**作成日:** 2026年1月17日
**バージョン:** 1.0.0
**ライセンス:** MIT

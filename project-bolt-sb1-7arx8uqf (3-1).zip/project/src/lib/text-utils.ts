export interface TextPart {
  type: 'text' | 'link';
  content: string;
  index?: number;
}

export function linkifyText(text: string): TextPart[] {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts: TextPart[] = [];
  let lastIndex = 0;
  let match;

  while ((match = urlRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push({
        type: 'text',
        content: text.substring(lastIndex, match.index),
      });
    }

    const url = match[0];
    parts.push({
      type: 'link',
      content: url,
      index: match.index,
    });

    lastIndex = match.index + url.length;
  }

  if (lastIndex < text.length) {
    parts.push({
      type: 'text',
      content: text.substring(lastIndex),
    });
  }

  return parts.length > 0 ? parts : [{ type: 'text', content: text }];
}

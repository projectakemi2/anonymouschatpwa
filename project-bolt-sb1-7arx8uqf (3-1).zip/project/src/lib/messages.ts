import { supabase } from './supabase';
import { getClientIP } from './device';
import { sendPushNotification } from './push';

export interface Message {
  id: string;
  user_id: string | null;
  content: string;
  images: string[];
  ip_address: string;
  room_id: string;
  created_at: string;
  deleted_at: string | null;
  deleted_by: string | null;
  user?: {
    display_name: string;
    is_admin: boolean;
    is_visible: boolean;
  };
}

export async function sendMessage(
  userId: string,
  content: string,
  images: string[] = [],
  roomId: string = 'default'
): Promise<Message> {
  if (content.length > 10000) {
    throw new Error('メッセージは10,000文字以内で入力してください');
  }

  if (images.length > 4) {
    throw new Error('画像は最大4枚までです');
  }

  const [userResult, ipAddress, rateLimitResult] = await Promise.all([
    supabase
      .from('anonymous_users')
      .select('id, device_id, display_name, is_admin, is_visible')
      .eq('id', userId)
      .maybeSingle(),
    getClientIP(),
    supabase
      .from('rate_limits')
      .select('last_message_at')
      .eq('user_id', userId)
      .maybeSingle()
  ]);

  if (!userResult.data) {
    throw new Error('ユーザー情報が見つかりません。再度ログインしてください。');
  }

  const userExists = userResult.data;

  if (rateLimitResult.data) {
    const lastMessageTime = new Date(rateLimitResult.data.last_message_at).getTime();
    if ((Date.now() - lastMessageTime) / 1000 < 2) {
      throw new Error('メッセージ送信は2秒に1回までです');
    }
  }

  const [ipBlockResult, deviceBlockResult] = await Promise.all([
    supabase
      .from('ip_blocks')
      .select('id')
      .eq('ip_address', ipAddress)
      .maybeSingle(),
    supabase
      .from('device_blocks')
      .select('id')
      .eq('device_id', userExists.device_id)
      .maybeSingle()
  ]);

  if (ipBlockResult.data) {
    throw new Error('このIPアドレスはブロックされています');
  }

  if (deviceBlockResult.data) {
    throw new Error('このデバイスはブロックされています');
  }

  const [insertResult] = await Promise.all([
    supabase
      .from('messages')
      .insert({
        user_id: userId,
        content,
        images,
        ip_address: ipAddress,
        room_id: roomId
      })
      .select('id, user_id, content, images, ip_address, room_id, created_at, deleted_at, deleted_by')
      .single(),
    supabase
      .from('rate_limits')
      .upsert({ user_id: userId, last_message_at: new Date().toISOString() }, { onConflict: 'user_id' })
  ]);

  if (insertResult.error) throw insertResult.error;

  const data = insertResult.data;
  const userData = { display_name: userExists.display_name, is_admin: userExists.is_admin, is_visible: userExists.is_visible };

  const message = { ...data, user: userData };

  if (userData.is_visible === true) {
    sendPushNotification(
      data.id,
      roomId,
      userId,
      userData.display_name || '匿名ユーザー',
      content || '画像を送信しました'
    ).catch(() => {});
  }

  return message;
}

export async function getMessages(roomId: string = 'default', limit = 50): Promise<Message[]> {
  const { data, error } = await supabase
    .from('messages')
    .select('id, user_id, content, images, ip_address, room_id, created_at, deleted_at, deleted_by')
    .eq('room_id', roomId)
    .is('deleted_at', null)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;

  if (!data || data.length === 0) {
    return [];
  }

  const userIds = [...new Set(data.map(msg => msg.user_id).filter(id => id !== null))];

  const userMap = new Map<string, { display_name: string; is_admin: boolean; is_visible: boolean }>();

  if (userIds.length > 0) {
    const { data: users } = await supabase
      .from('anonymous_users')
      .select('id, display_name, is_admin, is_visible')
      .in('id', userIds);

    (users || []).forEach(user => {
      userMap.set(user.id, { display_name: user.display_name, is_admin: user.is_admin, is_visible: user.is_visible });
    });
  }

  return data.map(msg => {
    const user = msg.user_id ? (userMap.get(msg.user_id) || { display_name: '削除済みユーザー', is_admin: false, is_visible: false }) : { display_name: '削除済みユーザー', is_admin: false, is_visible: false };
    return {
      ...msg,
      user
    };
  }).reverse();
}

export async function getAllMessages(limit = 1000): Promise<Message[]> {
  const { data, error } = await supabase
    .from('messages')
    .select('id, user_id, content, images, ip_address, room_id, created_at, deleted_at, deleted_by')
    .is('deleted_at', null)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;

  if (!data || data.length === 0) {
    return [];
  }

  // Filter out null user_ids before querying
  const userIds = [...new Set(data.map(msg => msg.user_id).filter(id => id !== null))];

  const userMap = new Map<string, { display_name: string; is_admin: boolean; is_visible: boolean }>();

  if (userIds.length > 0) {
    const { data: users } = await supabase
      .from('anonymous_users')
      .select('id, display_name, is_admin, is_visible')
      .in('id', userIds);

    (users || []).forEach(user => {
      userMap.set(user.id, { display_name: user.display_name, is_admin: user.is_admin, is_visible: user.is_visible });
    });
  }

  return data.map(msg => ({
    ...msg,
    user: msg.user_id ? (userMap.get(msg.user_id) || { display_name: '削除済みユーザー', is_admin: false, is_visible: false }) : { display_name: '削除済みユーザー', is_admin: false, is_visible: false }
  })).reverse();
}

export async function getMessagesBeforeId(beforeId: string, roomId: string = 'default', limit = 1000): Promise<Message[]> {
  const { data: beforeMessage } = await supabase
    .from('messages')
    .select('created_at, room_id')
    .eq('id', beforeId)
    .maybeSingle();

  if (!beforeMessage) {
    return [];
  }

  const { data, error } = await supabase
    .from('messages')
    .select('id, user_id, content, images, ip_address, room_id, created_at, deleted_at, deleted_by')
    .eq('room_id', roomId)
    .is('deleted_at', null)
    .lt('created_at', beforeMessage.created_at)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;

  if (!data || data.length === 0) {
    return [];
  }

  // Filter out null user_ids before querying
  const userIds = [...new Set(data.map(msg => msg.user_id).filter(id => id !== null))];

  const userMap = new Map<string, { display_name: string; is_admin: boolean; is_visible: boolean }>();

  if (userIds.length > 0) {
    const { data: users } = await supabase
      .from('anonymous_users')
      .select('id, display_name, is_admin, is_visible')
      .in('id', userIds);

    (users || []).forEach(user => {
      userMap.set(user.id, { display_name: user.display_name, is_admin: user.is_admin, is_visible: user.is_visible });
    });
  }

  return data.map(msg => ({
    ...msg,
    user: msg.user_id ? (userMap.get(msg.user_id) || { display_name: '削除済みユーザー', is_admin: false, is_visible: false }) : { display_name: '削除済みユーザー', is_admin: false, is_visible: false }
  })).reverse();
}

const ADMIN_PASSWORD = 'admin123';

async function callAdminFunction(action: string, adminId: string, params: any): Promise<void> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-operations`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      action,
      password: ADMIN_PASSWORD,
      adminId,
      ...params
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Operation failed');
  }

  return response.json();
}

export async function deleteMessage(messageId: string, adminId: string): Promise<void> {
  await callAdminFunction('delete_message', adminId, { messageId });
}

export async function deleteMessages(messageIds: string[], adminId: string): Promise<void> {
  await callAdminFunction('delete_messages', adminId, { messageIds });
}

const userCache = new Map<string, { data: { display_name: string; is_admin: boolean; is_visible: boolean }; ts: number }>();
const USER_CACHE_TTL = 60000;

async function getCachedUser(userId: string): Promise<{ display_name: string; is_admin: boolean; is_visible: boolean }> {
  const cached = userCache.get(userId);
  if (cached && Date.now() - cached.ts < USER_CACHE_TTL) {
    return cached.data;
  }

  const { data } = await supabase
    .from('anonymous_users')
    .select('display_name, is_admin, is_visible')
    .eq('id', userId)
    .maybeSingle();

  const userData = data || { display_name: '削除済みユーザー', is_admin: false, is_visible: false };
  userCache.set(userId, { data: userData, ts: Date.now() });
  return userData;
}

export function subscribeToMessages(
  roomId: string,
  onInsert: (message: Message) => void,
  onDelete?: (messageId: string) => void
): () => void {
  const channel = supabase
    .channel(`messages_channel_${roomId}`, {
      config: {
        broadcast: { self: true },
        presence: { key: '' }
      }
    })
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `room_id=eq.${roomId}`
      },
      async (payload) => {
        const messageData = payload.new as any;

        const userData = await getCachedUser(messageData.user_id);

        onInsert({
          id: messageData.id,
          user_id: messageData.user_id,
          content: messageData.content,
          images: messageData.images || [],
          ip_address: messageData.ip_address,
          room_id: messageData.room_id,
          created_at: messageData.created_at,
          deleted_at: messageData.deleted_at,
          deleted_by: messageData.deleted_by,
          user: userData
        });
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'messages',
        filter: `room_id=eq.${roomId}`
      },
      (payload) => {
        const messageData = payload.new as any;
        if (messageData.deleted_at && onDelete) {
          onDelete(messageData.id);
        }
      }
    )
    .subscribe();

  return () => {
    channel.unsubscribe();
  };
}

export async function getUserChatHistory(userId: string, roomId: string = 'default'): Promise<Message[]> {
  const { data, error } = await supabase
    .from('messages')
    .select(`
      *,
      user:anonymous_users!messages_user_id_fkey(display_name, is_admin, is_visible)
    `)
    .eq('user_id', userId)
    .eq('room_id', roomId)
    .order('created_at', { ascending: false })
    .limit(200);

  if (error) {
    console.error('Error fetching user chat history:', error);
    return [];
  }

  return data || [];
}

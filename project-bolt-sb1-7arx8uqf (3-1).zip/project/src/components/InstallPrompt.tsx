import { useState, useEffect } from 'react';
import { Smartphone, ExternalLink } from 'lucide-react';
import { markPWAInstalled, isIOS as checkIsIOS, isAndroid as checkIsAndroid } from '../lib/device';

interface InstallPromptProps {
  onComplete: () => void;
}

export default function InstallPrompt({ onComplete }: InstallPromptProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isInAppBrowser, setIsInAppBrowser] = useState(false);

  useEffect(() => {
    const userAgent = window.navigator.userAgent.toLowerCase();
    const ios = checkIsIOS();
    const android = checkIsAndroid();

    const inAppBrowser = /line|fban|fbav|instagram|twitter/.test(userAgent);

    setIsIOS(ios);
    setIsAndroid(android);
    setIsInAppBrowser(inAppBrowser);

    if ((window as any).deferredPrompt) {
      setDeferredPrompt((window as any).deferredPrompt);
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      (window as any).deferredPrompt = e;
    };

    const installableHandler = () => {
      if ((window as any).deferredPrompt) {
        setDeferredPrompt((window as any).deferredPrompt);
      }
    };

    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('pwainstallable', installableHandler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.removeEventListener('pwainstallable', installableHandler);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;

        if (outcome === 'accepted') {
          markPWAInstalled();
          onComplete();
        }

        setDeferredPrompt(null);
        (window as any).deferredPrompt = null;
      } catch (error) {
        console.error('Install prompt error:', error);
      }
    }
  };

  // iOSのアプリ内ブラウザの場合
  if (isInAppBrowser && isIOS) {
    const handleOpenInSafari = () => {
      const currentUrl = window.location.href;
      const safariUrl = currentUrl.replace(/^https?:\/\//, 'x-safari-https://');

      window.location.href = safariUrl;

      setTimeout(() => {
        alert('画面右上のメニュー（···）から「Safariで開く」を選択してください');
      }, 500);
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-orange-500 rounded-full mb-4">
              <ExternalLink className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-3">Safariで開く</h1>
            <p className="text-gray-600 leading-relaxed">
              アプリをインストールするには<br />Safariで開く必要があります
            </p>
          </div>

          <button
            onClick={handleOpenInSafari}
            className="w-full bg-orange-600 text-white rounded-2xl py-5 font-bold hover:bg-orange-700 transition-all transform hover:scale-105 text-xl shadow-lg mb-6"
          >
            Safariで開く
          </button>

          <div className="bg-orange-50 rounded-2xl p-6">
            <h3 className="font-bold text-gray-900 mb-3 text-sm">手動で開く場合</h3>
            <ol className="space-y-3 text-gray-700">
              <li className="flex items-start gap-3">
                <span className="font-bold text-orange-600 min-w-[20px]">1</span>
                <span className="text-sm">画面右上のメニュー（···）をタップ</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold text-orange-600 min-w-[20px]">2</span>
                <span className="text-sm">「Safariで開く」を選択</span>
              </li>
            </ol>
          </div>
        </div>
      </div>
    );
  }

  // Android（Chrome）の場合は優先的に処理
  if (isAndroid) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-blue-500 rounded-full mb-4">
              <Smartphone className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-3">参加者オープンチャット</h1>
            <p className="text-gray-600 leading-relaxed">
              このアプリはスマートフォンでの利用を<br />推奨しています
            </p>
          </div>

          <button
            onClick={onComplete}
            className="w-full bg-blue-600 text-white rounded-2xl py-5 font-bold hover:bg-blue-700 transition-all transform hover:scale-105 text-xl shadow-lg"
          >
            ココを押してログイン
          </button>
        </div>
      </div>
    );
  }

  // iPhone（Safari）の場合
  if (isIOS) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-blue-500 rounded-full mb-4">
              <Smartphone className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-3">参加者オープンチャット</h1>
            <p className="text-gray-600 leading-relaxed">
              このアプリはスマートフォンでの利用を<br />推奨しています
            </p>
          </div>

          <button
            onClick={onComplete}
            className="w-full bg-blue-600 text-white rounded-2xl py-5 font-bold hover:bg-blue-700 transition-all transform hover:scale-105 text-xl shadow-lg"
          >
            ココを押してログイン
          </button>
        </div>
      </div>
    );
  }

  // PC やその他のデバイス
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-6">
          <div className="inline-block p-4 bg-blue-500 rounded-full mb-4">
            <Smartphone className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-3">参加者オープンチャット</h1>
          <p className="text-gray-600 leading-relaxed">
            このアプリはスマートフォンでの利用を<br />推奨しています
          </p>
        </div>

        <button
          onClick={onComplete}
          className="w-full bg-blue-600 text-white rounded-2xl py-5 font-bold hover:bg-blue-700 transition-all transform hover:scale-105 text-xl shadow-lg"
        >
          ココを押してログイン
        </button>
      </div>
    </div>
  );
}

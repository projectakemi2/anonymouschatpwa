/*
  # Create account_groups table and link accounts to groups

  1. New Tables
    - `account_groups`
      - `id` (uuid, PK)
      - `name` (text, not null) - Group display name (e.g. "藤本なぎさ")
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Modified Tables
    - `accounts` - Add `group_id` (uuid, FK to account_groups, nullable)
    - `broadcasts` - Add `group_id` (uuid, FK to account_groups, nullable)

  3. Security
    - Enable RLS on `account_groups` table
    - Admin-only access policies for CRUD

  4. Notes
    - Existing accounts will have group_id = null (ungrouped)
    - Broadcasts with group_id = null will target all accounts (backward compatible)
    - Broadcasts with group_id set will only target accounts in that group
*/

CREATE TABLE IF NOT EXISTS account_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE account_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select account_groups"
  ON account_groups FOR SELECT TO authenticated USING (is_admin());
CREATE POLICY "Admins can insert account_groups"
  ON account_groups FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "Admins can update account_groups"
  ON account_groups FOR UPDATE TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());
CREATE POLICY "Admins can delete account_groups"
  ON account_groups FOR DELETE TO authenticated USING (is_admin());

CREATE TRIGGER account_groups_updated_at
  BEFORE UPDATE ON account_groups
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'accounts' AND column_name = 'group_id'
  ) THEN
    ALTER TABLE accounts ADD COLUMN group_id uuid REFERENCES account_groups(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_accounts_group_id ON accounts(group_id);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'broadcasts' AND column_name = 'group_id'
  ) THEN
    ALTER TABLE broadcasts ADD COLUMN group_id uuid REFERENCES account_groups(id) ON DELETE SET NULL;
  END IF;
END $$;

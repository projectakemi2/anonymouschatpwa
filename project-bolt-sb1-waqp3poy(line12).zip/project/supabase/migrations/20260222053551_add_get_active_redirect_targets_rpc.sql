/*
  # Add RPC function to get active redirect targets

  1. New Functions
    - `get_active_redirect_targets(p_link_slug text)` - Returns redirect link targets
      that belong to enabled (non-banned) accounts only.
      - Returns: id, friend_add_url, weight, link_id
      - Filters out targets whose linked account has is_enabled = false
      - Only returns targets for active redirect links (is_active = true)
      - Uses SECURITY DEFINER so anonymous users can call it without
        needing direct SELECT access to the accounts table

  2. Security
    - Function is SECURITY DEFINER to bypass RLS on accounts table
    - Only exposes the minimum data needed (target id, URL, weight, link id)
    - Does not expose any sensitive account information
    - Callable by anonymous users for the redirect page
*/

CREATE OR REPLACE FUNCTION get_active_redirect_targets(p_link_slug text)
RETURNS TABLE (
  link_id uuid,
  target_id uuid,
  friend_add_url text,
  weight integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT
    rl.id AS link_id,
    rlt.id AS target_id,
    rlt.friend_add_url,
    rlt.weight
  FROM redirect_links rl
  JOIN redirect_link_targets rlt ON rlt.redirect_link_id = rl.id
  LEFT JOIN accounts a ON a.id = rlt.account_id
  WHERE rl.slug = p_link_slug
    AND rl.is_active = true
    AND (rlt.account_id IS NULL OR a.is_enabled = true);
END;
$$;

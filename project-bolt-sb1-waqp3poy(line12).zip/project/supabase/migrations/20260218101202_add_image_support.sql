/*
  # Add image support for messages and broadcasts

  1. Modified Tables
    - `messages`
      - `image_url` (text, nullable) - URL of image sent/received
    - `broadcasts`
      - `image_url` (text, nullable) - URL of image to broadcast

  2. Storage
    - Create `line-images` public bucket for uploaded images
    - Add policy for authenticated users to upload images
    - Add public read access policy

  3. Notes
    - image_url is nullable since most messages are text-only
    - LINE API requires publicly accessible image URLs
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE messages ADD COLUMN image_url text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'broadcasts' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE broadcasts ADD COLUMN image_url text;
  END IF;
END $$;

INSERT INTO storage.buckets (id, name, public)
SELECT 'line-images', 'line-images', true
WHERE NOT EXISTS (
  SELECT 1 FROM storage.buckets WHERE id = 'line-images'
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Authenticated users can upload images' AND tablename = 'objects'
  ) THEN
    CREATE POLICY "Authenticated users can upload images"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (bucket_id = 'line-images');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Public can read images' AND tablename = 'objects'
  ) THEN
    CREATE POLICY "Public can read images"
      ON storage.objects FOR SELECT
      TO anon, authenticated
      USING (bucket_id = 'line-images');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Authenticated users can delete own images' AND tablename = 'objects'
  ) THEN
    CREATE POLICY "Authenticated users can delete own images"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (bucket_id = 'line-images');
  END IF;
END $$;

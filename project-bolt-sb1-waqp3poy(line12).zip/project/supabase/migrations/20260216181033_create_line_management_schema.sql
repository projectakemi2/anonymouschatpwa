/*
  # LINE Account Management System - Initial Schema

  1. New Tables
    - `admin_profiles` - Links auth.users to admin roles
      - `id` (uuid, PK, references auth.users)
      - `email` (text)
      - `role` (text, default 'admin')
      - `created_at` (timestamptz)
    - `accounts` - LINE official account configurations
      - `id` (uuid, PK)
      - `display_name` (text)
      - `channel_id` (text, unique) - Webhook destination value
      - `channel_secret` (text)
      - `access_token` (text)
      - `friend_add_url` (text)
      - `is_enabled` (boolean, default true)
    - `conversations` - Per-user conversation threads
      - `id` (uuid, PK)
      - `account_id` (uuid, FK)
      - `line_user_id` (text)
      - `line_display_name` (text, nullable)
      - `last_message_at` (timestamptz, nullable)
      - `unread_count` (integer, default 0)
      - `is_active`, `is_blocked` (boolean)
      - `followed_at`, `unfollowed_at` (timestamptz, nullable)
      - UNIQUE(account_id, line_user_id)
    - `messages` - Sent and received message log
      - `id` (uuid, PK)
      - `account_id`, `conversation_id` (uuid, FKs)
      - `direction` ('in' or 'out')
      - `message_type` ('text')
      - `text`, `raw_payload`, `event_id`, `status`
    - `broadcasts` - Broadcast job tracking
      - `id` (uuid, PK)
      - `text`, `status`, `total_targets`, `sent_count`, `failed_count`
    - `broadcast_targets` - Individual broadcast send targets
      - `id` (uuid, PK)
      - `broadcast_id`, `account_id` (uuid, FKs)
      - `line_user_id`, `status`, `error_message`, `sent_at`

  2. Security
    - RLS enabled on all tables
    - Admin-only access via admin_profiles membership check
    - is_admin() helper function for policy evaluation

  3. Functions and Triggers
    - is_admin() checks admin profile membership
    - handle_new_user() auto-creates admin profile on signup
    - update_updated_at() auto-updates timestamp columns

  4. Indexes
    - Optimized for webhook lookup, conversation listing, chat history, broadcast processing

  5. Realtime
    - Enabled for messages, conversations, broadcasts, broadcast_targets
*/

CREATE TABLE IF NOT EXISTS admin_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'admin',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE admin_profiles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM admin_profiles WHERE id = auth.uid()
  );
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.admin_profiles (id, email)
  VALUES (NEW.id, NEW.email);
  RETURN NEW;
END;
$$;

CREATE POLICY "Users can view own admin profile"
  ON admin_profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid());

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE IF NOT EXISTS accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name text NOT NULL DEFAULT '',
  channel_id text UNIQUE NOT NULL,
  channel_secret text NOT NULL,
  access_token text NOT NULL,
  friend_add_url text DEFAULT '',
  is_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select accounts"
  ON accounts FOR SELECT TO authenticated USING (is_admin());
CREATE POLICY "Admins can insert accounts"
  ON accounts FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "Admins can update accounts"
  ON accounts FOR UPDATE TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());
CREATE POLICY "Admins can delete accounts"
  ON accounts FOR DELETE TO authenticated USING (is_admin());

CREATE TRIGGER accounts_updated_at
  BEFORE UPDATE ON accounts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  line_user_id text NOT NULL,
  line_display_name text,
  last_message_at timestamptz,
  unread_count integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  is_blocked boolean NOT NULL DEFAULT false,
  followed_at timestamptz,
  unfollowed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (account_id, line_user_id)
);

ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select conversations"
  ON conversations FOR SELECT TO authenticated USING (is_admin());
CREATE POLICY "Admins can insert conversations"
  ON conversations FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "Admins can update conversations"
  ON conversations FOR UPDATE TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());
CREATE POLICY "Admins can delete conversations"
  ON conversations FOR DELETE TO authenticated USING (is_admin());

CREATE TRIGGER conversations_updated_at
  BEFORE UPDATE ON conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE INDEX IF NOT EXISTS idx_conversations_account ON conversations(account_id);
CREATE INDEX IF NOT EXISTS idx_conversations_account_last_msg ON conversations(account_id, last_message_at DESC);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  direction text NOT NULL CHECK (direction IN ('in', 'out')),
  message_type text NOT NULL DEFAULT 'text' CHECK (message_type IN ('text')),
  text text NOT NULL DEFAULT '',
  raw_payload jsonb,
  event_id text UNIQUE,
  status text NOT NULL DEFAULT 'received' CHECK (status IN ('received', 'sent', 'failed')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select messages"
  ON messages FOR SELECT TO authenticated USING (is_admin());
CREATE POLICY "Admins can insert messages"
  ON messages FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "Admins can update messages"
  ON messages FOR UPDATE TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());
CREATE POLICY "Admins can delete messages"
  ON messages FOR DELETE TO authenticated USING (is_admin());

CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);

CREATE TABLE IF NOT EXISTS broadcasts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'running', 'done', 'failed')),
  total_targets integer NOT NULL DEFAULT 0,
  sent_count integer NOT NULL DEFAULT 0,
  failed_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE broadcasts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select broadcasts"
  ON broadcasts FOR SELECT TO authenticated USING (is_admin());
CREATE POLICY "Admins can insert broadcasts"
  ON broadcasts FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "Admins can update broadcasts"
  ON broadcasts FOR UPDATE TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());
CREATE POLICY "Admins can delete broadcasts"
  ON broadcasts FOR DELETE TO authenticated USING (is_admin());

CREATE TABLE IF NOT EXISTS broadcast_targets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  broadcast_id uuid NOT NULL REFERENCES broadcasts(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  line_user_id text NOT NULL,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed')),
  error_message text,
  sent_at timestamptz
);

ALTER TABLE broadcast_targets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can select broadcast_targets"
  ON broadcast_targets FOR SELECT TO authenticated USING (is_admin());
CREATE POLICY "Admins can insert broadcast_targets"
  ON broadcast_targets FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "Admins can update broadcast_targets"
  ON broadcast_targets FOR UPDATE TO authenticated
  USING (is_admin()) WITH CHECK (is_admin());
CREATE POLICY "Admins can delete broadcast_targets"
  ON broadcast_targets FOR DELETE TO authenticated USING (is_admin());

CREATE INDEX IF NOT EXISTS idx_broadcast_targets_broadcast ON broadcast_targets(broadcast_id);
CREATE INDEX IF NOT EXISTS idx_broadcast_targets_status ON broadcast_targets(broadcast_id, status);

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE messages;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE conversations;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE broadcasts;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE broadcast_targets;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
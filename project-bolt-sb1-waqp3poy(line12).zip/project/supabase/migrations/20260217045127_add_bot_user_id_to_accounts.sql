/*
  # Add bot_user_id column to accounts table
  
  1. Changes
    - Add `bot_user_id` column to `accounts` table (text, nullable)
    - This stores the Bot's User ID (U-prefixed ID) used in LINE Webhook destination
    - Channel ID is the numeric ID, Bot User ID is what LINE sends in webhooks
  
  2. Notes
    - Existing accounts will have NULL bot_user_id
    - The import function will populate this automatically
    - Webhook will use bot_user_id to match accounts
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'accounts' AND column_name = 'bot_user_id'
  ) THEN
    ALTER TABLE accounts ADD COLUMN bot_user_id text;
  END IF;
END $$;

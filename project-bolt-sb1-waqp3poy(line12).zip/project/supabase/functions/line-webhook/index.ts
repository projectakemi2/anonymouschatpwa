import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function getSupabase() {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );
}

async function verifySignature(
  body: string,
  signature: string,
  channelSecret: string
): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(channelSecret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(body));
    const expected = btoa(String.fromCharCode(...new Uint8Array(sig)));
    return expected === signature;
  } catch (e) {
    console.error("Signature verification error:", e);
    return false;
  }
}

async function logWebhook(
  supabase: ReturnType<typeof createClient>,
  log: {
    destination: string | null;
    event_count: number;
    matched_account_id: string | null;
    match_method: string | null;
    signature_valid: boolean;
    error_message: string | null;
    raw_destination: string | null;
  }
) {
  try {
    await supabase.from("webhook_logs").insert(log);
  } catch (e) {
    console.error("Failed to write webhook log:", e);
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method === "GET") {
    return new Response("LINE Webhook is working!", {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "text/plain" },
    });
  }

  const supabase = getSupabase();

  try {
    const body = await req.text();
    console.log("Received webhook, body length:", body.length);

    if (!body || body.trim() === "") {
      await logWebhook(supabase, {
        destination: null,
        event_count: 0,
        matched_account_id: null,
        match_method: null,
        signature_valid: false,
        error_message: "Empty body",
        raw_destination: null,
      });
      return jsonResponse({ success: true });
    }

    let payload;
    try {
      payload = JSON.parse(body);
    } catch (e) {
      await logWebhook(supabase, {
        destination: null,
        event_count: 0,
        matched_account_id: null,
        match_method: null,
        signature_valid: false,
        error_message: `JSON parse error: ${(e as Error).message}`,
        raw_destination: null,
      });
      return jsonResponse({ success: true });
    }

    const events = payload.events || [];
    const destination = payload.destination;

    console.log("Events:", events.length, "Destination:", destination);

    if (!destination) {
      await logWebhook(supabase, {
        destination: null,
        event_count: events.length,
        matched_account_id: null,
        match_method: null,
        signature_valid: false,
        error_message: "No destination in payload",
        raw_destination: JSON.stringify(payload).substring(0, 200),
      });
      return jsonResponse({ success: true });
    }

    if (events.length === 0) {
      const signature =
        req.headers.get("X-Line-Signature") ||
        req.headers.get("x-line-signature");

      const { data: accounts } = await supabase
        .from("accounts")
        .select("*")
        .eq("is_enabled", true);

      let matchedId: string | null = null;
      let matchMethod: string | null = null;
      let sigValid = false;

      if (signature && accounts) {
        for (const acc of accounts) {
          const isValid = await verifySignature(body, signature, acc.channel_secret);
          if (isValid) {
            matchedId = acc.id;
            matchMethod = "signature_on_verify";
            sigValid = true;
            if (!acc.bot_user_id || acc.bot_user_id !== destination) {
              await supabase
                .from("accounts")
                .update({ bot_user_id: destination })
                .eq("id", acc.id);
            }
            break;
          }
        }
      }

      await logWebhook(supabase, {
        destination,
        event_count: 0,
        matched_account_id: matchedId,
        match_method: matchMethod || "verification_test",
        signature_valid: sigValid,
        error_message: sigValid ? null : "Verification test - no matching signature found",
        raw_destination: destination,
      });

      return jsonResponse({ success: true });
    }

    const { data: accounts } = await supabase
      .from("accounts")
      .select("*")
      .eq("is_enabled", true);

    const signature =
      req.headers.get("X-Line-Signature") ||
      req.headers.get("x-line-signature");

    if (!signature) {
      await logWebhook(supabase, {
        destination,
        event_count: events.length,
        matched_account_id: null,
        match_method: null,
        signature_valid: false,
        error_message: "No signature header",
        raw_destination: destination,
      });
      return jsonResponse({ success: true });
    }

    let account = null;
    let matchMethod = "none";

    const { data: accountByBotId } = await supabase
      .from("accounts")
      .select("*")
      .eq("bot_user_id", destination)
      .eq("is_enabled", true)
      .maybeSingle();

    if (accountByBotId) {
      const isValid = await verifySignature(
        body,
        signature,
        accountByBotId.channel_secret
      );
      if (isValid) {
        account = accountByBotId;
        matchMethod = "bot_user_id";
        console.log("Account found by bot_user_id:", account.id);
      } else {
        console.log("bot_user_id matched but signature invalid for account:", accountByBotId.id);
      }
    }

    if (!account && accounts && accounts.length > 0) {
      const triedAccounts: string[] = [];
      for (const acc of accounts) {
        const isValid = await verifySignature(
          body,
          signature,
          acc.channel_secret
        );
        triedAccounts.push(`${acc.channel_id}:${isValid}`);
        if (isValid) {
          account = acc;
          matchMethod = "signature_loop";
          console.log("Account found by signature:", account.id, "Channel:", account.channel_id);

          if (!account.bot_user_id || account.bot_user_id !== destination) {
            await supabase
              .from("accounts")
              .update({ bot_user_id: destination })
              .eq("id", account.id);
            account.bot_user_id = destination;
          }
          break;
        }
      }
      if (!account) {
        console.log("Signature verification failed for all accounts:", triedAccounts.join(", "));
      }
    }

    if (!account) {
      await logWebhook(supabase, {
        destination,
        event_count: events.length,
        matched_account_id: null,
        match_method: "none",
        signature_valid: false,
        error_message: `No matching account. Accounts checked: ${accounts?.length || 0}`,
        raw_destination: destination,
      });
      return jsonResponse({ success: true });
    }

    await logWebhook(supabase, {
      destination,
      event_count: events.length,
      matched_account_id: account.id as string,
      match_method: matchMethod,
      signature_valid: true,
      error_message: null,
      raw_destination: destination,
    });

    console.log("Using account:", account.id, "Channel:", account.channel_id);

    for (const event of events) {
      await processEvent(supabase, account, event);
    }

    return jsonResponse({ success: true });
  } catch (error) {
    console.error("Webhook error:", error);
    try {
      await logWebhook(supabase, {
        destination: null,
        event_count: 0,
        matched_account_id: null,
        match_method: null,
        signature_valid: false,
        error_message: `Unhandled error: ${(error as Error).message}`,
        raw_destination: null,
      });
    } catch (_) { /* ignore log errors */ }
    return jsonResponse({ success: true });
  }
});

async function processEvent(
  supabase: ReturnType<typeof createClient>,
  account: Record<string, unknown>,
  event: Record<string, unknown>
) {
  const eventType = event.type as string;
  const source = event.source as Record<string, unknown> | undefined;
  const userId = source?.userId as string | undefined;

  console.log("Processing event:", eventType, "User:", userId);

  if (!userId) return;

  const eventTimestamp = event.timestamp
    ? new Date(event.timestamp as number).toISOString()
    : new Date().toISOString();

  const webhookEventId = event.webhookEventId as string | undefined;
  const eventId =
    webhookEventId ||
    `${account.id}_${event.timestamp}_${userId}_${eventType}`;

  if (eventType === "message") {
    await handleMessageEvent(
      supabase,
      account,
      event,
      userId,
      eventTimestamp,
      eventId
    );
  } else if (eventType === "follow") {
    await handleFollowEvent(supabase, account, userId, eventTimestamp);
  } else if (eventType === "unfollow") {
    await handleUnfollowEvent(supabase, account, userId, eventTimestamp);
  }
}

async function getLineProfile(
  accessToken: string,
  userId: string
): Promise<string | null> {
  try {
    const res = await fetch(
      `https://api.line.me/v2/bot/profile/${userId}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (res.ok) {
      const profile = await res.json();
      return profile.displayName || null;
    }
  } catch (e) {
    console.error("Failed to fetch LINE profile:", e);
  }
  return null;
}

async function downloadLineContent(
  supabase: ReturnType<typeof createClient>,
  accessToken: string,
  messageId: string
): Promise<string | null> {
  try {
    const res = await fetch(
      `https://api-data.line.me/v2/bot/message/${messageId}/content`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (!res.ok) return null;

    const contentType = res.headers.get("content-type") || "image/jpeg";
    const ext = contentType.includes("png") ? "png" : contentType.includes("gif") ? "gif" : "jpg";
    const fileName = `received/${messageId}.${ext}`;
    const arrayBuffer = await res.arrayBuffer();

    const { error } = await supabase.storage
      .from("line-images")
      .upload(fileName, arrayBuffer, { contentType, upsert: true });

    if (error) {
      console.error("Failed to upload image to storage:", error);
      return null;
    }

    const { data: urlData } = supabase.storage
      .from("line-images")
      .getPublicUrl(fileName);

    return urlData.publicUrl;
  } catch (e) {
    console.error("Failed to download LINE content:", e);
    return null;
  }
}

async function handleMessageEvent(
  supabase: ReturnType<typeof createClient>,
  account: Record<string, unknown>,
  event: Record<string, unknown>,
  userId: string,
  timestamp: string,
  eventId: string
) {
  const { data: existingMsg } = await supabase
    .from("messages")
    .select("id")
    .eq("event_id", eventId)
    .maybeSingle();

  if (existingMsg) {
    console.log("Message already exists");
    return;
  }

  const message = event.message as Record<string, unknown> | undefined;
  const msgType = (message?.type as string) || "text";
  const text = (message?.text as string) || "";

  let imageUrl: string | null = null;
  if (msgType === "image" && message?.id) {
    imageUrl = await downloadLineContent(
      supabase,
      account.access_token as string,
      message.id as string
    );
  }

  const { data: existingConv } = await supabase
    .from("conversations")
    .select("id, unread_count, line_display_name")
    .eq("account_id", account.id)
    .eq("line_user_id", userId)
    .maybeSingle();

  let displayName: string | null = null;
  if (!existingConv?.line_display_name) {
    displayName = await getLineProfile(account.access_token as string, userId);
  }

  let convId: string;

  if (existingConv) {
    const updateData: Record<string, unknown> = {
      last_message_at: timestamp,
      is_active: true,
      unread_count: existingConv.unread_count + 1,
    };
    if (displayName) {
      updateData.line_display_name = displayName;
    }
    await supabase
      .from("conversations")
      .update(updateData)
      .eq("id", existingConv.id);
    convId = existingConv.id;
    console.log("Updated conversation:", convId);
  } else {
    const { data: newConv } = await supabase
      .from("conversations")
      .insert({
        account_id: account.id,
        line_user_id: userId,
        line_display_name: displayName,
        last_message_at: timestamp,
        is_active: true,
        unread_count: 1,
      })
      .select("id")
      .single();
    convId = newConv!.id;
    console.log("Created conversation:", convId);
  }

  await supabase.from("messages").insert({
    account_id: account.id,
    conversation_id: convId,
    direction: "in",
    message_type: imageUrl ? "image" : "text",
    text: imageUrl && !text ? "" : text,
    image_url: imageUrl,
    raw_payload: event,
    event_id: eventId,
    status: "received",
  });

  console.log("Message saved");
}

async function handleFollowEvent(
  supabase: ReturnType<typeof createClient>,
  account: Record<string, unknown>,
  userId: string,
  timestamp: string
) {
  let displayName = await getLineProfile(account.access_token as string, userId);

  const { data: existingConv } = await supabase
    .from("conversations")
    .select("id")
    .eq("account_id", account.id)
    .eq("line_user_id", userId)
    .maybeSingle();

  if (existingConv) {
    const updateData: Record<string, unknown> = {
      followed_at: timestamp,
      is_active: true,
      is_blocked: false,
      last_message_at: timestamp,
    };
    if (displayName) {
      updateData.line_display_name = displayName;
    }
    await supabase
      .from("conversations")
      .update(updateData)
      .eq("id", existingConv.id);
  } else {
    await supabase.from("conversations").insert({
      account_id: account.id,
      line_user_id: userId,
      line_display_name: displayName,
      followed_at: timestamp,
      is_active: true,
      is_blocked: false,
      last_message_at: timestamp,
    });
  }

  console.log("Follow event processed");
}

async function handleUnfollowEvent(
  supabase: ReturnType<typeof createClient>,
  account: Record<string, unknown>,
  userId: string,
  timestamp: string
) {
  await supabase
    .from("conversations")
    .update({
      is_blocked: true,
      is_active: false,
      unfollowed_at: timestamp,
    })
    .eq("account_id", account.id)
    .eq("line_user_id", userId);

  console.log("Unfollow event processed");
}

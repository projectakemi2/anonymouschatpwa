import type {
  Account,
  AccountGroup,
  Conversation,
  Message,
  Broadcast,
  ImportResult,
  RedirectLink,
} from '../types';

const API_BASE = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-api`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

function getAuthHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${ANON_KEY}`,
    'Content-Type': 'application/json',
    apikey: ANON_KEY,
  };
}

async function fetchApi<T = unknown>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const headers = getAuthHeaders();
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...headers, ...(options.headers as Record<string, string>) },
  });

  let data;
  try {
    data = await response.json();
  } catch (e) {
    console.error('Failed to parse response:', e);
    throw new Error(`API request failed (status ${response.status}): ${await response.text()}`);
  }

  if (!response.ok) {
    console.error('API error:', data);
    throw new Error(data.error || `API request failed (status ${response.status})`);
  }
  return data as T;
}

export async function listAccounts(): Promise<Account[]> {
  const data = await fetchApi<{ accounts: Account[] }>('/accounts');
  return data.accounts;
}

export async function createAccount(
  account: Partial<Account>
): Promise<Account> {
  const data = await fetchApi<{ account: Account }>('/accounts', {
    method: 'POST',
    body: JSON.stringify(account),
  });
  return data.account;
}

export async function importAccounts(
  textData: string,
  groupId?: string
): Promise<ImportResult> {
  return fetchApi<ImportResult>('/accounts/import', {
    method: 'POST',
    body: JSON.stringify({ text_data: textData, group_id: groupId }),
  });
}

export async function listConversations(
  accountId: string
): Promise<Conversation[]> {
  const data = await fetchApi<{ conversations: Conversation[] }>(
    `/conversations?account_id=${accountId}`
  );
  return data.conversations;
}

export async function listMessages(
  conversationId: string
): Promise<Message[]> {
  const data = await fetchApi<{ messages: Message[] }>(
    `/messages?conversation_id=${conversationId}`
  );
  return data.messages;
}

export async function markAsRead(conversationId: string): Promise<void> {
  await fetchApi(`/conversations/${conversationId}/read`, {
    method: 'POST',
  });
}

export async function uploadImage(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('file', file);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${ANON_KEY}`,
    apikey: ANON_KEY,
  };
  const response = await fetch(`${API_BASE}/upload-image`, {
    method: 'POST',
    headers,
    body: formData,
  });
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || 'Upload failed');
  }
  const data = await response.json();
  return data.url;
}

export async function sendMessage(
  accountId: string,
  conversationId: string,
  text: string,
  imageUrl?: string
): Promise<{ message: Message; success: boolean }> {
  return fetchApi('/send', {
    method: 'POST',
    body: JSON.stringify({
      account_id: accountId,
      conversation_id: conversationId,
      text,
      image_url: imageUrl,
    }),
  });
}

export async function createBroadcast(
  text: string,
  imageUrl?: string,
  groupId?: string
): Promise<{ broadcast: Broadcast }> {
  return fetchApi('/broadcast-all', {
    method: 'POST',
    body: JSON.stringify({ text, image_url: imageUrl, group_id: groupId }),
  });
}

export async function listGroups(): Promise<AccountGroup[]> {
  const data = await fetchApi<{ groups: AccountGroup[] }>('/account-groups');
  return data.groups;
}

export async function createGroup(name: string): Promise<AccountGroup> {
  const data = await fetchApi<{ group: AccountGroup }>('/account-groups', {
    method: 'POST',
    body: JSON.stringify({ name }),
  });
  return data.group;
}

export async function updateGroup(groupId: string, name: string): Promise<AccountGroup> {
  const data = await fetchApi<{ group: AccountGroup }>(`/account-groups/${groupId}`, {
    method: 'PUT',
    body: JSON.stringify({ name }),
  });
  return data.group;
}

export async function deleteGroup(groupId: string): Promise<void> {
  await fetchApi(`/account-groups/${groupId}`, {
    method: 'DELETE',
  });
}

export async function assignAccountGroup(accountId: string, groupId: string | null): Promise<void> {
  await fetchApi(`/accounts/${accountId}/group`, {
    method: 'PUT',
    body: JSON.stringify({ group_id: groupId }),
  });
}

export async function processBroadcast(
  broadcastId: string
): Promise<{ broadcast: Broadcast; remaining: number; processed: number }> {
  return fetchApi('/broadcast-process', {
    method: 'POST',
    body: JSON.stringify({ broadcast_id: broadcastId }),
  });
}

export async function listBroadcasts(): Promise<Broadcast[]> {
  const data = await fetchApi<{ broadcasts: Broadcast[] }>('/broadcasts');
  return data.broadcasts;
}

export async function getBroadcast(
  broadcastId: string
): Promise<Broadcast> {
  const data = await fetchApi<{ broadcast: Broadcast }>(
    `/broadcasts/${broadcastId}`
  );
  return data.broadcast;
}

export async function resendMessage(
  messageId: string,
  accountId: string,
  conversationId: string,
  text: string
): Promise<{ message: Message; success: boolean }> {
  return fetchApi('/resend', {
    method: 'POST',
    body: JSON.stringify({
      message_id: messageId,
      account_id: accountId,
      conversation_id: conversationId,
      text,
    }),
  });
}

export async function deleteAccount(accountId: string): Promise<void> {
  await fetchApi(`/accounts/${accountId}`, {
    method: 'DELETE',
  });
}

export async function listRedirectLinks(): Promise<RedirectLink[]> {
  const data = await fetchApi<{ redirect_links: RedirectLink[] }>('/redirect-links');
  return data.redirect_links;
}

export async function createRedirectLink(
  payload: {
    name: string;
    slug: string;
    distribution_mode?: 'weighted' | 'balanced';
    targets: Array<{ account_id: string; friend_add_url: string; weight?: number }>;
  }
): Promise<RedirectLink> {
  const data = await fetchApi<{ redirect_link: RedirectLink }>('/redirect-links', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return data.redirect_link;
}

export async function updateRedirectLink(
  linkId: string,
  payload: {
    name?: string;
    slug?: string;
    is_active?: boolean;
    distribution_mode?: 'weighted' | 'balanced';
    targets?: Array<{ account_id: string; friend_add_url: string; weight?: number }>;
  }
): Promise<RedirectLink> {
  const data = await fetchApi<{ redirect_link: RedirectLink }>(`/redirect-links/${linkId}`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
  return data.redirect_link;
}

export async function deleteRedirectLink(linkId: string): Promise<void> {
  await fetchApi(`/redirect-links/${linkId}`, {
    method: 'DELETE',
  });
}

import { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  ToggleLeft,
  ToggleRight,
  Link2,
  ChevronDown,
  ChevronUp,
  BarChart3,
  Pencil,
  Save,
  XCircle,
} from 'lucide-react';
import type { Account, AccountGroup, RedirectLink } from '../types';
import * as api from '../lib/api';

type DistributionMode = 'weighted' | 'balanced';

interface RedirectLinksModalProps {
  onClose: () => void;
  accounts: Account[];
  groups: AccountGroup[];
  selectedGroupId?: string | null;
}

function generateSlug(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

interface TargetRow {
  account_id: string;
  friend_add_url: string;
  weight: number;
}

export default function RedirectLinksModal({ onClose, accounts, groups, selectedGroupId }: RedirectLinksModalProps) {
  const [links, setLinks] = useState<RedirectLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [filterGroupId, setFilterGroupId] = useState<string>(selectedGroupId || '');

  const [newName, setNewName] = useState('');
  const [newSlug, setNewSlug] = useState('');
  const [newDistMode, setNewDistMode] = useState<DistributionMode>('weighted');
  const [newTargets, setNewTargets] = useState<TargetRow[]>([]);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');

  const [editingLinkId, setEditingLinkId] = useState<string | null>(null);
  const [editDistMode, setEditDistMode] = useState<DistributionMode>('weighted');
  const [editTargets, setEditTargets] = useState<TargetRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [editError, setEditError] = useState('');

  const filteredAccounts = filterGroupId
    ? accounts.filter((a) => a.group_id === filterGroupId)
    : accounts;

  useEffect(() => {
    loadLinks();
  }, []);

  const loadLinks = async () => {
    try {
      const data = await api.listRedirectLinks();
      setLinks(data);
    } catch {
      //
    } finally {
      setLoading(false);
    }
  };

  const handleStartCreate = () => {
    setNewName('');
    setNewSlug(generateSlug());
    setNewDistMode('weighted');
    setNewTargets(
      filteredAccounts.map((a) => ({
        account_id: a.id,
        friend_add_url: a.friend_add_url,
        weight: 1,
      }))
    );
    setError('');
    setShowCreate(true);
  };

  const handleCreate = async () => {
    if (!newName.trim()) {
      setError('名前を入力してください');
      return;
    }
    if (!newSlug.trim()) {
      setError('スラッグを入力してください');
      return;
    }
    if (newTargets.length === 0) {
      setError('少なくとも1つのターゲットURLを追加してください');
      return;
    }
    const validTargets = newTargets.filter((t) => t.friend_add_url.trim());
    if (validTargets.length === 0) {
      setError('有効なURLを入力してください');
      return;
    }
    setCreating(true);
    setError('');
    try {
      const link = await api.createRedirectLink({
        name: newName.trim(),
        slug: newSlug.trim(),
        distribution_mode: newDistMode,
        targets: validTargets,
      });
      setLinks((prev) => [link, ...prev]);
      setShowCreate(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : '作成に失敗しました');
    } finally {
      setCreating(false);
    }
  };

  const handleToggleActive = async (link: RedirectLink) => {
    try {
      const updated = await api.updateRedirectLink(link.id, {
        is_active: !link.is_active,
      });
      setLinks((prev) => prev.map((l) => (l.id === link.id ? updated : l)));
    } catch {
      //
    }
  };

  const handleDelete = async (linkId: string) => {
    if (!confirm('このリダイレクトリンクを削除しますか？')) return;
    try {
      await api.deleteRedirectLink(linkId);
      setLinks((prev) => prev.filter((l) => l.id !== linkId));
    } catch {
      alert('削除に失敗しました');
    }
  };

  const handleCopy = (slug: string, linkId: string) => {
    const url = `${window.location.origin}/r/${slug}`;
    navigator.clipboard.writeText(url);
    setCopiedId(linkId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleStartEdit = (link: RedirectLink) => {
    setEditingLinkId(link.id);
    setEditDistMode(link.distribution_mode || 'weighted');
    setEditTargets(
      link.targets.map((t) => ({
        account_id: t.account_id,
        friend_add_url: t.friend_add_url,
        weight: t.weight,
      }))
    );
    setEditError('');
    if (expandedId !== link.id) setExpandedId(link.id);
  };

  const handleCancelEdit = () => {
    setEditingLinkId(null);
    setEditDistMode('weighted');
    setEditTargets([]);
    setEditError('');
  };

  const handleSaveEdit = async (linkId: string) => {
    const validTargets = editTargets.filter((t) => t.friend_add_url.trim());
    if (validTargets.length === 0) {
      setEditError('少なくとも1つの有効なURLが必要です');
      return;
    }
    setSaving(true);
    setEditError('');
    try {
      const updated = await api.updateRedirectLink(linkId, {
        distribution_mode: editDistMode,
        targets: validTargets,
      });
      setLinks((prev) => prev.map((l) => (l.id === linkId ? updated : l)));
      setEditingLinkId(null);
      setEditTargets([]);
    } catch (e) {
      setEditError(e instanceof Error ? e.message : '保存に失敗しました');
    } finally {
      setSaving(false);
    }
  };

  const addEditTarget = () => {
    setEditTargets((prev) => [
      ...prev,
      { account_id: '', friend_add_url: '', weight: 1 },
    ]);
  };

  const removeEditTarget = (index: number) => {
    setEditTargets((prev) => prev.filter((_, i) => i !== index));
  };

  const updateEditTarget = (index: number, field: keyof TargetRow, value: string | number) => {
    setEditTargets((prev) =>
      prev.map((t, i) => (i === index ? { ...t, [field]: value } : t))
    );
  };

  const handleEditAccountSelect = (index: number, accountId: string) => {
    const account = accounts.find((a) => a.id === accountId);
    if (account) {
      setEditTargets((prev) =>
        prev.map((t, i) =>
          i === index
            ? { ...t, account_id: accountId, friend_add_url: account.friend_add_url }
            : t
        )
      );
    }
  };

  const addTarget = () => {
    setNewTargets((prev) => [
      ...prev,
      { account_id: '', friend_add_url: '', weight: 1 },
    ]);
  };

  const removeTarget = (index: number) => {
    setNewTargets((prev) => prev.filter((_, i) => i !== index));
  };

  const updateTarget = (index: number, field: keyof TargetRow, value: string | number) => {
    setNewTargets((prev) =>
      prev.map((t, i) => (i === index ? { ...t, [field]: value } : t))
    );
  };

  const handleAccountSelect = (index: number, accountId: string) => {
    const account = accounts.find((a) => a.id === accountId);
    if (account) {
      setNewTargets((prev) =>
        prev.map((t, i) =>
          i === index
            ? { ...t, account_id: accountId, friend_add_url: account.friend_add_url }
            : t
        )
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col mx-4">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-sky-50 rounded-lg flex items-center justify-center">
              <Link2 className="w-4.5 h-4.5 text-sky-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">リダイレクトリンク</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {groups.length > 0 && (
            <div className="flex items-center gap-2">
              <label className="text-xs font-medium text-gray-500 whitespace-nowrap">グループ</label>
              <select
                value={filterGroupId}
                onChange={(e) => {
                  setFilterGroupId(e.target.value);
                  if (showCreate) setShowCreate(false);
                }}
                className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400/20 focus:border-sky-400 transition-all bg-white"
              >
                <option value="">すべてのアカウント</option>
                {groups.map((g) => (
                  <option key={g.id} value={g.id}>{g.name}</option>
                ))}
              </select>
            </div>
          )}

          {!showCreate && (
            <button
              onClick={handleStartCreate}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-gray-200 rounded-xl text-sm font-medium text-gray-500 hover:border-sky-300 hover:text-sky-600 hover:bg-sky-50/50 transition-all"
            >
              <Plus className="w-4 h-4" />
              新しいリダイレクトリンクを作成
            </button>
          )}

          {showCreate && (
            <div className="border border-sky-200 bg-sky-50/30 rounded-xl p-4 space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">新規リンク作成</h3>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">名前</label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="キャンペーンA"
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">スラッグ</label>
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-gray-400">/r/</span>
                    <input
                      type="text"
                      value={newSlug}
                      onChange={(e) => setNewSlug(e.target.value.replace(/[^a-zA-Z0-9_-]/g, ''))}
                      className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg border border-gray-200 p-3">
                <label className="block text-xs font-semibold text-gray-700 mb-2">配信モード</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewDistMode('weighted')}
                    className={`relative px-3 py-2.5 rounded-lg text-xs font-medium border-2 transition-all text-left ${
                      newDistMode === 'weighted'
                        ? 'border-sky-400 bg-sky-50 text-sky-700 ring-2 ring-sky-400/20'
                        : 'border-gray-200 bg-gray-50 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    {newDistMode === 'weighted' && (
                      <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-sky-500 rounded-full flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 text-white" />
                      </span>
                    )}
                    <BarChart3 className="w-4 h-4 mb-1" />
                    ウェイト配分
                    <span className="block text-[10px] font-normal mt-0.5 opacity-70">
                      設定した比率で振り分け
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewDistMode('balanced')}
                    className={`relative px-3 py-2.5 rounded-lg text-xs font-medium border-2 transition-all text-left ${
                      newDistMode === 'balanced'
                        ? 'border-emerald-400 bg-emerald-50 text-emerald-700 ring-2 ring-emerald-400/20'
                        : 'border-gray-200 bg-gray-50 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    {newDistMode === 'balanced' && (
                      <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 text-white" />
                      </span>
                    )}
                    <ToggleRight className="w-4 h-4 mb-1" />
                    友だち数均等化
                    <span className="block text-[10px] font-normal mt-0.5 opacity-70">
                      少ないアカウントを優先
                    </span>
                  </button>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-medium text-gray-600">
                    ターゲットURL ({newTargets.length})
                  </label>
                  <button
                    onClick={addTarget}
                    className="text-xs text-sky-600 hover:text-sky-700 font-medium flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    追加
                  </button>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {newTargets.map((target, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-2 bg-white rounded-lg p-2 border border-gray-100"
                    >
                      <select
                        value={target.account_id}
                        onChange={(e) => handleAccountSelect(i, e.target.value)}
                        className="flex-shrink-0 w-36 px-2 py-1.5 border border-gray-200 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-sky-400"
                      >
                        <option value="">アカウント選択</option>
                        {filteredAccounts.map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.display_name}
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        value={target.friend_add_url}
                        onChange={(e) => updateTarget(i, 'friend_add_url', e.target.value)}
                        placeholder="https://line.me/R/ti/p/..."
                        className="flex-1 px-2 py-1.5 border border-gray-200 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-sky-400"
                      />
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={target.weight}
                        onChange={(e) =>
                          updateTarget(i, 'weight', Math.max(1, parseInt(e.target.value) || 1))
                        }
                        className="w-14 px-2 py-1.5 border border-gray-200 rounded-md text-xs text-center focus:outline-none focus:ring-2 focus:ring-sky-400"
                        title="ウェイト"
                      />
                      <button
                        onClick={() => removeTarget(i)}
                        className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
                <p className="text-[10px] text-gray-400 mt-1">
                  ウェイトが高いほど選ばれる確率が上がります
                </p>
              </div>

              {error && (
                <p className="text-xs text-red-500 bg-red-50 px-3 py-2 rounded-lg">{error}</p>
              )}

              <div className="flex items-center gap-2 justify-end">
                <button
                  onClick={() => setShowCreate(false)}
                  className="px-4 py-2 text-xs font-medium text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  キャンセル
                </button>
                <button
                  onClick={handleCreate}
                  disabled={creating}
                  className="px-4 py-2 text-xs font-medium text-white bg-sky-500 hover:bg-sky-600 disabled:opacity-50 rounded-lg transition-colors"
                >
                  {creating ? '作成中...' : '作成'}
                </button>
              </div>
            </div>
          )}

          {loading ? (
            <div className="flex justify-center py-12">
              <div className="w-6 h-6 border-2 border-gray-200 border-t-sky-500 rounded-full animate-spin" />
            </div>
          ) : links.length === 0 ? (
            <div className="text-center py-12 text-sm text-gray-400">
              リダイレクトリンクがありません
            </div>
          ) : (
            <div className="space-y-2">
              {links.map((link) => {
                const isExpanded = expandedId === link.id;
                const isCopied = copiedId === link.id;
                const totalWeight = link.targets.reduce((sum, t) => sum + t.weight, 0);

                return (
                  <div
                    key={link.id}
                    className="border border-gray-200 rounded-xl overflow-hidden hover:border-gray-300 transition-colors"
                  >
                    <div className="flex items-center gap-3 p-3.5">
                      <button
                        onClick={() => handleToggleActive(link)}
                        className="flex-shrink-0"
                        title={link.is_active ? '有効' : '無効'}
                      >
                        {link.is_active ? (
                          <ToggleRight className="w-6 h-6 text-emerald-500" />
                        ) : (
                          <ToggleLeft className="w-6 h-6 text-gray-300" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-gray-900 truncate">
                            {link.name || '(名前なし)'}
                          </span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                              link.is_active
                                ? 'bg-emerald-50 text-emerald-600'
                                : 'bg-gray-100 text-gray-400'
                            }`}
                          >
                            {link.is_active ? '有効' : '無効'}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="text-xs text-gray-400 font-mono">/r/{link.slug}</span>
                          <span className="text-xs text-gray-400 flex items-center gap-1">
                            <BarChart3 className="w-3 h-3" />
                            {link.click_count}回
                          </span>
                          <span className="text-xs text-gray-400">
                            {link.targets.length}件のURL
                          </span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                              link.distribution_mode === 'balanced'
                                ? 'bg-emerald-50 text-emerald-600'
                                : 'bg-gray-100 text-gray-500'
                            }`}
                          >
                            {link.distribution_mode === 'balanced' ? '均等化' : 'ウェイト'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleCopy(link.slug, link.id)}
                          className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-400 hover:text-gray-600"
                          title="URLをコピー"
                        >
                          {isCopied ? (
                            <Check className="w-4 h-4 text-emerald-500" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                        <button
                          onClick={() => {
                            if (isExpanded && editingLinkId === link.id) {
                              handleCancelEdit();
                            }
                            setExpandedId(isExpanded ? null : link.id);
                          }}
                          className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-400 hover:text-gray-600"
                        >
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </button>
                        <button
                          onClick={() => handleDelete(link.id)}
                          className="p-1.5 rounded-lg hover:bg-red-50 transition-colors text-gray-400 hover:text-red-500"
                          title="削除"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="border-t border-gray-100 bg-gray-50/50 p-3.5">
                        {editingLinkId === link.id ? (
                          <div className="space-y-3">
                            <div>
                              <label className="block text-xs font-medium text-gray-500 mb-1.5">配信モード</label>
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => setEditDistMode('weighted')}
                                  className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${
                                    editDistMode === 'weighted'
                                      ? 'border-sky-400 bg-sky-50 text-sky-700'
                                      : 'border-gray-200 bg-white text-gray-500 hover:border-gray-300'
                                  }`}
                                >
                                  ウェイト配分
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditDistMode('balanced')}
                                  className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${
                                    editDistMode === 'balanced'
                                      ? 'border-emerald-400 bg-emerald-50 text-emerald-700'
                                      : 'border-gray-200 bg-white text-gray-500 hover:border-gray-300'
                                  }`}
                                >
                                  友だち数均等化
                                </button>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-medium text-gray-500">
                                ターゲットURL編集 ({editTargets.length})
                              </span>
                              <button
                                onClick={addEditTarget}
                                className="text-xs text-sky-600 hover:text-sky-700 font-medium flex items-center gap-1"
                              >
                                <Plus className="w-3 h-3" />
                                追加
                              </button>
                            </div>
                            <div className="space-y-2 max-h-52 overflow-y-auto">
                              {editTargets.map((target, i) => (
                                <div
                                  key={i}
                                  className="flex items-center gap-2 bg-white rounded-lg p-2 border border-gray-200"
                                >
                                  <select
                                    value={target.account_id}
                                    onChange={(e) => handleEditAccountSelect(i, e.target.value)}
                                    className="flex-shrink-0 w-36 px-2 py-1.5 border border-gray-200 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-sky-400"
                                  >
                                    <option value="">アカウント選択</option>
                                    {accounts.map((a) => (
                                      <option key={a.id} value={a.id}>
                                        {a.display_name}
                                      </option>
                                    ))}
                                  </select>
                                  <input
                                    type="text"
                                    value={target.friend_add_url}
                                    onChange={(e) => updateEditTarget(i, 'friend_add_url', e.target.value)}
                                    placeholder="https://line.me/R/ti/p/..."
                                    className="flex-1 px-2 py-1.5 border border-gray-200 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-sky-400"
                                  />
                                  <input
                                    type="number"
                                    min={1}
                                    max={100}
                                    value={target.weight}
                                    onChange={(e) =>
                                      updateEditTarget(i, 'weight', Math.max(1, parseInt(e.target.value) || 1))
                                    }
                                    className="w-14 px-2 py-1.5 border border-gray-200 rounded-md text-xs text-center focus:outline-none focus:ring-2 focus:ring-sky-400"
                                    title="ウェイト"
                                  />
                                  <button
                                    onClick={() => removeEditTarget(i)}
                                    className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ))}
                            </div>
                            <p className="text-[10px] text-gray-400">
                              ウェイトが高いほど選ばれる確率が上がります
                            </p>
                            {editError && (
                              <p className="text-xs text-red-500 bg-red-50 px-3 py-2 rounded-lg">{editError}</p>
                            )}
                            <div className="flex items-center gap-2 justify-end">
                              <button
                                onClick={handleCancelEdit}
                                className="px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 rounded-lg transition-colors flex items-center gap-1"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                キャンセル
                              </button>
                              <button
                                onClick={() => handleSaveEdit(link.id)}
                                disabled={saving}
                                className="px-3 py-1.5 text-xs font-medium text-white bg-sky-500 hover:bg-sky-600 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1"
                              >
                                <Save className="w-3.5 h-3.5" />
                                {saving ? '保存中...' : '保存'}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-xs font-medium text-gray-500">ターゲットURL</span>
                              <button
                                onClick={() => handleStartEdit(link)}
                                className="text-xs text-sky-600 hover:text-sky-700 font-medium flex items-center gap-1 px-2 py-1 rounded-md hover:bg-sky-50 transition-colors"
                              >
                                <Pencil className="w-3 h-3" />
                                編集
                              </button>
                            </div>
                            <div className="space-y-1.5">
                              {link.targets.map((target) => {
                                const pct =
                                  totalWeight > 0
                                    ? Math.round((target.weight / totalWeight) * 100)
                                    : 0;
                                return (
                                  <div
                                    key={target.id}
                                    className="flex items-center gap-2 bg-white rounded-lg px-3 py-2 border border-gray-100"
                                  >
                                    <a
                                      href={target.friend_add_url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="flex-1 text-xs text-sky-600 hover:text-sky-700 truncate flex items-center gap-1"
                                    >
                                      {target.friend_add_url}
                                      <ExternalLink className="w-3 h-3 flex-shrink-0" />
                                    </a>
                                    <span className="text-[10px] text-gray-400 flex-shrink-0">
                                      ウェイト: {target.weight} ({pct}%)
                                    </span>
                                    <span className="text-[10px] text-gray-400 flex-shrink-0">
                                      {target.click_count}回
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                            <div className="mt-2 text-[10px] text-gray-400">
                              完全URL: {window.location.origin}/r/{link.slug}
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

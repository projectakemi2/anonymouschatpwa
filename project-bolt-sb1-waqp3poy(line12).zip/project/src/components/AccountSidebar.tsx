import { Upload, MessageCircle, Trash2, FolderPlus, Folder, FolderOpen, ChevronRight, ChevronDown, MoreHorizontal, Pencil, X, Check, ArrowRightLeft, Mail } from 'lucide-react';
import { useState, useMemo, useRef, useEffect } from 'react';
import type { Account, AccountGroup } from '../types';

interface AccountSidebarProps {
  accounts: Account[];
  groups: AccountGroup[];
  selectedId: string | null;
  selectedGroupId: string | null;
  onSelect: (id: string) => void;
  onImport: () => void;
  onDelete: (id: string) => void;
  onCreateGroup: (name: string) => void;
  onRenameGroup: (id: string, name: string) => void;
  onDeleteGroup: (id: string) => void;
  onAssignGroup: (accountId: string, groupId: string | null) => void;
  onSelectGroup: (groupId: string | null) => void;
  loading: boolean;
}

export default function AccountSidebar({
  accounts,
  groups,
  selectedId,
  selectedGroupId,
  onSelect,
  onImport,
  onDelete,
  onCreateGroup,
  onRenameGroup,
  onDeleteGroup,
  onAssignGroup,
  onSelectGroup,
  loading,
}: AccountSidebarProps) {
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [showUngrouped, setShowUngrouped] = useState(true);
  const [creatingGroup, setCreatingGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [editGroupName, setEditGroupName] = useState('');
  const [groupMenuId, setGroupMenuId] = useState<string | null>(null);
  const [moveMenuAccountId, setMoveMenuAccountId] = useState<string | null>(null);
  const [unreadFilter, setUnreadFilter] = useState<Set<string>>(new Set());
  const newGroupInputRef = useRef<HTMLInputElement>(null);
  const editGroupInputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (creatingGroup && newGroupInputRef.current) {
      newGroupInputRef.current.focus();
    }
  }, [creatingGroup]);

  useEffect(() => {
    if (editingGroupId && editGroupInputRef.current) {
      editGroupInputRef.current.focus();
    }
  }, [editingGroupId]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setGroupMenuId(null);
        setMoveMenuAccountId(null);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(groupId)) next.delete(groupId);
      else next.add(groupId);
      return next;
    });
  };

  const accountsByGroup = useMemo(() => {
    const map: Record<string, Account[]> = { ungrouped: [] };
    for (const g of groups) {
      map[g.id] = [];
    }
    for (const a of accounts) {
      if (a.group_id && map[a.group_id]) {
        map[a.group_id].push(a);
      } else {
        map.ungrouped.push(a);
      }
    }
    return map;
  }, [accounts, groups]);

  const toggleUnreadFilter = (key: string) => {
    setUnreadFilter((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const filterAccounts = (list: Account[], key: string) => {
    if (!unreadFilter.has(key)) return list;
    return list.filter((a) => (a.total_unread ?? 0) > 0);
  };

  const handleCreateGroup = () => {
    if (newGroupName.trim()) {
      onCreateGroup(newGroupName.trim());
      setNewGroupName('');
      setCreatingGroup(false);
    }
  };

  const handleRenameGroup = (id: string) => {
    if (editGroupName.trim()) {
      onRenameGroup(id, editGroupName.trim());
      setEditingGroupId(null);
      setEditGroupName('');
    }
  };

  const ungroupedAccounts = accountsByGroup.ungrouped || [];

  return (
    <div className="w-64 bg-gray-900 text-white flex flex-col shrink-0 h-full">
      <div className="p-3 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            グループ
          </h2>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCreatingGroup(true)}
              className="p-1 rounded hover:bg-gray-800 transition-colors"
              title="グループを作成"
            >
              <FolderPlus className="w-3.5 h-3.5 text-gray-400" />
            </button>
            <button
              onClick={onImport}
              className="p-1 rounded hover:bg-gray-800 transition-colors"
              title="アカウントをインポート"
            >
              <Upload className="w-3.5 h-3.5 text-gray-400" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-1">
        {loading ? (
          <div className="px-3 py-8 text-center">
            <div className="w-5 h-5 border-2 border-gray-700 border-t-gray-400 rounded-full animate-spin mx-auto" />
          </div>
        ) : (
          <>
            {creatingGroup && (
              <div className="px-2 py-1.5">
                <div className="flex items-center gap-1.5 bg-gray-800 rounded-lg px-2 py-1.5">
                  <Folder className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <input
                    ref={newGroupInputRef}
                    type="text"
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleCreateGroup();
                      if (e.key === 'Escape') { setCreatingGroup(false); setNewGroupName(''); }
                    }}
                    placeholder="グループ名..."
                    className="flex-1 bg-transparent text-sm text-white placeholder-gray-500 outline-none min-w-0"
                  />
                  <button onClick={handleCreateGroup} className="p-0.5 hover:bg-gray-700 rounded transition-colors">
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  </button>
                  <button onClick={() => { setCreatingGroup(false); setNewGroupName(''); }} className="p-0.5 hover:bg-gray-700 rounded transition-colors">
                    <X className="w-3.5 h-3.5 text-gray-500" />
                  </button>
                </div>
              </div>
            )}

            {groups.map((group) => {
              const isExpanded = expandedGroups.has(group.id);
              const groupAccounts = accountsByGroup[group.id] || [];
              const isSelected = selectedGroupId === group.id;

              return (
                <div key={group.id}>
                  <div
                    className={`group relative flex items-center px-2 py-1 ${
                      isSelected ? 'bg-gray-800' : 'hover:bg-gray-800/50'
                    }`}
                  >
                    {editingGroupId === group.id ? (
                      <div className="flex items-center gap-1.5 flex-1 px-1">
                        <Folder className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <input
                          ref={editGroupInputRef}
                          type="text"
                          value={editGroupName}
                          onChange={(e) => setEditGroupName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleRenameGroup(group.id);
                            if (e.key === 'Escape') { setEditingGroupId(null); setEditGroupName(''); }
                          }}
                          className="flex-1 bg-transparent text-sm text-white outline-none min-w-0"
                        />
                        <button onClick={() => handleRenameGroup(group.id)} className="p-0.5 hover:bg-gray-700 rounded">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        </button>
                        <button onClick={() => { setEditingGroupId(null); setEditGroupName(''); }} className="p-0.5 hover:bg-gray-700 rounded">
                          <X className="w-3.5 h-3.5 text-gray-500" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          onClick={() => toggleGroup(group.id)}
                          className="p-0.5 mr-0.5 shrink-0"
                        >
                          {isExpanded
                            ? <ChevronDown className="w-3 h-3 text-gray-500" />
                            : <ChevronRight className="w-3 h-3 text-gray-500" />
                          }
                        </button>
                        <button
                          onClick={() => { onSelectGroup(group.id); if (!isExpanded) toggleGroup(group.id); }}
                          className="flex items-center gap-1.5 flex-1 min-w-0 py-0.5"
                        >
                          {isExpanded
                            ? <FolderOpen className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            : <Folder className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          }
                          <span className="text-sm font-medium truncate">{group.name}</span>
                          <span className="text-[10px] text-gray-500 ml-auto shrink-0">{groupAccounts.length}</span>
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleUnreadFilter(group.id);
                          }}
                          className={`p-1 rounded transition-all shrink-0 ${
                            unreadFilter.has(group.id)
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'opacity-0 group-hover:opacity-100 text-gray-500 hover:text-gray-300 hover:bg-gray-700'
                          }`}
                          title={unreadFilter.has(group.id) ? '全て表示' : '未読のみ'}
                        >
                          <Mail className="w-3 h-3" />
                        </button>
                        <div className="relative">
                          <button
                            onClick={(e) => { e.stopPropagation(); setGroupMenuId(groupMenuId === group.id ? null : group.id); }}
                            className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-gray-700 transition-all shrink-0"
                          >
                            <MoreHorizontal className="w-3.5 h-3.5 text-gray-400" />
                          </button>
                          {groupMenuId === group.id && (
                            <div ref={menuRef} className="absolute right-0 top-full mt-1 bg-gray-800 border border-gray-700 rounded-lg shadow-xl z-50 py-1 min-w-[140px]">
                              <button
                                onClick={() => {
                                  setEditingGroupId(group.id);
                                  setEditGroupName(group.name);
                                  setGroupMenuId(null);
                                }}
                                className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-gray-300 hover:bg-gray-700 transition-colors"
                              >
                                <Pencil className="w-3 h-3" />
                                名前を変更
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`「${group.name}」を削除しますか？\nアカウントは削除されず、未分類に移動します。`)) {
                                    onDeleteGroup(group.id);
                                  }
                                  setGroupMenuId(null);
                                }}
                                className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-red-400 hover:bg-gray-700 transition-colors"
                              >
                                <Trash2 className="w-3 h-3" />
                                削除
                              </button>
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>

                  {isExpanded && (() => {
                    const visibleAccounts = filterAccounts(groupAccounts, group.id);
                    return (
                    <div className="ml-3">
                      {groupAccounts.length === 0 ? (
                        <div className="px-3 py-2 text-[10px] text-gray-600">
                          アカウントがありません
                        </div>
                      ) : visibleAccounts.length === 0 ? (
                        <div className="px-3 py-2 text-[10px] text-gray-600">
                          未読のアカウントはありません
                        </div>
                      ) : (
                        visibleAccounts.map((account) => (
                          <AccountItem
                            key={account.id}
                            account={account}
                            isSelected={selectedId === account.id}
                            onSelect={onSelect}
                            onDelete={onDelete}
                            groups={groups}
                            onAssignGroup={onAssignGroup}
                            moveMenuAccountId={moveMenuAccountId}
                            setMoveMenuAccountId={setMoveMenuAccountId}
                            menuRef={menuRef}
                          />
                        ))
                      )}
                    </div>
                    );
                  })()}
                </div>
              );
            })}

            {ungroupedAccounts.length > 0 && (
              <div>
                <div className="flex items-center px-2 py-1 hover:bg-gray-800/50">
                  <button
                    onClick={() => setShowUngrouped(!showUngrouped)}
                    className="p-0.5 mr-0.5 shrink-0"
                  >
                    {showUngrouped
                      ? <ChevronDown className="w-3 h-3 text-gray-500" />
                      : <ChevronRight className="w-3 h-3 text-gray-500" />
                    }
                  </button>
                  <button
                    onClick={() => { onSelectGroup(null); setShowUngrouped(true); }}
                    className="flex items-center gap-1.5 flex-1 min-w-0 py-0.5"
                  >
                    <Folder className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                    <span className="text-sm text-gray-400 truncate">未分類</span>
                    <span className="text-[10px] text-gray-600 ml-auto shrink-0">{ungroupedAccounts.length}</span>
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleUnreadFilter('ungrouped');
                    }}
                    className={`p-1 rounded transition-all shrink-0 ${
                      unreadFilter.has('ungrouped')
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'text-gray-600 hover:text-gray-400 hover:bg-gray-700'
                    }`}
                    title={unreadFilter.has('ungrouped') ? '全て表示' : '未読のみ'}
                  >
                    <Mail className="w-3 h-3" />
                  </button>
                </div>
                {showUngrouped && (() => {
                  const visibleUngrouped = filterAccounts(ungroupedAccounts, 'ungrouped');
                  return (
                  <div className="ml-3">
                    {visibleUngrouped.length === 0 ? (
                      <div className="px-3 py-2 text-[10px] text-gray-600">
                        未読のアカウントはありません
                      </div>
                    ) : (
                      visibleUngrouped.map((account) => (
                        <AccountItem
                          key={account.id}
                          account={account}
                          isSelected={selectedId === account.id}
                          onSelect={onSelect}
                          onDelete={onDelete}
                          groups={groups}
                          onAssignGroup={onAssignGroup}
                          moveMenuAccountId={moveMenuAccountId}
                          setMoveMenuAccountId={setMoveMenuAccountId}
                          menuRef={menuRef}
                        />
                      ))
                    )}
                  </div>
                  );
                })()}
              </div>
            )}

            {accounts.length === 0 && groups.length === 0 && !loading && (
              <div className="px-3 py-8 text-center">
                <FolderPlus className="w-8 h-8 text-gray-700 mx-auto mb-2" />
                <p className="text-xs text-gray-500">グループを作成してアカウントを整理</p>
                <button
                  onClick={onImport}
                  className="mt-2 text-xs text-emerald-400 hover:text-emerald-300 transition-colors"
                >
                  アカウントをインポート
                </button>
              </div>
            )}
          </>
        )}
      </div>

      <div className="p-3 border-t border-gray-800">
        <div className="text-xs text-gray-500 text-center">
          {groups.length} グループ / {accounts.length} アカウント
        </div>
      </div>
    </div>
  );
}

function AccountItem({
  account,
  isSelected,
  onSelect,
  onDelete,
  groups,
  onAssignGroup,
  moveMenuAccountId,
  setMoveMenuAccountId,
  menuRef,
}: {
  account: Account;
  isSelected: boolean;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  groups: AccountGroup[];
  onAssignGroup: (accountId: string, groupId: string | null) => void;
  moveMenuAccountId: string | null;
  setMoveMenuAccountId: (id: string | null) => void;
  menuRef: React.RefObject<HTMLDivElement>;
}) {
  return (
    <div
      className={`group relative ${
        isSelected
          ? 'bg-gray-800 border-l-2 border-emerald-400'
          : 'border-l-2 border-transparent hover:bg-gray-800/50'
      }`}
    >
      <button
        onClick={() => onSelect(account.id)}
        className="w-full px-2.5 py-2 flex items-center gap-2 text-left transition-all"
      >
        <div
          className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
            account.is_enabled
              ? 'bg-emerald-500/20 text-emerald-400'
              : 'bg-gray-700 text-gray-500'
          }`}
        >
          <MessageCircle className="w-3.5 h-3.5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-medium truncate">
            {account.display_name || `Account ${account.channel_id.slice(-6)}`}
          </div>
          <div className="text-[10px] text-gray-500 truncate">
            {account.channel_id.slice(-8)}
          </div>
        </div>
        {(account.total_unread ?? 0) > 0 && (
          <span className="bg-emerald-500 text-white text-[10px] font-bold min-w-[18px] h-4 flex items-center justify-center rounded-full px-1 shrink-0">
            {account.total_unread}
          </span>
        )}
      </button>
      <div className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-all">
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setMoveMenuAccountId(moveMenuAccountId === account.id ? null : account.id);
            }}
            className="p-1 rounded hover:bg-gray-700 transition-colors"
            title="グループ移動"
          >
            <ArrowRightLeft className="w-3 h-3 text-gray-400" />
          </button>
          {moveMenuAccountId === account.id && (
            <div ref={menuRef} className="absolute right-0 top-full mt-1 bg-gray-800 border border-gray-700 rounded-lg shadow-xl z-50 py-1 min-w-[150px]">
              {groups.filter((g) => g.id !== account.group_id).map((g) => (
                <button
                  key={g.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onAssignGroup(account.id, g.id);
                    setMoveMenuAccountId(null);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-gray-300 hover:bg-gray-700 transition-colors"
                >
                  <Folder className="w-3 h-3 text-emerald-400" />
                  {g.name}
                </button>
              ))}
              {account.group_id && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAssignGroup(account.id, null);
                    setMoveMenuAccountId(null);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-gray-400 hover:bg-gray-700 transition-colors border-t border-gray-700"
                >
                  <X className="w-3 h-3" />
                  未分類に移動
                </button>
              )}
            </div>
          )}
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            if (confirm(`「${account.display_name || account.channel_id}」を削除しますか？`)) {
              onDelete(account.id);
            }
          }}
          className="p-1 rounded hover:bg-red-500/20 transition-colors"
          title="削除"
        >
          <Trash2 className="w-3 h-3 text-red-400" />
        </button>
      </div>
    </div>
  );
}

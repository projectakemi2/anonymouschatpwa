import { useState, useEffect, useRef } from 'react';
import { X, Radio, AlertTriangle, ImagePlus, Loader, Folder } from 'lucide-react';
import * as api from '../lib/api';
import type { Broadcast, AccountGroup } from '../types';

interface BroadcastModalProps {
  onClose: () => void;
  groups: AccountGroup[];
  selectedGroupId?: string | null;
}

export default function BroadcastModal({ onClose, groups, selectedGroupId }: BroadcastModalProps) {
  const [text, setText] = useState('');
  const [groupId, setGroupId] = useState<string>(selectedGroupId || '');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [step, setStep] = useState<'compose' | 'processing' | 'done'>(
    'compose'
  );
  const [broadcast, setBroadcast] = useState<Broadcast | null>(null);
  const [error, setError] = useState('');
  const processingRef = useRef(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const handleSend = async () => {
    if (!text.trim() && !imageFile) return;
    setError('');
    setStep('processing');
    try {
      let imageUrl: string | undefined;
      if (imageFile) {
        setUploading(true);
        imageUrl = await api.uploadImage(imageFile);
        setUploading(false);
      }
      const { broadcast: b } = await api.createBroadcast(text.trim(), imageUrl, groupId || undefined);
      setBroadcast(b);
      processingRef.current = true;
      processLoop(b.id);
    } catch (err) {
      setUploading(false);
      setError(err instanceof Error ? err.message : '配信の作成に失敗しました');
      setStep('compose');
    }
  };

  const processLoop = async (broadcastId: string) => {
    while (processingRef.current) {
      try {
        const result = await api.processBroadcast(broadcastId);
        setBroadcast(result.broadcast);
        if (result.remaining === 0) {
          processingRef.current = false;
          setStep('done');
          break;
        }
      } catch {
        processingRef.current = false;
        setStep('done');
        break;
      }
    }
  };

  useEffect(() => {
    return () => {
      processingRef.current = false;
    };
  }, []);

  const progress = broadcast
    ? broadcast.total_targets > 0
      ? Math.round(
          ((broadcast.sent_count + broadcast.failed_count) /
            broadcast.total_targets) *
            100
        )
      : 100
    : 0;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-500" />
            <h2 className="text-lg font-semibold text-gray-900">
              一斉配信
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-5">
          {step === 'compose' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  メッセージ
                </label>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="配信メッセージを入力..."
                  rows={4}
                  className="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  画像 (任意)
                </label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageSelect}
                  className="hidden"
                />
                {imagePreview ? (
                  <div className="relative inline-block">
                    <img
                      src={imagePreview}
                      alt=""
                      className="h-28 rounded-lg object-cover border border-gray-200"
                    />
                    <button
                      onClick={clearImage}
                      className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-gray-800 text-white rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-gray-300 rounded-lg text-sm text-gray-500 hover:border-emerald-400 hover:text-emerald-600 transition-colors"
                  >
                    <ImagePlus className="w-4 h-4" />
                    画像を選択
                  </button>
                )}
              </div>
              {groups.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    配信先グループ
                  </label>
                  <div className="relative">
                    <Folder className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <select
                      value={groupId}
                      onChange={(e) => setGroupId(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all appearance-none bg-white"
                    >
                      <option value="">全アカウント</option>
                      {groups.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700">
                  {groupId
                    ? `「${groups.find((g) => g.id === groupId)?.name}」グループ内のアクティブなフォロワーに送信されます。`
                    : '有効な全アカウントのアクティブなフォロワーに送信されます。'}
                  ブロック済み・フォロー解除済みのユーザーは除外されます。
                </p>
              </div>
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-700">
                  {error}
                </div>
              )}
            </div>
          )}

          {(step === 'processing' || step === 'done') && broadcast && (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-3">
                {broadcast.image_url && (
                  <img
                    src={broadcast.image_url}
                    alt=""
                    className="h-20 rounded mb-2 object-cover"
                  />
                )}
                {broadcast.text && (
                  <p className="text-sm text-gray-700 whitespace-pre-wrap line-clamp-3">
                    {broadcast.text}
                  </p>
                )}
                {uploading && (
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Loader className="w-3 h-3 animate-spin" />
                    画像アップロード中...
                  </div>
                )}
              </div>

              <div>
                <div className="flex justify-between text-xs text-gray-600 mb-1.5">
                  <span>
                    {step === 'processing' ? '送信中...' : '完了'}
                  </span>
                  <span>{progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      step === 'done' && broadcast.failed_count > 0
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-xl font-bold text-gray-900">
                    {broadcast.total_targets}
                  </div>
                  <div className="text-[10px] text-gray-500">合計</div>
                </div>
                <div className="text-center p-3 bg-emerald-50 rounded-lg">
                  <div className="text-xl font-bold text-emerald-600">
                    {broadcast.sent_count}
                  </div>
                  <div className="text-[10px] text-emerald-600">送信済</div>
                </div>
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="text-xl font-bold text-red-600">
                    {broadcast.failed_count}
                  </div>
                  <div className="text-[10px] text-red-600">失敗</div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-5 border-t border-gray-100 flex justify-end gap-2">
          {step === 'compose' && (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 text-sm text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                キャンセル
              </button>
              <button
                onClick={handleSend}
                disabled={!text.trim() && !imageFile}
                className="px-4 py-2 text-sm font-medium text-white bg-emerald-500 hover:bg-emerald-600 rounded-lg transition-colors disabled:opacity-40 flex items-center gap-1.5 shadow-sm"
              >
                <Radio className="w-4 h-4" />
                配信する
              </button>
            </>
          )}
          {step === 'done' && (
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-white bg-emerald-500 hover:bg-emerald-600 rounded-lg transition-colors shadow-sm"
            >
              閉じる
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

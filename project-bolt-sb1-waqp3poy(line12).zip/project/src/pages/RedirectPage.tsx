import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

async function supabaseRpc(fn: string, body: Record<string, string>) {
  fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: 'POST',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  }).catch(() => {});
}

export default function RedirectPage() {
  const { slug } = useParams<{ slug: string }>();
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!slug) {
      setError(true);
      return;
    }

    (async () => {
      try {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/get_active_redirect_targets`, {
          method: 'POST',
          headers: {
            apikey: SUPABASE_ANON_KEY,
            Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ p_link_slug: slug }),
        });

        if (!res.ok) {
          setError(true);
          return;
        }

        const targets: {
          link_id: string;
          target_id: string;
          friend_add_url: string;
          weight: number;
          follower_count: number;
          distribution_mode: string;
        }[] = await res.json();

        if (!targets || targets.length === 0) {
          setError(true);
          return;
        }

        const mode = targets[0].distribution_mode;

        let effectiveWeights: number[];
        if (mode === 'balanced') {
          const maxFollowers = Math.max(...targets.map((t) => t.follower_count), 1);
          effectiveWeights = targets.map((t) => {
            const inverseWeight = maxFollowers - t.follower_count + 1;
            return inverseWeight * t.weight;
          });
        } else {
          effectiveWeights = targets.map((t) => t.weight);
        }

        const totalWeight = effectiveWeights.reduce((sum, w) => sum + w, 0);
        let rand = Math.random() * totalWeight;
        let selected = targets[0];

        for (let i = 0; i < targets.length; i++) {
          rand -= effectiveWeights[i];
          if (rand <= 0) {
            selected = targets[i];
            break;
          }
        }

        supabaseRpc('increment_redirect_clicks', {
          p_link_id: selected.link_id,
          p_target_id: selected.target_id,
        });

        window.location.href = selected.friend_add_url;
      } catch {
        setError(true);
      }
    })();
  }, [slug]);

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 text-sm">このリンクは無効です</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="w-8 h-8 border-3 border-gray-200 border-t-emerald-500 rounded-full animate-spin mx-auto mb-3" />
        <p className="text-gray-400 text-sm">リダイレクト中...</p>
      </div>
    </div>
  );
}

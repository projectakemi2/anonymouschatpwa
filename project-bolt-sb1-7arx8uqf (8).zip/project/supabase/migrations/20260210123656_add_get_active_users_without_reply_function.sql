/*
  # Add RPC function to get active users without reply

  1. New Function
    - `get_active_users_without_reply()`
      - Returns list of users who logged in today but haven't sent any DMs
      - Excludes admin users
      - Returns user id and display_name

  2. Purpose
    - Used for broadcasting messages to users who haven't replied yet
    - Helps admins identify inactive users for engagement
*/

CREATE OR REPLACE FUNCTION get_active_users_without_reply()
RETURNS TABLE (
  id uuid,
  display_name text
) 
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    au.id,
    au.display_name
  FROM anonymous_users au
  LEFT JOIN (
    SELECT sender_id, COUNT(*) as count
    FROM direct_messages
    GROUP BY sender_id
  ) dm_count ON au.id = dm_count.sender_id
  WHERE au.last_seen_at >= CURRENT_DATE
    AND COALESCE(dm_count.count, 0) = 0
    AND au.is_admin = false
  ORDER BY au.last_seen_at DESC;
$$;

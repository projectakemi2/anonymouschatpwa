/*
  # Fix RLS Policies for Admin Operations

  ## Changes
  - Fix ip_blocks INSERT policy to properly check if the user performing the action is an admin
  - Fix audit_logs INSERT policy to properly check admin status
  - These policies were incorrectly checking for admin status

  ## Security
  - Ensures only actual admins can block IPs and create audit logs
  - Uses the blocked_by/admin_id from the new row being inserted
*/

-- Drop and recreate ip_blocks INSERT policy
DROP POLICY IF EXISTS "Admins can insert IP blocks" ON ip_blocks;

CREATE POLICY "Admins can insert IP blocks"
  ON ip_blocks FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = blocked_by
      AND anonymous_users.is_admin = true
    )
  );

-- Drop and recreate audit_logs INSERT policy
DROP POLICY IF EXISTS "Admins can insert audit logs" ON audit_logs;

CREATE POLICY "Admins can insert audit logs"
  ON audit_logs FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = admin_id
      AND anonymous_users.is_admin = true
    )
  );
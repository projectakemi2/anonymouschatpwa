/*
  # Add filter for users who never received messages

  1. Changes
    - Update `get_active_users_without_reply()` function to support filtering by:
      - Users who never sent messages (existing behavior)
      - Users who never received messages (new option)
    - Add `filter_never_received` boolean parameter
    
  2. Purpose
    - Enable admins to target users who have never received any direct messages
    - Provide more granular control over user targeting for broadcasts
*/

CREATE OR REPLACE FUNCTION get_active_users_without_reply(
  start_date timestamp with time zone DEFAULT CURRENT_DATE,
  end_date timestamp with time zone DEFAULT (CURRENT_DATE + interval '1 day'),
  filter_never_received boolean DEFAULT false
)
RETURNS TABLE (
  id uuid,
  display_name text
) 
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    au.id,
    au.display_name
  FROM anonymous_users au
  LEFT JOIN (
    SELECT sender_id, COUNT(*) as sent_count
    FROM direct_messages
    GROUP BY sender_id
  ) dm_sent ON au.id = dm_sent.sender_id
  LEFT JOIN (
    SELECT recipient_id, COUNT(*) as received_count
    FROM direct_messages
    GROUP BY recipient_id
  ) dm_received ON au.id = dm_received.recipient_id
  WHERE au.last_seen_at >= start_date
    AND au.last_seen_at < end_date
    AND au.is_admin = false
    AND (
      (filter_never_received = false AND COALESCE(dm_sent.sent_count, 0) = 0)
      OR
      (filter_never_received = true AND COALESCE(dm_received.received_count, 0) = 0)
    )
  ORDER BY au.last_seen_at DESC;
$$;

/*
  # Fix Messages SELECT Policy for Realtime Updates

  ## Changes
  - Update messages SELECT policy to allow viewing messages even after soft delete
  - This enables realtime subscriptions to receive UPDATE events when messages are deleted
  - The application layer will filter out deleted messages

  ## Security
  - Still maintains data integrity
  - Soft-deleted messages are filtered in application code
*/

-- Drop and recreate messages SELECT policy to include deleted messages for realtime
DROP POLICY IF EXISTS "Anyone can view non-deleted messages" ON messages;

CREATE POLICY "Anyone can view messages"
  ON messages FOR SELECT
  USING (true);
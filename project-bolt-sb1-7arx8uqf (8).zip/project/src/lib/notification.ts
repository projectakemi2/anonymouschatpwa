let notificationPermission: NotificationPermission = 'default';

export interface NotificationDiagnostics {
  browser: string;
  os: string;
  device: string;
  isPWA: boolean;
  isStandalone: boolean;
  notificationSupport: boolean;
  initialPermission: NotificationPermission;
  serviceWorkerSupport: boolean;
  pushManagerSupport: boolean;
  isSecure: boolean;
  userAgent: string;
}

export function getNotificationDiagnostics(): NotificationDiagnostics {
  const ua = navigator.userAgent;

  // ブラウザ検出
  let browser = 'Unknown';
  if (ua.includes('Chrome') && !ua.includes('Edg')) browser = 'Chrome';
  else if (ua.includes('Safari') && !ua.includes('Chrome')) browser = 'Safari';
  else if (ua.includes('Firefox')) browser = 'Firefox';
  else if (ua.includes('Edg')) browser = 'Edge';

  // OS検出
  let os = 'Unknown';
  if (ua.includes('Android')) os = 'Android';
  else if (ua.includes('iPhone') || ua.includes('iPad')) os = 'iOS';
  else if (ua.includes('Windows')) os = 'Windows';
  else if (ua.includes('Mac')) os = 'macOS';
  else if (ua.includes('Linux')) os = 'Linux';

  // デバイスタイプ
  const device = /Mobile|Android|iPhone|iPad/.test(ua) ? 'Mobile' : 'Desktop';

  // PWA検出
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                       ('standalone' in navigator && (navigator as any).standalone === true);
  const isPWA = isStandalone || document.referrer.includes('android-app://');

  return {
    browser,
    os,
    device,
    isPWA,
    isStandalone,
    notificationSupport: 'Notification' in window,
    initialPermission: 'Notification' in window ? Notification.permission : 'denied',
    serviceWorkerSupport: 'serviceWorker' in navigator,
    pushManagerSupport: 'PushManager' in window,
    isSecure: window.location.protocol === 'https:' || window.location.hostname === 'localhost',
    userAgent: ua
  };
}

export function logNotificationDiagnostics(): void {
  const diag = getNotificationDiagnostics();

  console.group('🔍 通知診断情報');
  console.log('ブラウザ:', diag.browser);
  console.log('OS:', diag.os);
  console.log('デバイス:', diag.device);
  console.log('PWAインストール:', diag.isPWA ? 'はい' : 'いいえ');
  console.log('スタンドアローンモード:', diag.isStandalone ? 'はい' : 'いいえ');
  console.log('通知API対応:', diag.notificationSupport ? 'はい' : 'いいえ');
  console.log('初期通知許可状態:', diag.initialPermission);
  console.log('Service Worker対応:', diag.serviceWorkerSupport ? 'はい' : 'いいえ');
  console.log('Push Manager対応:', diag.pushManagerSupport ? 'はい' : 'いいえ');
  console.log('HTTPS:', diag.isSecure ? 'はい' : 'いいえ');

  // 特殊なケースを警告
  if (diag.isPWA && diag.os === 'Android' && diag.initialPermission === 'granted') {
    console.warn('⚠️ Android PWAで通知が自動許可されています（Chromeの仕様）');
  }

  if (diag.os === 'iOS' && diag.initialPermission === 'denied') {
    console.warn('⚠️ iOSではデフォルトで通知が拒否される場合があります');
  }

  if (diag.initialPermission === 'denied' && !diag.isPWA) {
    console.warn('⚠️ ブラウザ設定で通知がブロックされている可能性があります');
  }

  if (diag.initialPermission === 'granted' && !diag.isPWA) {
    console.warn('⚠️ 過去にこのサイトで通知を許可したか、ブラウザ設定で自動許可されています');
  }

  console.groupEnd();
}

export function getNotificationDiagnosticsReport(): string {
  const diag = getNotificationDiagnostics();

  const lines = [
    '【通知診断レポート】',
    '',
    `ブラウザ: ${diag.browser}`,
    `OS: ${diag.os}`,
    `デバイス: ${diag.device}`,
    `PWAインストール: ${diag.isPWA ? 'はい' : 'いいえ'}`,
    `スタンドアローンモード: ${diag.isStandalone ? 'はい' : 'いいえ'}`,
    '',
    `通知API対応: ${diag.notificationSupport ? 'はい' : 'いいえ'}`,
    `初期通知許可状態: ${diag.initialPermission}`,
    `Service Worker対応: ${diag.serviceWorkerSupport ? 'はい' : 'いいえ'}`,
    `Push Manager対応: ${diag.pushManagerSupport ? 'はい' : 'いいえ'}`,
    `HTTPS: ${diag.isSecure ? 'はい' : 'いいえ'}`,
    ''
  ];

  // 特殊なケースの説明
  if (diag.isPWA && diag.os === 'Android' && diag.initialPermission === 'granted') {
    lines.push('【原因】');
    lines.push('Android PWAでは、アプリをインストールすると自動的に通知が許可されます。');
    lines.push('これはChromeの仕様で、ユーザーに許可を求めるダイアログは表示されません。');
  } else if (diag.os === 'iOS' && diag.initialPermission === 'denied') {
    lines.push('【原因】');
    lines.push('iOSでは、Safari設定で通知が無効化されている可能性があります。');
    lines.push('iPhoneの設定 > Safari > 通知 を確認してください。');
  } else if (diag.initialPermission === 'denied' && !diag.isPWA) {
    lines.push('【原因】');
    lines.push('過去にこのサイトで通知を「ブロック」したか、');
    lines.push('ブラウザ設定で通知が無効化されています。');
  } else if (diag.initialPermission === 'granted' && !diag.isPWA) {
    lines.push('【原因】');
    lines.push('過去にこのサイトで通知を「許可」したため、');
    lines.push('既に通知が有効になっています。');
  } else if (diag.initialPermission === 'default') {
    lines.push('【状態】');
    lines.push('まだ通知許可を求めていません。');
    lines.push('許可ダイアログが表示されます。');
  }

  return lines.join('\n');
}

export async function requestNotificationPermission(): Promise<boolean> {
  // 診断情報をログ出力
  logNotificationDiagnostics();
  if (!('Notification' in window)) {
    console.warn('This browser does not support notifications');
    return false;
  }

  if (Notification.permission === 'granted') {
    notificationPermission = 'granted';
    console.log('✅ 通知許可: 既に許可されています');
    return true;
  }

  if (Notification.permission === 'denied') {
    console.warn('⚠️ 通知許可: ブロックされています。設定から許可してください。');
    return false;
  }

  try {
    const permission = await Notification.requestPermission();
    notificationPermission = permission;

    if (permission === 'granted') {
      console.log('✅ 通知許可: 許可されました');
      await showTestNotification();
      return true;
    } else {
      console.warn('⚠️ 通知許可: 拒否されました');
      return false;
    }
  } catch (error) {
    console.error('❌ 通知許可リクエストエラー:', error);
    return false;
  }
}

async function showTestNotification(): Promise<void> {
  try {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification('通知テスト', {
        body: '新しいメッセージが届いたときに通知されます',
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        vibrate: [200, 100, 200],
        tag: 'test-notification',
        requireInteraction: false,
        silent: false
      });
    } else {
      new Notification('通知テスト', {
        body: '新しいメッセージが届いたときに通知されます',
        icon: '/icon-192.png',
        tag: 'test-notification'
      });
    }
  } catch (error) {
    console.warn('テスト通知の表示に失敗:', error);
  }
}

export function getNotificationPermission(): NotificationPermission {
  if ('Notification' in window) {
    return Notification.permission;
  }
  return 'denied';
}

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered:', registration);

      // Service Workerが準備できるまで待つ
      await navigator.serviceWorker.ready;

      return registration;
    } catch (error) {
      console.warn('Service Worker not supported or registration failed:', error);
      return null;
    }
  }
  console.warn('Service Worker not supported in this environment');
  return null;
}

export async function sendUserInfoToServiceWorker(userId: string, roomId: string): Promise<void> {
  if (!('serviceWorker' in navigator)) {
    console.warn('❌ Service Worker not supported');
    return;
  }

  try {
    // Service Workerが準備できるまで待つ
    await navigator.serviceWorker.ready;

    // アクティブなService Workerを取得
    const registration = await navigator.serviceWorker.ready;
    if (!registration.active) {
      console.warn('❌ No active Service Worker found');
      return;
    }

    // controllerがない場合は、少し待ってから再試行
    if (!navigator.serviceWorker.controller) {
      console.log('⏳ Waiting for Service Worker controller...');
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    if (navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SET_USER_INFO',
        userId,
        roomId
      });
      console.log('✅ User info sent to Service Worker:', { userId, roomId });
    } else {
      console.warn('❌ Service Worker controller not available');
    }
  } catch (error) {
    console.error('❌ Failed to send user info to Service Worker:', error);
  }
}

export async function removeNotificationByMessageId(messageId: string): Promise<void> {
  if (!('serviceWorker' in navigator)) {
    console.warn('❌ Service Worker not supported');
    return;
  }

  try {
    await navigator.serviceWorker.ready;

    if (!navigator.serviceWorker.controller) {
      console.warn('❌ Service Worker controller not available');
      return;
    }

    navigator.serviceWorker.controller.postMessage({
      type: 'REMOVE_NOTIFICATION',
      messageId
    });
    console.log('✅ Requested notification removal for message:', messageId);
  } catch (error) {
    console.error('❌ Failed to remove notification:', error);
  }
}

export async function removeNotificationsByMessageIds(messageIds: string[]): Promise<void> {
  if (!('serviceWorker' in navigator)) {
    console.warn('❌ Service Worker not supported');
    return;
  }

  try {
    await navigator.serviceWorker.ready;

    if (!navigator.serviceWorker.controller) {
      console.warn('❌ Service Worker controller not available');
      return;
    }

    navigator.serviceWorker.controller.postMessage({
      type: 'REMOVE_NOTIFICATIONS',
      messageIds
    });
    console.log('✅ Requested notification removal for messages:', messageIds.length);
  } catch (error) {
    console.error('❌ Failed to remove notifications:', error);
  }
}

export async function showNotification(title: string, body: string): Promise<void> {
  if (!('Notification' in window)) {
    console.warn('Notifications not supported');
    return;
  }

  const permission = Notification.permission;

  if (permission === 'denied') {
    console.warn('⚠️ 通知許可がブロックされています');
    return;
  }

  if (permission !== 'granted') {
    console.warn('⚠️ 通知許可がありません。許可をリクエストしてください。');
    const newPermission = await requestNotificationPermission();
    if (!newPermission) {
      return;
    }
  }

  try {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.ready;

        await registration.showNotification(title, {
          body,
          icon: '/icon-192.png',
          badge: '/icon-192.png',
          vibrate: [300, 100, 300, 100, 300],
          tag: `message-${Date.now()}`,
          requireInteraction: false,
          silent: false,
          renotify: true,
          timestamp: Date.now(),
          data: {
            url: window.location.href,
            timestamp: Date.now()
          }
        });

        console.log('🔔 通知表示成功 (Service Worker):', title);
        return;
      } catch (swError) {
        console.warn('Service Worker notification failed, using Notification API:', swError);
      }
    }

    const notification = new Notification(title, {
      body,
      icon: '/icon-192.png',
      tag: `message-${Date.now()}`,
      vibrate: [300, 100, 300, 100, 300],
      requireInteraction: false,
      silent: false,
      timestamp: Date.now()
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };

    console.log('🔔 通知表示成功 (Notification API):', title);
  } catch (error) {
    console.error('❌ 通知表示エラー:', error);
  }
}

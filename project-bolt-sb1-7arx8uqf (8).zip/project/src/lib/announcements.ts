import { supabase } from './supabase';

export interface Announcement {
  id: string;
  title: string;
  body: string;
  url: string | null;
  is_active: boolean;
  priority: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface CreateAnnouncementData {
  title: string;
  body: string;
  url?: string;
  is_active?: boolean;
  priority?: number;
}

export interface UpdateAnnouncementData {
  title?: string;
  body?: string;
  url?: string | null;
  is_active?: boolean;
  priority?: number;
}

export async function getActiveAnnouncements(): Promise<Announcement[]> {
  const { data, error } = await supabase
    .from('announcements')
    .select('*')
    .eq('is_active', true)
    .order('priority', { ascending: true })
    .limit(3);

  if (error) {
    console.error('Failed to fetch announcements:', error);
    return [];
  }

  return data || [];
}

export async function getAllAnnouncements(): Promise<Announcement[]> {
  const { data, error } = await supabase
    .from('announcements')
    .select('*')
    .order('priority', { ascending: true })
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Failed to fetch all announcements:', error);
    throw error;
  }

  return data || [];
}

export async function createAnnouncement(
  userId: string,
  announcementData: CreateAnnouncementData
): Promise<Announcement> {
  if (announcementData.is_active) {
    const activeCount = await getActiveAnnouncementsCount();
    if (activeCount >= 3) {
      throw new Error('アクティブなアナウンスは最大3件までです');
    }
  }

  const { data, error } = await supabase
    .from('announcements')
    .insert({
      title: announcementData.title,
      body: announcementData.body,
      url: announcementData.url || null,
      is_active: announcementData.is_active ?? false,
      priority: announcementData.priority ?? 1,
      created_by: userId
    })
    .select()
    .single();

  if (error) {
    console.error('Failed to create announcement:', error);
    throw error;
  }

  return data;
}

export async function updateAnnouncement(
  id: string,
  updates: UpdateAnnouncementData
): Promise<Announcement> {
  if (updates.is_active === true) {
    const { data: current } = await supabase
      .from('announcements')
      .select('is_active')
      .eq('id', id)
      .single();

    if (current && !current.is_active) {
      const activeCount = await getActiveAnnouncementsCount();
      if (activeCount >= 3) {
        throw new Error('アクティブなアナウンスは最大3件までです');
      }
    }
  }

  const { data, error } = await supabase
    .from('announcements')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Failed to update announcement:', error);
    throw error;
  }

  return data;
}

export async function deleteAnnouncement(id: string): Promise<void> {
  const { error } = await supabase
    .from('announcements')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Failed to delete announcement:', error);
    throw error;
  }
}

export async function toggleAnnouncementActive(id: string, isActive: boolean): Promise<void> {
  if (isActive) {
    const activeCount = await getActiveAnnouncementsCount();
    if (activeCount >= 3) {
      throw new Error('アクティブなアナウンスは最大3件までです');
    }
  }

  await updateAnnouncement(id, { is_active: isActive });
}

export async function updateAnnouncementPriority(id: string, newPriority: number): Promise<void> {
  if (newPriority < 1 || newPriority > 3) {
    throw new Error('優先度は1-3の範囲で指定してください');
  }

  await updateAnnouncement(id, { priority: newPriority });
}

async function getActiveAnnouncementsCount(): Promise<number> {
  const { count, error } = await supabase
    .from('announcements')
    .select('*', { count: 'exact', head: true })
    .eq('is_active', true);

  if (error) {
    console.error('Failed to count active announcements:', error);
    return 0;
  }

  return count || 0;
}

export function subscribeToAnnouncements(
  callback: (announcements: Announcement[]) => void
): () => void {
  const channel = supabase
    .channel('announcements-changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'announcements'
      },
      async () => {
        const announcements = await getActiveAnnouncements();
        callback(announcements);
      }
    )
    .subscribe();

  getActiveAnnouncements().then(callback);

  return () => {
    supabase.removeChannel(channel);
  };
}

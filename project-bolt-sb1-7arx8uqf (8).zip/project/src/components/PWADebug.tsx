import { useState, useEffect } from 'react';
import { X } from 'lucide-react';

export default function PWADebug() {
  const [isOpen, setIsOpen] = useState(false);
  const [status, setStatus] = useState({
    isHTTPS: false,
    hasServiceWorker: false,
    serviceWorkerActive: false,
    hasManifest: false,
    manifestLoaded: false,
    beforeInstallPromptFired: false,
    isInstalled: false,
    isStandalone: false,
    userAgent: '',
    manifestData: null as any,
  });

  useEffect(() => {
    const checkPWAStatus = async () => {
      const isHTTPS = window.location.protocol === 'https:' || window.location.hostname === 'localhost';
      const hasServiceWorker = 'serviceWorker' in navigator;
      let serviceWorkerActive = false;

      if (hasServiceWorker) {
        const registration = await navigator.serviceWorker.getRegistration();
        serviceWorkerActive = registration?.active !== undefined;
      }

      const manifestLink = document.querySelector('link[rel="manifest"]');
      const hasManifest = manifestLink !== null;
      let manifestLoaded = false;
      let manifestData = null;

      if (hasManifest) {
        try {
          const manifestUrl = (manifestLink as HTMLLinkElement).href;
          const response = await fetch(manifestUrl);
          manifestData = await response.json();
          manifestLoaded = true;
        } catch (error) {
          console.error('Failed to load manifest:', error);
        }
      }

      const beforeInstallPromptFired = !!(window as any).deferredPrompt;
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                          (window.navigator as any).standalone === true;
      const isInstalled = localStorage.getItem('pwa_installed') === 'true';

      setStatus({
        isHTTPS,
        hasServiceWorker,
        serviceWorkerActive,
        hasManifest,
        manifestLoaded,
        beforeInstallPromptFired,
        isInstalled,
        isStandalone,
        userAgent: navigator.userAgent,
        manifestData,
      });
    };

    checkPWAStatus();

    const interval = setInterval(checkPWAStatus, 1000);

    return () => clearInterval(interval);
  }, []);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 left-4 bg-gray-900 text-white px-4 py-2 rounded-lg shadow-lg text-sm font-mono z-50"
      >
        PWA Debug
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-auto">
        <div className="sticky top-0 bg-white border-b px-4 py-3 flex items-center justify-between">
          <h2 className="text-lg font-bold">PWA Debug Panel</h2>
          <button onClick={() => setIsOpen(false)} className="p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4 font-mono text-sm">
          <div>
            <h3 className="font-bold mb-2 text-base">PWA Status</h3>
            <div className="space-y-1">
              <StatusRow label="HTTPS" value={status.isHTTPS} />
              <StatusRow label="Service Worker Support" value={status.hasServiceWorker} />
              <StatusRow label="Service Worker Active" value={status.serviceWorkerActive} />
              <StatusRow label="Manifest Link" value={status.hasManifest} />
              <StatusRow label="Manifest Loaded" value={status.manifestLoaded} />
              <StatusRow label="beforeinstallprompt Fired" value={status.beforeInstallPromptFired} />
              <StatusRow label="Installed" value={status.isInstalled} />
              <StatusRow label="Standalone Mode" value={status.isStandalone} />
            </div>
          </div>

          <div>
            <h3 className="font-bold mb-2 text-base">User Agent</h3>
            <div className="bg-gray-100 p-2 rounded text-xs break-all">
              {status.userAgent}
            </div>
          </div>

          {status.manifestData && (
            <div>
              <h3 className="font-bold mb-2 text-base">Manifest Data</h3>
              <div className="bg-gray-100 p-2 rounded text-xs overflow-auto max-h-60">
                <pre>{JSON.stringify(status.manifestData, null, 2)}</pre>
              </div>
            </div>
          )}

          <div>
            <h3 className="font-bold mb-2 text-base">Diagnosis</h3>
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3 text-xs">
              {!status.beforeInstallPromptFired && !status.isInstalled && (
                <div className="mb-2">
                  <strong className="text-red-600">❌ beforeinstallprompt not fired</strong>
                  <p className="mt-1">Possible reasons:</p>
                  <ul className="list-disc ml-4 mt-1">
                    <li>App is already installed</li>
                    <li>User dismissed install prompt before</li>
                    <li>PWA criteria not met</li>
                    <li>Browser does not support PWA installation</li>
                  </ul>
                </div>
              )}
              {status.beforeInstallPromptFired && (
                <div className="text-green-600">
                  <strong>✅ PWA is installable!</strong>
                </div>
              )}
              {status.isStandalone && (
                <div className="text-green-600">
                  <strong>✅ App is running in standalone mode</strong>
                </div>
              )}
              {!status.isHTTPS && (
                <div className="text-red-600">
                  <strong>❌ Not served over HTTPS</strong>
                </div>
              )}
              {!status.serviceWorkerActive && (
                <div className="text-red-600">
                  <strong>❌ Service Worker not active</strong>
                </div>
              )}
              {!status.manifestLoaded && (
                <div className="text-red-600">
                  <strong>❌ Manifest failed to load</strong>
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-bold mb-2 text-base">Actions</h3>
            <div className="space-y-2">
              <button
                onClick={() => {
                  localStorage.removeItem('pwa_installed');
                  window.location.reload();
                }}
                className="w-full bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
              >
                Clear Install State & Reload
              </button>
              <button
                onClick={async () => {
                  if ('serviceWorker' in navigator) {
                    const registrations = await navigator.serviceWorker.getRegistrations();
                    for (const registration of registrations) {
                      await registration.unregister();
                    }
                  }
                  window.location.reload();
                }}
                className="w-full bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700"
              >
                Unregister Service Worker & Reload
              </button>
              <button
                onClick={async () => {
                  if ('caches' in window) {
                    const cacheNames = await caches.keys();
                    await Promise.all(cacheNames.map(name => caches.delete(name)));
                  }
                  alert('Cache cleared!');
                }}
                className="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                Clear Cache
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusRow({ label, value }: { label: string; value: boolean }) {
  return (
    <div className="flex items-center justify-between py-1 border-b">
      <span className="text-gray-700">{label}</span>
      <span className={`font-bold ${value ? 'text-green-600' : 'text-red-600'}`}>
        {value ? '✅ Yes' : '❌ No'}
      </span>
    </div>
  );
}

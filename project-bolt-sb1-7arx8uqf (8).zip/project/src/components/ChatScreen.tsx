import { useState, useEffect, useRef, useMemo, memo } from 'react';
import { Send, Image as ImageIcon, X, Shield, AlertCircle, LogOut, Trash2, MessageSquare, Share2, Copy, Check, QrCode, Bell, BellOff, Eye, EyeOff, Mail } from 'lucide-react';
import { getCurrentUser, updateLastSeen, AnonymousUser, deleteAccount, validateCurrentUser } from '../lib/user';
import { getMessages, sendMessage, subscribeToMessages, Message, deleteMessage, getMessagesBeforeId } from '../lib/messages';
import { resizeImage, validateImageFile } from '../lib/image';
import { showNotification, requestNotificationPermission, getNotificationPermission, sendUserInfoToServiceWorker, removeNotificationByMessageId } from '../lib/notification';
import { subscribeToPushNotifications, checkPushSubscription } from '../lib/push';
import { getCurrentRoomId, getRoomName, getRoomURL, URLFormat, getFormatLabel, getFormatDescription } from '../lib/room';
import { downloadProjectHandoverPackage } from '../lib/project-export';
import { toggleUserVisibility } from '../lib/admin';
import AdminPanel from './AdminPanel';
import RoomList from './RoomList';
import InstallBanner from './InstallBanner';
import { PushNotificationBanner } from './PushNotificationBanner';
import AnnouncementBanner from './AnnouncementBanner';
import { DirectMessagesModal } from './DirectMessagesModal';
import { getUnreadCount, subscribeToDirectMessages } from '../lib/direct-messages';
import QRCode from 'qrcode';

function linkifyText(text: string) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts = text.split(urlRegex);

  return parts.map((part, index) => {
    if (part.match(urlRegex)) {
      return (
        <a
          key={index}
          href={part}
          target="_blank"
          rel="noopener noreferrer"
          className="underline hover:opacity-80"
        >
          {part}
        </a>
      );
    }
    return part;
  });
}

export default function ChatScreen() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [content, setContent] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentUser, setCurrentUser] = useState<AnonymousUser | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showRoomList, setShowRoomList] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState<URLFormat>('hash');
  const [roomId] = useState(getCurrentRoomId());
  const [roomName, setRoomName] = useState('チャットルーム');
  const [exportLoading, setExportLoading] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const [hasSubscription, setHasSubscription] = useState(false);
  const [showPushBanner, setShowPushBanner] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [showDirectMessages, setShowDirectMessages] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [expandedImage, setExpandedImage] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    const initUser = async () => {
      const user = await validateCurrentUser();
      if (!user) {
        window.location.reload();
        return;
      }
      setCurrentUser(user);

      const permission = getNotificationPermission();
      setNotificationPermission(permission);

      if (permission === 'granted') {
        (async () => {
          const hasSub = await checkPushSubscription();
          setHasSubscription(hasSub);
          if (!hasSub && user.id) {
            const subscribed = await subscribeToPushNotifications(user.id, roomId);
            setHasSubscription(subscribed);
          }
        })();
        setShowPushBanner(false);
      } else if (permission === 'default') {
        (async () => {
          try {
            const granted = await requestNotificationPermission();

            if (granted && user.id) {
              const subscribed = await subscribeToPushNotifications(user.id, roomId);
              if (subscribed) {
                setNotificationPermission('granted');
                setHasSubscription(true);
                setShowPushBanner(false);
              }
            } else {
              const dismissed = localStorage.getItem('push-banner-dismissed');
              setShowPushBanner(!dismissed);
            }
          } catch (err) {
            const dismissed = localStorage.getItem('push-banner-dismissed');
            setShowPushBanner(!dismissed);
          }
        })();
      }
    };
    initUser();

    const handleURLChange = () => {
      const newRoomId = getCurrentRoomId();
      if (newRoomId !== roomId) {
        window.location.reload();
      }
    };

    window.addEventListener('hashchange', handleURLChange);
    window.addEventListener('popstate', handleURLChange);

    return () => {
      window.removeEventListener('hashchange', handleURLChange);
      window.removeEventListener('popstate', handleURLChange);
    };
  }, [roomId]);

  useEffect(() => {
    const loadRoomName = async () => {
      try {
        const name = await getRoomName(roomId);
        setRoomName(name);
      } catch (err) {
        console.error('Failed to load room name:', err);
      }
    };
    loadRoomName();
  }, [roomId]);

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) return;

    sendUserInfoToServiceWorker(user.id, roomId).catch(() => {});

    loadMessages();
    const unsubscribe = subscribeToMessages(
      roomId,
      (newMessage) => {
        setMessages((prev) => [...prev, newMessage]);

        if (newMessage.user_id !== user.id && !document.hidden) {
          showNotification(
            `${newMessage.user?.display_name || '匿名ユーザー'}`,
            newMessage.content.substring(0, 100) || '画像を送信しました'
          ).catch(() => {});
        }
      },
      (deletedMessageId) => {
        setMessages((prev) => prev.filter(msg => msg.id !== deletedMessageId));
        removeNotificationByMessageId(deletedMessageId);
      }
    );

    const interval = setInterval(() => {
      updateLastSeen(user.id);
    }, 30000);

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        loadMessages();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      unsubscribe();
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [roomId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;

    const handleScroll = () => {
      if (container.scrollTop < 100 && !loadingMore && hasMore) {
        loadMoreMessages();
      }
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, [loadingMore, hasMore, messages]);

  useEffect(() => {
    if (!currentUser) return;

    const loadUnreadCount = async () => {
      const count = await getUnreadCount(currentUser.id);
      setUnreadCount(count);
    };

    loadUnreadCount();

    const channel = subscribeToDirectMessages(currentUser.id, () => {
      loadUnreadCount();
    });

    return () => {
      channel.unsubscribe();
    };
  }, [currentUser]);

  const loadMessages = async () => {
    try {
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      const initialLimit = isMobile ? 20 : 50;
      const data = await getMessages(roomId, initialLimit);
      setMessages(data);
      setHasMore(data.length === initialLimit);
    } catch (err) {
      console.error('Failed to load messages:', err);
    } finally {
      setInitialLoading(false);
    }
  };

  const loadMoreMessages = async () => {
    if (loadingMore || !hasMore || messages.length === 0) return;

    setLoadingMore(true);
    try {
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      const pageSize = isMobile ? 20 : 50;
      const oldestMessage = messages[0];
      const olderMessages = await getMessagesBeforeId(oldestMessage.id, roomId, pageSize);

      if (olderMessages.length > 0) {
        const container = messagesContainerRef.current;
        const prevScrollHeight = container?.scrollHeight || 0;

        setMessages((prev) => [...olderMessages, ...prev]);
        setHasMore(olderMessages.length === pageSize);

        setTimeout(() => {
          if (container) {
            const newScrollHeight = container.scrollHeight;
            container.scrollTop = newScrollHeight - prevScrollHeight;
          }
        }, 0);
      } else {
        setHasMore(false);
      }
    } catch (err) {
      console.error('Failed to load more messages:', err);
    } finally {
      setLoadingMore(false);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);

    if (images.length + files.length > 4) {
      setError('画像は最大4枚までです');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const resizedImages = await Promise.all(
        files.map(async (file) => {
          if (!validateImageFile(file)) {
            throw new Error('無効な画像ファイルです（5MB以下のJPG/PNG/GIF/WebP）');
          }
          return await resizeImage(file);
        })
      );

      setImages((prev) => [...prev, ...resizedImages]);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!content.trim() && images.length === 0) {
      return;
    }

    if (!currentUser) {
      setError('ユーザー情報が見つかりません');
      return;
    }

    setError('');
    setLoading(true);

    try {
      await sendMessage(currentUser.id, content, images, roomId);
      setContent('');
      setImages([]);
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    } catch (err: any) {
      const errorMessage = err.message || '送信に失敗しました';
      setError(errorMessage);

      if (errorMessage.includes('ユーザー情報が見つかりません')) {
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files).filter(file => file.type.startsWith('image/'));
    if (files.length === 0) return;

    if (images.length + files.length > 4) {
      setError('画像は最大4枚までです');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const resizedImages = await Promise.all(
        files.map(async (file) => {
          if (!validateImageFile(file)) {
            throw new Error('無効な画像ファイルです（5MB以下のJPG/PNG/GIF/WebP）');
          }
          return await resizeImage(file);
        })
      );

      setImages((prev) => [...prev, ...resizedImages]);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAdminClick = () => {
    const password = prompt('管理者パスワードを入力してください:');
    if (password === 'admin123') {
      setShowAdmin(true);
    } else if (password !== null) {
      alert('パスワードが間違っています');
    }
  };

  const handleEnablePushFromBanner = async () => {
    setShowPushBanner(false);
    await handleEnableNotifications();
  };

  const handleDismissPushBanner = () => {
    setShowPushBanner(false);
    localStorage.setItem('push-banner-dismissed', 'true');
  };

  const handleEnableNotifications = async () => {
    if (!currentUser) return;

    try {
      const granted = await requestNotificationPermission();

      if (granted && currentUser.id) {
        const subscribed = await subscribeToPushNotifications(currentUser.id, roomId);

        if (subscribed) {
          setNotificationPermission('granted');
          setHasSubscription(true);
          setShowPushBanner(false);
          alert('プッシュ通知を有効にしました！ブラウザを閉じても通知が届き続けます。');
        } else {
          alert('プッシュ通知の登録に失敗しました。');
        }
      } else {
        const newPermission = getNotificationPermission();
        setNotificationPermission(newPermission);
        if (newPermission === 'denied') {
          setShowPushBanner(false);
          const instructions = [
            `${window.location.hostname}`,
            '通知が拒否されています。ブラウザの設定から許可してください。',
            '',
            '【Androidの場合】',
            '1. ブラウザのアドレスバー左の鍵マークをタップ',
            '2. 「権限」または「サイトの設定」をタップ',
            '3. 「通知」を「許可」に変更',
            '4. ページを再読み込み',
            '',
            '【iPhoneの場合】',
            '1. iPhoneの「設定」アプリを開く',
            '2. 下にスクロールして「Safari」を選択',
            '3. 「Webサイト」→「通知」を選択',
            `4. ${window.location.hostname} を「許可」に変更`,
            '5. ページを再読み込み',
          ].join('\n');
          alert(instructions);
        }
      }
    } catch (err: any) {
      alert('通知の有効化に失敗しました: ' + err.message);
    }
  };

  const handleDeleteAccount = async () => {
    if (!currentUser) return;

    const confirmed = confirm(
      '本当に退会しますか？\n\nこの操作は取り消せません。\nあなたのアカウントとメッセージが削除されます。'
    );

    if (!confirmed) return;

    try {
      await deleteAccount(currentUser.id);
      alert('退会しました。ご利用ありがとうございました。');
      window.location.reload();
    } catch (err: any) {
      alert('退会に失敗しました: ' + err.message);
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!currentUser?.is_admin) return;

    const confirmed = confirm('このメッセージを削除しますか？');
    if (!confirmed) return;

    try {
      await deleteMessage(messageId, currentUser.id);
    } catch (err: any) {
      alert('削除に失敗しました: ' + err.message);
    }
  };

  const handleToggleVisibility = async (userId: string, currentVisibility: boolean) => {
    if (!currentUser?.is_admin) return;

    try {
      await toggleUserVisibility(userId, !currentVisibility);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.user_id === userId && msg.user
            ? { ...msg, user: { ...msg.user, is_visible: !currentVisibility } }
            : msg
        )
      );
    } catch (err: any) {
      alert('可視性の変更に失敗しました: ' + err.message);
    }
  };

  const handleShare = async () => {
    try {
      const qrUrl = await QRCode.toDataURL(roomId, {
        width: 300,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      setQrCodeUrl(qrUrl);
      setShowShareModal(true);
    } catch (err) {
      console.error('QR code generation failed:', err);
    }
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(roomId);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } catch (err) {
      alert('コピーに失敗しました');
    }
  };

  const handleCopyUrl = async () => {
    try {
      const url = getRoomURL(roomId, selectedFormat);
      await navigator.clipboard.writeText(url);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    } catch (err) {
      alert('URLのコピーに失敗しました');
    }
  };

  const handleExportHandover = async () => {
    setExportLoading(true);
    try {
      await downloadProjectHandoverPackage();
      alert('✅ プロジェクト引き継ぎパッケージをダウンロードしました！');
    } catch (err: any) {
      alert('❌ エクスポートに失敗しました: ' + err.message);
    } finally {
      setExportLoading(false);
    }
  };

  const filteredMessages = useMemo(() => {
    return messages.filter((msg) => {
      if (currentUser?.is_admin) return true;
      return msg.user?.is_visible !== false;
    });
  }, [messages, currentUser?.is_admin]);

  if (initialLoading) {
    return (
      <div className="flex flex-col h-screen bg-gray-50 items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mb-4"></div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">読み込み中...</h2>
          <p className="text-gray-600">チャットルームに接続しています</p>
        </div>
      </div>
    );
  }

  if (showAdmin && currentUser) {
    return <AdminPanel onClose={() => setShowAdmin(false)} currentUser={currentUser} roomId={roomId} />;
  }

  if (showRoomList && currentUser) {
    return <RoomList onClose={() => setShowRoomList(false)} currentUser={currentUser} />;
  }

  return (
    <div className="fixed inset-0 flex flex-col bg-gray-50 overflow-hidden w-full">
      {showShareModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowShareModal(false)}>
          <div className="bg-white rounded-3xl p-8 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">ルームを共有</h2>
              <p className="text-gray-600 mb-4">{roomName}</p>
            </div>

            <div className="space-y-6">
              <div className="bg-gray-50 rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-3">
                  <Copy className="w-5 h-5 text-gray-700" />
                  <h3 className="font-bold text-gray-900">ルームコード（推奨）</h3>
                </div>
                <div className="bg-white rounded-xl p-4 mb-3 border-2 border-gray-200">
                  <p className="text-2xl font-mono font-bold text-center text-gray-900">{roomId}</p>
                </div>
                <button
                  onClick={handleCopyCode}
                  className="w-full px-4 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors flex items-center justify-center gap-2 font-medium"
                >
                  {copiedCode ? (
                    <>
                      <Check className="w-5 h-5" />
                      コピーしました
                    </>
                  ) : (
                    <>
                      <Copy className="w-5 h-5" />
                      コードをコピー
                    </>
                  )}
                </button>
                <p className="text-sm text-gray-600 mt-3 text-center">
                  このコードを友達に共有してください
                </p>
              </div>

              <div className="bg-gray-50 rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-3">
                  <Share2 className="w-5 h-5 text-gray-700" />
                  <h3 className="font-bold text-gray-900">URL共有（オプション）</h3>
                </div>

                <div className="mb-3 space-y-2">
                  {(['hash', 'query', 'path'] as URLFormat[]).map((format) => (
                    <button
                      key={format}
                      onClick={() => setSelectedFormat(format)}
                      className={`w-full text-left px-4 py-3 rounded-xl border-2 transition-colors ${
                        selectedFormat === format
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      }`}
                    >
                      <div className="font-medium text-gray-900">{getFormatLabel(format)}</div>
                      <div className="text-xs text-gray-500 mt-1">{getFormatDescription(format)}</div>
                    </button>
                  ))}
                </div>

                <div className="bg-white rounded-xl p-3 mb-3 border-2 border-gray-200 overflow-x-auto">
                  <p className="text-sm font-mono text-gray-900 break-all">
                    {getRoomURL(roomId, selectedFormat)}
                  </p>
                </div>

                <button
                  onClick={handleCopyUrl}
                  className="w-full px-4 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 font-medium"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="w-5 h-5" />
                      URLをコピーしました
                    </>
                  ) : (
                    <>
                      <Copy className="w-5 h-5" />
                      URLをコピー
                    </>
                  )}
                </button>
                <p className="text-sm text-gray-600 mt-3 text-center">
                  警告が出る場合は別の形式を試してください
                </p>
              </div>

              {qrCodeUrl && (
                <div className="bg-gray-50 rounded-2xl p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <QrCode className="w-5 h-5 text-gray-700" />
                    <h3 className="font-bold text-gray-900">QRコード</h3>
                  </div>
                  <div className="bg-white rounded-xl p-4 flex justify-center">
                    <img src={qrCodeUrl} alt="QR Code" className="w-64 h-64" />
                  </div>
                  <p className="text-sm text-gray-600 mt-3 text-center">
                    QRコードをスキャンして参加
                  </p>
                </div>
              )}
            </div>

            <button
              onClick={() => setShowShareModal(false)}
              className="w-full mt-6 px-4 py-3 bg-gray-200 text-gray-900 rounded-xl hover:bg-gray-300 transition-colors font-medium"
            >
              閉じる
            </button>
          </div>
        </div>
      )}

      {currentUser && (
        <DirectMessagesModal
          isOpen={showDirectMessages}
          onClose={() => setShowDirectMessages(false)}
          currentUserId={currentUser.id}
          currentUserName={currentUser.display_name}
          isAdmin={currentUser.is_admin}
          roomId={roomId}
        />
      )}

      {expandedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4"
          onClick={() => setExpandedImage(null)}
        >
          <button
            onClick={() => setExpandedImage(null)}
            className="absolute top-4 right-4 p-2 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
          <img
            src={expandedImage}
            alt="拡大画像"
            className="max-w-full max-h-full object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      <div className="flex flex-col h-full overflow-hidden w-full">
        <div className="flex-shrink-0">
          <InstallBanner />

          {showPushBanner && (
            <PushNotificationBanner
              onEnable={handleEnablePushFromBanner}
              onDismiss={handleDismissPushBanner}
            />
          )}

          <header className="bg-white border-b border-gray-200 px-4 py-1.5 flex items-center justify-between w-full overflow-x-hidden">
            <div>
              <h1 className="text-sm font-bold text-gray-900">{roomName}</h1>
              <p className="text-[9px] text-gray-500">{currentUser?.display_name}</p>
            </div>
            <div className="flex items-center gap-1.5">
              {currentUser?.is_admin && (
                <>
                  <button
                    onClick={handleShare}
                    className="p-1.5 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition-colors"
                    title="共有"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setShowRoomList(true)}
                    className="p-1.5 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
                    title="ルーム一覧"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                </>
              )}
              <button
                onClick={() => setShowDirectMessages(true)}
                className="p-1.5 bg-purple-100 text-purple-600 rounded-lg hover:bg-purple-200 transition-colors relative"
                title="ダイレクトメッセージ"
              >
                <Mail className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>
              <button
                onClick={handleEnableNotifications}
                className={`p-1.5 rounded-lg transition-colors ${
                  notificationPermission === 'granted' && hasSubscription
                    ? 'bg-green-100 text-green-600 hover:bg-green-200'
                    : 'bg-red-100 text-red-600 hover:bg-red-200 animate-pulse'
                }`}
                title={
                  notificationPermission === 'granted' && hasSubscription
                    ? '通知: 有効'
                    : notificationPermission === 'denied'
                    ? '通知: ブロック中（タップして設定方法を確認）'
                    : '通知: 無効（タップして有効化）'
                }
              >
                {notificationPermission === 'granted' && hasSubscription ? (
                  <Bell className="w-4 h-4" />
                ) : (
                  <BellOff className="w-4 h-4" />
                )}
              </button>
              <button
                onClick={handleDeleteAccount}
                className="p-1.5 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors"
                title="退会する"
              >
                <LogOut className="w-4 h-4" />
              </button>
              <button
                onClick={handleAdminClick}
                className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                title="管理者パネル"
              >
                <Shield className="w-4 h-4" />
              </button>
            </div>
          </header>

          <AnnouncementBanner />
        </div>

        <div ref={messagesContainerRef} className="flex-1 overflow-y-auto overflow-x-hidden p-4 space-y-4 w-full">
          {loadingMore && (
            <div className="text-center py-2">
              <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <p className="text-sm text-gray-500 mt-2">メッセージを読み込み中...</p>
            </div>
          )}
          {!hasMore && messages.length > 0 && (
            <div className="text-center py-2">
              <p className="text-sm text-gray-500">これ以上古いメッセージはありません</p>
            </div>
          )}
          {filteredMessages.map((msg) => {
            const isOwn = msg.user_id === currentUser?.id;

            return (
              <div key={msg.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'} w-full max-w-full`}>
                <div className={`max-w-[75%] ${isOwn ? 'items-end' : 'items-start'} flex flex-col overflow-hidden`}>
                  {!isOwn && (
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-gray-700">
                        {msg.user?.display_name || '匿名ユーザー'}
                      </span>
                      {msg.user?.is_admin && (
                        <Shield className="w-3 h-3 text-red-500" />
                      )}
                    </div>
                  )}

                  <div className="flex items-end gap-2">
                    <div
                      className={`rounded-2xl px-4 py-2 max-w-full overflow-hidden ${
                        isOwn
                          ? 'bg-blue-600 text-white rounded-br-sm'
                          : 'bg-white text-gray-900 rounded-bl-sm shadow-sm'
                      }`}
                    >
                      {msg.content && (
                        <p className="text-sm whitespace-pre-wrap break-words overflow-wrap-anywhere">
                          {linkifyText(msg.content)}
                        </p>
                      )}

                      {msg.images && msg.images.length > 0 && (
                        <div className="flex flex-col gap-2 mt-2 max-w-full">
                          {msg.images.map((img, idx) => (
                            <img
                              key={idx}
                              src={img}
                              alt=""
                              loading="lazy"
                              decoding="async"
                              onClick={() => setExpandedImage(img)}
                              className="rounded-lg w-full h-auto object-contain max-h-96 cursor-pointer hover:opacity-90 transition-opacity"
                            />
                          ))}
                        </div>
                      )}
                    </div>

                    {currentUser?.is_admin && msg.user_id && (
                      <>
                        <button
                          onClick={() => handleToggleVisibility(msg.user_id!, msg.user?.is_visible ?? false)}
                          className={`p-1.5 rounded-lg transition-colors flex-shrink-0 ${
                            msg.user?.is_visible
                              ? 'bg-green-100 text-green-600 hover:bg-green-200'
                              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                          }`}
                          title={msg.user?.is_visible ? 'メッセージを非表示にする' : 'メッセージを表示する'}
                        >
                          {msg.user?.is_visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                        </button>
                        <button
                          onClick={() => handleDeleteMessage(msg.id)}
                          className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors flex-shrink-0"
                          title="メッセージを削除"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>

                  <span className="text-xs text-gray-400 mt-1">
                    {new Date(msg.created_at).toLocaleTimeString('ja-JP', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        <div
          className="bg-white border-t border-gray-200 p-4 flex-shrink-0 w-full overflow-x-hidden relative"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {isDragging && (
            <div className="absolute inset-0 bg-blue-500 bg-opacity-20 border-4 border-blue-500 border-dashed rounded-lg z-10 flex items-center justify-center pointer-events-none">
              <div className="bg-white px-6 py-4 rounded-lg shadow-lg">
                <p className="text-lg font-bold text-blue-600">画像をドロップして添付</p>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-3 bg-red-50 border border-red-200 rounded-xl p-3 flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {images.length > 0 && (
            <div className="mb-3 flex gap-2 overflow-x-auto">
              {images.map((img, idx) => (
                <div key={idx} className="relative flex-shrink-0">
                  <img src={img} alt="" loading="lazy" decoding="async" className="w-20 h-20 object-cover rounded-lg" />
                  <button
                    onClick={() => removeImage(idx)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex gap-2 w-full max-w-full">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={loading || images.length >= 4}
              className="p-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors disabled:opacity-50"
            >
              <ImageIcon className="w-5 h-5" />
            </button>

            <textarea
              ref={textareaRef}
              value={content}
              onChange={handleTextareaChange}
              onKeyDown={handleKeyDown}
              placeholder="メッセージを入力（Shift+Enterで改行）"
              maxLength={10000}
              disabled={loading}
              rows={1}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none overflow-hidden max-w-full"
            />

            <button
              type="submit"
              disabled={loading || (!content.trim() && images.length === 0)}
              className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

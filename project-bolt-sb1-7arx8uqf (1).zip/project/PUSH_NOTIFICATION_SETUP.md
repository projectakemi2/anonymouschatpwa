# プッシュ通知機能セットアップガイド

## 概要

完全なプッシュ通知機能が実装されました。以下のすべての状態で通知が届きます：

- ✅ iPhone / Android 両対応
- ✅ アプリを閉じている状態
- ✅ スマホがロックされている状態
- ✅ 画面オフの状態

## 技術仕様

### 使用技術
- **Web Push API**: PWA向けプッシュ通知
- **Service Worker**: バックグラウンド通知受信
- **VAPID認証**: セキュアな通知配信
- **Supabase Edge Functions**: プッシュ通知送信サーバー

### データベース
- `push_subscriptions` テーブル: ユーザーごとの通知トークン管理
- RLS (Row Level Security) 有効化済み

## セットアップ済み項目

### 1. データベース ✅
- プッシュ通知サブスクリプション管理テーブル作成完了
- RLSポリシー設定完了

### 2. VAPID キー ✅
以下のキーが生成され、設定済みです：

```
Public Key: BC6oeVeXz14j2ySKI4d_qRKi7-f-AxrQOP1GBZ97ATq-ENiiDykPVcE3gGicKrVQJv3lhnBHb4RjyZYoKna9DFE
Private Key: QhMJipODLjp7nNzsjsazsqKg9fgBlfLFiQ21E3DuonA
```

`.env`ファイルに自動設定済み。

### 3. Edge Function ✅
`send-push-notification` Edge Function がデプロイ済み。
メッセージ送信時に自動的に呼び出されます。

### 4. Service Worker ✅
`public/sw.js` にプッシュ通知受信処理を実装済み。
バックグラウンドでも通知を受信できます。

### 5. フロントエンド ✅
以下の機能が実装済み：
- 初回登録時に通知許可ダイアログ表示
- プッシュ通知サブスクリプション自動登録
- メッセージ送信時に自動的にプッシュ通知送信

## 動作フロー

### 1. ユーザー登録時
```
1. ユーザーが表示名を入力して登録
2. 通知許可ダイアログが自動表示
3. ユーザーが「許可」をタップ
4. プッシュ通知トークンが自動生成・保存
```

### 2. メッセージ送信時
```
1. ユーザーAがメッセージを送信
2. メッセージがデータベースに保存
3. Edge Functionが自動起動
4. 同じルームの他のユーザーにプッシュ通知送信
5. ユーザーBのデバイス（アプリ閉じていても）に通知が届く
```

### 3. 通知受信時
```
1. Service Workerがバックグラウンドで通知を受信
2. OS標準の通知が表示（ロック画面・通知センター）
3. ユーザーが通知をタップ
4. アプリが開き、該当のチャット画面を表示
```

## ファイル構成

```
src/
├── lib/
│   ├── push.ts                  # プッシュ通知管理ライブラリ
│   ├── notification.ts          # 通知許可管理
│   └── messages.ts              # メッセージ送信時に通知トリガー
├── components/
│   ├── RegisterScreen.tsx       # 登録時に通知許可リクエスト
│   └── ChatScreen.tsx           # チャット画面で通知状態チェック
supabase/
├── migrations/
│   └── add_push_subscriptions_table.sql  # データベーステーブル
└── functions/
    └── send-push-notification/
        └── index.ts             # プッシュ通知送信Edge Function
public/
└── sw.js                        # Service Worker（プッシュ受信処理）
```

## 動作確認方法

### 1. デスクトップブラウザ（Chrome, Edge, Firefox）
1. アプリを開く
2. 通知許可ダイアログで「許可」をクリック
3. 別のブラウザで別ユーザーとしてログイン
4. メッセージを送信
5. 最初のブラウザに通知が表示される（ブラウザを閉じていても）

### 2. iPhone（Safari）
1. Safari でアプリを開く
2. 「ホーム画面に追加」でPWAをインストール
3. PWAアプリを開く
4. 通知許可ダイアログで「許可」をタップ
5. アプリを閉じる（ホーム画面に戻る）
6. 別デバイスから同じルームにメッセージを送信
7. iPhoneのロック画面に通知が表示される

### 3. Android（Chrome）
1. Chrome でアプリを開く
2. 「ホーム画面に追加」でPWAをインストール
3. PWAアプリを開く
4. 通知許可ダイアログで「許可」をタップ
5. アプリを閉じる（ホーム画面に戻る）
6. 別デバイスから同じルームにメッセージを送信
7. Androidの通知センターに通知が表示される

## トラブルシューティング

### 通知が届かない場合

#### 1. 通知許可を確認
- ブラウザ/デバイスの設定で通知が許可されているか確認
- PWAの場合、アプリの通知設定も確認

#### 2. Service Worker を確認
- Chrome DevTools → Application → Service Workers
- Service Workerが登録されているか確認

#### 3. プッシュサブスクリプションを確認
```javascript
// ブラウザコンソールで実行
navigator.serviceWorker.ready.then(reg => {
  reg.pushManager.getSubscription().then(sub => {
    console.log('Subscription:', sub);
  });
});
```

#### 4. データベースを確認
```sql
SELECT * FROM push_subscriptions;
```

### よくある問題

#### iOS Safariで通知が届かない
- PWAとしてインストールされているか確認
- iOS 16.4以降が必要
- Safariの通常ブラウジングモードではプッシュ通知非対応

#### Androidで通知が届かない
- Chrome 63以降が必要
- バッテリーセーバーモードをOFF
- アプリのバックグラウンド制限を解除

## セキュリティ

### VAPID キー
- Private Keyは絶対に公開しない
- Supabase Edge Function内でのみ使用
- Public Keyはフロントエンドで使用（安全）

### RLS (Row Level Security)
- ユーザーは自分のサブスクリプションのみ管理可能
- Service Roleのみ全ユーザーの通知送信が可能

## パフォーマンス

- 通知送信は非同期処理（メッセージ送信をブロックしない）
- 無効なサブスクリプションは自動削除
- Edge Functionでバッチ処理

## 今後の拡張

### Firebase Cloud Messaging (FCM) 対応
現在はWeb Push APIを使用していますが、将来的にFCMを追加することで：
- より安定した通知配信
- 高度な通知管理
- アナリティクス統合

が可能になります。

### APNs (Apple Push Notification service) 対応
ネイティブiOSアプリ化する場合、APNsの統合が必要です。

## まとめ

✅ **完全実装完了**

- iPhone / Android 両対応
- アプリを閉じていても通知が届く
- スマホがロックされていても通知が届く
- 画面オフでも通知が届く
- OS標準の通知（ロック画面・通知センター）に表示
- タップでアプリを開く

すべての要件を満たしています。

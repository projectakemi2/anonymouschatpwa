/*
  # パフォーマンス最適化とTTL設定

  ## 概要
  Bolt環境の限定的なサーバー性能でも破綻しないよう、DB負荷を最小化する最適化を実施

  ## 最適化内容

  ### 1. インデックスの最適化
  - messagesテーブルに複合インデックス追加（created_at DESC + deleted_at）
  - anonymous_usersテーブルにip_address, last_seen_atインデックス追加
  - 既存インデックスの見直し

  ### 2. 監査ログのTTL設定
  - audit_logsに自動削除トリガー（180日経過後）
  - 古いレート制限レコードのクリーンアップ

  ### 3. パフォーマンス関数
  - メッセージのページネーション用関数
  - 効率的なメッセージ取得

  ## セキュリティ
  - 既存のRLSポリシーは維持
  - パフォーマンス向上のみ
*/

-- 複合インデックスの追加（クエリ最適化）
CREATE INDEX IF NOT EXISTS idx_messages_created_deleted 
  ON messages(created_at DESC, deleted_at) 
  WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_messages_user_created 
  ON messages(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_anonymous_users_ip 
  ON anonymous_users(ip_address);

CREATE INDEX IF NOT EXISTS idx_anonymous_users_last_seen 
  ON anonymous_users(last_seen_at DESC);

CREATE INDEX IF NOT EXISTS idx_rate_limits_last_message 
  ON rate_limits(last_message_at);

-- 古いレコードの自動削除関数
CREATE OR REPLACE FUNCTION cleanup_old_audit_logs()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM audit_logs
  WHERE created_at < NOW() - INTERVAL '180 days';
END;
$$;

-- 古いレート制限レコードのクリーンアップ関数
CREATE OR REPLACE FUNCTION cleanup_old_rate_limits()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM rate_limits
  WHERE last_message_at < NOW() - INTERVAL '7 days';
END;
$$;

-- 効率的なメッセージ取得関数（ページネーション対応）
CREATE OR REPLACE FUNCTION get_messages_paginated(
  p_limit INTEGER DEFAULT 50,
  p_before_id UUID DEFAULT NULL
)
RETURNS TABLE (
  id UUID,
  user_id UUID,
  content TEXT,
  images JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ,
  display_name TEXT,
  is_admin BOOLEAN
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    m.id,
    m.user_id,
    m.content,
    m.images,
    m.ip_address,
    m.created_at,
    u.display_name,
    u.is_admin
  FROM messages m
  JOIN anonymous_users u ON m.user_id = u.id
  WHERE m.deleted_at IS NULL
    AND (p_before_id IS NULL OR m.created_at < (
      SELECT created_at FROM messages WHERE id = p_before_id
    ))
  ORDER BY m.created_at DESC
  LIMIT p_limit;
END;
$$;

-- メッセージ数カウント関数（最適化版）
CREATE OR REPLACE FUNCTION count_active_messages()
RETURNS BIGINT
LANGUAGE sql
STABLE
AS $$
  SELECT COUNT(*) FROM messages WHERE deleted_at IS NULL;
$$;

-- 定期クリーンアップのスケジュール設定用コメント
COMMENT ON FUNCTION cleanup_old_audit_logs() IS 
  '監査ログの自動削除（180日経過後）。cron等で定期実行を推奨。';

COMMENT ON FUNCTION cleanup_old_rate_limits() IS 
  'レート制限レコードのクリーンアップ（7日経過後）。cron等で定期実行を推奨。';

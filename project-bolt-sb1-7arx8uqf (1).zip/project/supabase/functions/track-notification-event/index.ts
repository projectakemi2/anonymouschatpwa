import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { subscription_id, campaign_id, event_type } = await req.json();

    if (!subscription_id || !event_type) {
      return new Response(
        JSON.stringify({ error: 'subscription_id and event_type are required' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }

    if (!['clicked', 'dismissed', 'delivered'].includes(event_type)) {
      return new Response(
        JSON.stringify({ error: 'Invalid event_type' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }

    await supabase.from('notification_events').insert({
      subscription_id,
      campaign_id: campaign_id || null,
      event_type,
      metadata: {
        timestamp: new Date().toISOString(),
        source: 'service_worker'
      }
    });

    await supabase.rpc('update_subscription_stats', {
      sub_id: subscription_id,
      event: event_type,
      should_increment_failure: false
    });

    console.log(`Tracked ${event_type} event for subscription ${subscription_id}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Event tracked successfully'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

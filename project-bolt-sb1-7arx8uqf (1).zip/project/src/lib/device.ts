export function generateDeviceId(): string {
  let deviceId = localStorage.getItem('device_id');

  if (!deviceId) {
    deviceId = `device_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    localStorage.setItem('device_id', deviceId);
  }

  return deviceId;
}

export async function getClientIP(): Promise<string> {
  const cachedIP = sessionStorage.getItem('client_ip');
  if (cachedIP && !cachedIP.startsWith('temp_') && cachedIP !== 'unknown') {
    return cachedIP;
  }

  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const apiUrl = `${supabaseUrl}/functions/v1/get-client-ip`;

    const response = await fetch(apiUrl, {
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      signal: AbortSignal.timeout(8000)
    });

    if (response.ok) {
      const data = await response.json();
      if (data.ip && data.ip !== 'unknown') {
        sessionStorage.setItem('client_ip', data.ip);
        return data.ip;
      }
    }
  } catch (error) {
    console.error('Edge Function IP fetch failed:', error);
  }

  try {
    const response = await fetch('https://api.ipify.org?format=json', {
      signal: AbortSignal.timeout(5000)
    });
    if (!response.ok) throw new Error('IP fetch failed');

    const data = await response.json();
    const ip = data.ip;
    if (ip) {
      sessionStorage.setItem('client_ip', ip);
      return ip;
    }
  } catch (error) {
    console.error('ipify.org failed:', error);
  }

  try {
    const backupResponse = await fetch('https://api64.ipify.org?format=json', {
      signal: AbortSignal.timeout(5000)
    });
    if (backupResponse.ok) {
      const backupData = await backupResponse.json();
      const ip = backupData.ip;
      if (ip) {
        sessionStorage.setItem('client_ip', ip);
        return ip;
      }
    }
  } catch (backupError) {
    console.error('api64.ipify.org failed:', backupError);
  }

  const tempIP = `temp_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  sessionStorage.setItem('client_ip', tempIP);
  return tempIP;
}

export function isStandalone(): boolean {
  return window.matchMedia('(display-mode: standalone)').matches ||
         (window.navigator as any).standalone === true;
}

export function isPWAInstalled(): boolean {
  return localStorage.getItem('pwa_installed') === 'true' || isStandalone();
}

export function markPWAInstalled(): void {
  localStorage.setItem('pwa_installed', 'true');
}

export function isIOS(): boolean {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
}

export function isInStandaloneMode(): boolean {
  return ('standalone' in window.navigator) && (window.navigator as any).standalone;
}

export function isSafari(): boolean {
  const ua = navigator.userAgent.toLowerCase();
  const isIOSDevice = /iphone|ipad|ipod/.test(ua);
  const isSafariUA = /safari/.test(ua) && !/chrome|crios|fxios|edgios|opios/.test(ua);
  return isIOSDevice && isSafariUA;
}

export function isAndroid(): boolean {
  return /android/i.test(navigator.userAgent);
}

export function needsSafariRedirect(): boolean {
  return isIOS() && !isSafari() && !isStandalone();
}

export function getDeviceInfo() {
  const ua = navigator.userAgent;
  const isIOS = /iPad|iPhone|iPod/.test(ua);
  const isAndroid = /android/i.test(ua);

  let platform = 'Unknown';
  let osVersion = 'Unknown';
  let browser = 'Unknown';
  let browserVersion = 'Unknown';

  if (isIOS) {
    platform = 'iOS';
    const match = ua.match(/OS (\d+)_(\d+)_?(\d+)?/);
    if (match) {
      osVersion = `${match[1]}.${match[2]}${match[3] ? '.' + match[3] : ''}`;
    }

    if (/CriOS/.test(ua)) {
      browser = 'Chrome';
      const chromeMatch = ua.match(/CriOS\/(\d+\.\d+)/);
      if (chromeMatch) browserVersion = chromeMatch[1];
    } else if (/FxiOS/.test(ua)) {
      browser = 'Firefox';
      const firefoxMatch = ua.match(/FxiOS\/(\d+\.\d+)/);
      if (firefoxMatch) browserVersion = firefoxMatch[1];
    } else if (/Safari/.test(ua) && !/Chrome/.test(ua)) {
      browser = 'Safari';
      const safariMatch = ua.match(/Version\/(\d+\.\d+)/);
      if (safariMatch) browserVersion = safariMatch[1];
    }
  } else if (isAndroid) {
    platform = 'Android';
    const match = ua.match(/Android (\d+\.?\d*\.?\d*)/);
    if (match) {
      osVersion = match[1];
    }

    if (/Chrome/.test(ua) && !/Edg/.test(ua)) {
      browser = 'Chrome';
      const chromeMatch = ua.match(/Chrome\/(\d+\.\d+)/);
      if (chromeMatch) browserVersion = chromeMatch[1];
    } else if (/Firefox/.test(ua)) {
      browser = 'Firefox';
      const firefoxMatch = ua.match(/Firefox\/(\d+\.\d+)/);
      if (firefoxMatch) browserVersion = firefoxMatch[1];
    } else if (/Edg/.test(ua)) {
      browser = 'Edge';
      const edgeMatch = ua.match(/Edg\/(\d+\.\d+)/);
      if (edgeMatch) browserVersion = edgeMatch[1];
    }
  } else {
    if (/Win/.test(ua)) platform = 'Windows';
    else if (/Mac/.test(ua)) platform = 'macOS';
    else if (/Linux/.test(ua)) platform = 'Linux';

    if (/Chrome/.test(ua) && !/Edg/.test(ua)) {
      browser = 'Chrome';
      const chromeMatch = ua.match(/Chrome\/(\d+\.\d+)/);
      if (chromeMatch) browserVersion = chromeMatch[1];
    } else if (/Firefox/.test(ua)) {
      browser = 'Firefox';
      const firefoxMatch = ua.match(/Firefox\/(\d+\.\d+)/);
      if (firefoxMatch) browserVersion = firefoxMatch[1];
    } else if (/Edg/.test(ua)) {
      browser = 'Edge';
      const edgeMatch = ua.match(/Edg\/(\d+\.\d+)/);
      if (edgeMatch) browserVersion = edgeMatch[1];
    } else if (/Safari/.test(ua) && !/Chrome/.test(ua)) {
      browser = 'Safari';
      const safariMatch = ua.match(/Version\/(\d+\.\d+)/);
      if (safariMatch) browserVersion = safariMatch[1];
    }
  }

  return {
    userAgent: ua,
    platform,
    osVersion,
    browser,
    browserVersion,
    isStandalone: isStandalone(),
  };
}

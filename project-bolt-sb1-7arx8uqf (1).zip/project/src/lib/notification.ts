let notificationPermission: NotificationPermission = 'default';

export async function requestNotificationPermission(): Promise<boolean> {
  if (!('Notification' in window)) {
    console.warn('This browser does not support notifications');
    return false;
  }

  if (Notification.permission === 'granted') {
    notificationPermission = 'granted';
    console.log('✅ 通知許可: 既に許可されています');
    return true;
  }

  if (Notification.permission === 'denied') {
    console.warn('⚠️ 通知許可: ブロックされています。設定から許可してください。');
    return false;
  }

  try {
    const permission = await Notification.requestPermission();
    notificationPermission = permission;

    if (permission === 'granted') {
      console.log('✅ 通知許可: 許可されました');
      await showTestNotification();
      return true;
    } else {
      console.warn('⚠️ 通知許可: 拒否されました');
      return false;
    }
  } catch (error) {
    console.error('❌ 通知許可リクエストエラー:', error);
    return false;
  }
}

async function showTestNotification(): Promise<void> {
  try {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification('通知テスト', {
        body: '新しいメッセージが届いたときに通知されます',
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        vibrate: [200, 100, 200],
        tag: 'test-notification',
        requireInteraction: false,
        silent: false
      });
    } else {
      new Notification('通知テスト', {
        body: '新しいメッセージが届いたときに通知されます',
        icon: '/icon-192.png',
        tag: 'test-notification'
      });
    }
  } catch (error) {
    console.warn('テスト通知の表示に失敗:', error);
  }
}

export function getNotificationPermission(): NotificationPermission {
  if ('Notification' in window) {
    return Notification.permission;
  }
  return 'denied';
}

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered:', registration);

      // Service Workerが準備できるまで待つ
      await navigator.serviceWorker.ready;

      return registration;
    } catch (error) {
      console.warn('Service Worker not supported or registration failed:', error);
      return null;
    }
  }
  console.warn('Service Worker not supported in this environment');
  return null;
}

export async function sendUserInfoToServiceWorker(userId: string, roomId: string): Promise<void> {
  if (!('serviceWorker' in navigator)) {
    console.warn('❌ Service Worker not supported');
    return;
  }

  try {
    // Service Workerが準備できるまで待つ
    await navigator.serviceWorker.ready;

    // アクティブなService Workerを取得
    const registration = await navigator.serviceWorker.ready;
    if (!registration.active) {
      console.warn('❌ No active Service Worker found');
      return;
    }

    // controllerがない場合は、少し待ってから再試行
    if (!navigator.serviceWorker.controller) {
      console.log('⏳ Waiting for Service Worker controller...');
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    if (navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SET_USER_INFO',
        userId,
        roomId
      });
      console.log('✅ User info sent to Service Worker:', { userId, roomId });
    } else {
      console.warn('❌ Service Worker controller not available');
    }
  } catch (error) {
    console.error('❌ Failed to send user info to Service Worker:', error);
  }
}

export async function showNotification(title: string, body: string): Promise<void> {
  if (!('Notification' in window)) {
    console.warn('Notifications not supported');
    return;
  }

  const permission = Notification.permission;

  if (permission === 'denied') {
    console.warn('⚠️ 通知許可がブロックされています');
    return;
  }

  if (permission !== 'granted') {
    console.warn('⚠️ 通知許可がありません。許可をリクエストしてください。');
    const newPermission = await requestNotificationPermission();
    if (!newPermission) {
      return;
    }
  }

  try {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.ready;

        await registration.showNotification(title, {
          body,
          icon: '/icon-192.png',
          badge: '/icon-192.png',
          vibrate: [300, 100, 300, 100, 300],
          tag: `message-${Date.now()}`,
          requireInteraction: false,
          silent: false,
          renotify: true,
          timestamp: Date.now(),
          data: {
            url: window.location.href,
            timestamp: Date.now()
          }
        });

        console.log('🔔 通知表示成功 (Service Worker):', title);
        return;
      } catch (swError) {
        console.warn('Service Worker notification failed, using Notification API:', swError);
      }
    }

    const notification = new Notification(title, {
      body,
      icon: '/icon-192.png',
      tag: `message-${Date.now()}`,
      vibrate: [300, 100, 300, 100, 300],
      requireInteraction: false,
      silent: false,
      timestamp: Date.now()
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };

    console.log('🔔 通知表示成功 (Notification API):', title);
  } catch (error) {
    console.error('❌ 通知表示エラー:', error);
  }
}

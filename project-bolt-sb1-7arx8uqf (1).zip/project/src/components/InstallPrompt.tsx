import { useState, useEffect } from 'react';
import { Smartphone, Share, ExternalLink } from 'lucide-react';
import { markPWAInstalled, isIOS as checkIsIOS, isAndroid as checkIsAndroid } from '../lib/device';

interface InstallPromptProps {
  onComplete: () => void;
}

export default function InstallPrompt({ onComplete }: InstallPromptProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isInAppBrowser, setIsInAppBrowser] = useState(false);

  useEffect(() => {
    const userAgent = window.navigator.userAgent.toLowerCase();
    const ios = checkIsIOS();
    const android = checkIsAndroid();

    const inAppBrowser = /line|fban|fbav|instagram|twitter/.test(userAgent);

    setIsIOS(ios);
    setIsAndroid(android);
    setIsInAppBrowser(inAppBrowser);

    console.log('InstallPrompt mounted - isAndroid:', android, 'isIOS:', ios);

    if ((window as any).deferredPrompt) {
      console.log('Found existing deferred prompt on mount');
      setDeferredPrompt((window as any).deferredPrompt);
    }

    const handler = (e: Event) => {
      console.log('InstallPrompt received beforeinstallprompt');
      e.preventDefault();
      setDeferredPrompt(e);
      (window as any).deferredPrompt = e;
    };

    const installableHandler = () => {
      console.log('PWA is installable event received');
      if ((window as any).deferredPrompt) {
        setDeferredPrompt((window as any).deferredPrompt);
      }
    };

    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('pwainstallable', installableHandler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.removeEventListener('pwainstallable', installableHandler);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;

        if (outcome === 'accepted') {
          markPWAInstalled();
          onComplete();
        }

        setDeferredPrompt(null);
        (window as any).deferredPrompt = null;
      } catch (error) {
        console.error('Install prompt error:', error);
      }
    }
  };

  // iOSのアプリ内ブラウザの場合
  if (isInAppBrowser && isIOS) {
    const handleOpenInSafari = () => {
      const currentUrl = window.location.href;
      const safariUrl = currentUrl.replace(/^https?:\/\//, 'x-safari-https://');

      window.location.href = safariUrl;

      setTimeout(() => {
        alert('画面右上のメニュー（···）から「Safariで開く」を選択してください');
      }, 500);
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-orange-500 rounded-full mb-4">
              <ExternalLink className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-3">Safariで開く</h1>
            <p className="text-gray-600 leading-relaxed">
              アプリをインストールするには<br />Safariで開く必要があります
            </p>
          </div>

          <button
            onClick={handleOpenInSafari}
            className="w-full bg-orange-600 text-white rounded-2xl py-5 font-bold hover:bg-orange-700 transition-all transform hover:scale-105 text-xl shadow-lg mb-6"
          >
            Safariで開く
          </button>

          <div className="bg-orange-50 rounded-2xl p-6">
            <h3 className="font-bold text-gray-900 mb-3 text-sm">手動で開く場合</h3>
            <ol className="space-y-3 text-gray-700">
              <li className="flex items-start gap-3">
                <span className="font-bold text-orange-600 min-w-[20px]">1</span>
                <span className="text-sm">画面右上のメニュー（···）をタップ</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold text-orange-600 min-w-[20px]">2</span>
                <span className="text-sm">「Safariで開く」を選択</span>
              </li>
            </ol>
          </div>
        </div>
      </div>
    );
  }

  // Android（Chrome）の場合は優先的に処理
  if (isAndroid) {
    const handleAndroidInstall = async () => {
      if (deferredPrompt) {
        try {
          console.log('Showing install prompt immediately...');
          await deferredPrompt.prompt();
          const { outcome } = await deferredPrompt.userChoice;
          console.log('User choice:', outcome);

          if (outcome === 'accepted') {
            markPWAInstalled();
            onComplete();
          }

          setDeferredPrompt(null);
          (window as any).deferredPrompt = null;
        } catch (error) {
          console.error('Install prompt error:', error);
          alert('画面右上のメニュー（⋮）をタップして、「アプリをインストール」または「ホーム画面に追加」を選択してください');
        }
      } else {
        console.log('No deferred prompt available, showing manual instructions immediately');

        alert('画面右上のメニュー（⋮）をタップして、「アプリをインストール」または「ホーム画面に追加」を選択してください');
      }
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-green-500 rounded-full mb-4">
              <Smartphone className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-3">アプリをインストール</h1>
            <p className="text-gray-600 leading-relaxed">
              ワンタップでホーム画面に追加できます
            </p>
          </div>

          <button
            onClick={handleAndroidInstall}
            className="w-full bg-green-600 text-white rounded-2xl py-5 font-bold hover:bg-green-700 transition-all transform hover:scale-105 text-xl shadow-lg mb-3"
          >
            インストール
          </button>

          <button
            onClick={onComplete}
            className="w-full bg-gray-100 text-gray-700 rounded-2xl py-4 font-semibold hover:bg-gray-200 transition-all"
          >
            アプリインストールできない人はそのままログイン
          </button>

          <div className="text-center text-sm text-gray-500 mt-6">
            通知受信とオフライン利用が可能になります
          </div>
        </div>
      </div>
    );
  }

  // iPhone（Safari）の場合
  if (isIOS) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-6">
            <div className="inline-block p-4 bg-blue-500 rounded-full mb-4">
              <Smartphone className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-3">アプリをインストール</h1>
            <p className="text-gray-600 leading-relaxed">
              ホーム画面に追加して<br />アプリとして使おう
            </p>
          </div>

          <div className="bg-blue-50 rounded-2xl p-6 mb-6">
            <h3 className="font-bold text-gray-900 mb-4 text-center">インストール手順</h3>
            <ol className="space-y-4 text-gray-700">
              <li className="flex items-start gap-3">
                <span className="font-bold text-blue-600 text-lg min-w-[28px]">1</span>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Share className="w-5 h-5 text-blue-600" />
                    <span className="text-base font-semibold">共有ボタンをタップ</span>
                  </div>
                  <span className="text-sm text-gray-600">画面下部の共有アイコン（□に↑）</span>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold text-blue-600 text-lg min-w-[28px]">2</span>
                <span className="text-base">「ホーム画面に追加」を選択</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold text-blue-600 text-lg min-w-[28px]">3</span>
                <span className="text-base">「追加」をタップして完了</span>
              </li>
            </ol>
          </div>

          <button
            onClick={onComplete}
            className="w-full bg-blue-600 text-white rounded-2xl py-5 font-bold hover:bg-blue-700 transition-all transform hover:scale-105 text-xl shadow-lg mb-3"
          >
            今すぐ使う
          </button>

          <button
            onClick={onComplete}
            className="w-full bg-gray-100 text-gray-700 rounded-2xl py-4 font-semibold hover:bg-gray-200 transition-all"
          >
            アプリインストールできない人はそのままログイン
          </button>

          <p className="text-xs text-gray-500 text-center mt-4">
            インストールせずに使うこともできます
          </p>
        </div>
      </div>
    );
  }

  // PC やその他のデバイス
  const handlePCInstall = () => {
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isMobile = /iphone|ipad|ipod|android/.test(userAgent);

    if (isMobile) {
      alert('ブラウザのメニューから「ホーム画面に追加」または「アプリをインストール」を選択してください');
    } else {
      alert('このアプリはスマートフォンでの利用を推奨しています。\n\nスマートフォンからアクセスしてホーム画面に追加してください。');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-6">
          <div className="inline-block p-4 bg-blue-500 rounded-full mb-4">
            <Smartphone className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-3">参加者オープンチャット</h1>
          <p className="text-gray-600 leading-relaxed">
            このアプリはスマートフォンでの利用を<br />推奨しています
          </p>
        </div>

        <div className="bg-blue-50 rounded-2xl p-5 mb-6">
          <h3 className="font-bold text-gray-900 mb-3 text-sm">スマートフォンでご利用の方へ</h3>
          <p className="text-sm text-gray-700 mb-4">
            ホーム画面に追加すると、アプリとして快適にご利用いただけます
          </p>
          <div className="space-y-3">
            <div className="bg-white rounded-xl p-3">
              <p className="font-semibold text-gray-900 text-sm mb-1">iPhone（Safari）</p>
              <p className="text-xs text-gray-600">画面下部の共有ボタン → 「ホーム画面に追加」</p>
            </div>
            <div className="bg-white rounded-xl p-3">
              <p className="font-semibold text-gray-900 text-sm mb-1">Android（Chrome）</p>
              <p className="text-xs text-gray-600">メニュー（⋮）→ 「アプリをインストール」</p>
            </div>
          </div>
        </div>

        <button
          onClick={handlePCInstall}
          className="w-full bg-blue-600 text-white rounded-2xl py-5 font-bold hover:bg-blue-700 transition-all transform hover:scale-105 text-xl shadow-lg mb-3"
        >
          アプリをインストール
        </button>

        <button
          onClick={onComplete}
          className="w-full bg-gray-100 text-gray-700 rounded-2xl py-4 font-semibold hover:bg-gray-200 transition-all"
        >
          アプリインストールできない人はそのままログイン
        </button>

        <p className="text-xs text-gray-500 text-center mt-4">
          スマートフォンからアクセスしてインストールしてください
        </p>
      </div>
    </div>
  );
}

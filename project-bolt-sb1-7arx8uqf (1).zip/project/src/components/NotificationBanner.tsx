import { useState, useEffect } from 'react';
import { X, Bell } from 'lucide-react';
import {
  getUnreadNotifications,
  markNotificationAsRead,
  subscribeToNotifications,
  type InAppNotification
} from '../lib/in-app-notifications';

export function NotificationBanner() {
  const [notifications, setNotifications] = useState<InAppNotification[]>([]);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    loadNotifications();

    const unsubscribe = subscribeToNotifications((newNotification) => {
      setNotifications(prev => [newNotification, ...prev]);
      setIsVisible(true);
    });

    return unsubscribe;
  }, []);

  const loadNotifications = async () => {
    const unread = await getUnreadNotifications();
    setNotifications(unread);
    setIsVisible(unread.length > 0);
  };

  const handleDismiss = async (notification: InAppNotification) => {
    await markNotificationAsRead(notification.id);
    setNotifications(prev => prev.filter(n => n.id !== notification.id));

    if (notifications.length <= 1) {
      setIsVisible(false);
    }
  };

  const handleClick = async (notification: InAppNotification) => {
    await markNotificationAsRead(notification.id);
    setNotifications(prev => prev.filter(n => n.id !== notification.id));

    if (notification.url) {
      window.location.href = notification.url;
    }

    if (notifications.length <= 1) {
      setIsVisible(false);
    }
  };

  if (!isVisible || notifications.length === 0) {
    return null;
  }

  const currentNotification = notifications[0];

  return (
    <div className="fixed top-4 right-4 left-4 md:left-auto md:w-96 z-50 animate-slide-down">
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg shadow-2xl overflow-hidden">
        <div className="p-4">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 mt-1">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Bell className="w-5 h-5" />
              </div>
            </div>

            <div
              className="flex-1 cursor-pointer"
              onClick={() => handleClick(currentNotification)}
            >
              <div className="font-semibold text-sm mb-1">
                {currentNotification.title}
              </div>
              <div className="text-sm text-white/90 line-clamp-2">
                {currentNotification.body}
              </div>
              {notifications.length > 1 && (
                <div className="text-xs text-white/70 mt-2">
                  +{notifications.length - 1} more notifications
                </div>
              )}
            </div>

            <button
              onClick={() => handleDismiss(currentNotification)}
              className="flex-shrink-0 p-1 hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="h-1 bg-white/20">
          <div
            className="h-full bg-white animate-progress"
            style={{ animationDuration: '5s' }}
          />
        </div>
      </div>
    </div>
  );
}

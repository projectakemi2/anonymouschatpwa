import { useState, useEffect } from 'react';
import { Megaphone, Plus, Edit2, Trash2, Eye, EyeOff, ArrowUp, ArrowDown, X } from 'lucide-react';
import {
  Announcement,
  getAllAnnouncements,
  createAnnouncement,
  updateAnnouncement,
  deleteAnnouncement,
  toggleAnnouncementActive,
  updateAnnouncementPriority
} from '../lib/announcements';
import { AnonymousUser } from '../lib/user';

interface AnnouncementManagerProps {
  currentUser: AnonymousUser;
  onClose: () => void;
}

interface AnnouncementForm {
  title: string;
  body: string;
  url: string;
  is_active: boolean;
  priority: number;
}

export default function AnnouncementManager({ currentUser, onClose }: AnnouncementManagerProps) {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<AnnouncementForm>({
    title: '',
    body: '',
    url: '',
    is_active: false,
    priority: 1
  });

  useEffect(() => {
    loadAnnouncements();
  }, []);

  const loadAnnouncements = async () => {
    try {
      setLoading(true);
      const data = await getAllAnnouncements();
      setAnnouncements(data);
    } catch (err) {
      setError('アナウンスの読み込みに失敗しました');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      if (editingId) {
        await updateAnnouncement(editingId, {
          title: formData.title,
          body: formData.body,
          url: formData.url || null,
          is_active: formData.is_active,
          priority: formData.priority
        });
        setSuccess('アナウンスを更新しました');
      } else {
        await createAnnouncement(currentUser.id, formData);
        setSuccess('アナウンスを作成しました');
      }

      setShowForm(false);
      setEditingId(null);
      setFormData({
        title: '',
        body: '',
        url: '',
        is_active: false,
        priority: 1
      });
      await loadAnnouncements();
    } catch (err: any) {
      setError(err.message || 'エラーが発生しました');
    }
  };

  const handleEdit = (announcement: Announcement) => {
    setEditingId(announcement.id);
    setFormData({
      title: announcement.title,
      body: announcement.body,
      url: announcement.url || '',
      is_active: announcement.is_active,
      priority: announcement.priority
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('このアナウンスを削除してもよろしいですか？')) {
      return;
    }

    try {
      await deleteAnnouncement(id);
      setSuccess('アナウンスを削除しました');
      await loadAnnouncements();
    } catch (err: any) {
      setError(err.message || '削除に失敗しました');
    }
  };

  const handleToggleActive = async (id: string, currentActive: boolean) => {
    try {
      await toggleAnnouncementActive(id, !currentActive);
      setSuccess(`アナウンスを${!currentActive ? '表示' : '非表示'}にしました`);
      await loadAnnouncements();
    } catch (err: any) {
      setError(err.message || '状態の変更に失敗しました');
    }
  };

  const handlePriorityChange = async (id: string, delta: number) => {
    const announcement = announcements.find(a => a.id === id);
    if (!announcement) return;

    const newPriority = announcement.priority + delta;
    if (newPriority < 1 || newPriority > 3) return;

    try {
      await updateAnnouncementPriority(id, newPriority);
      await loadAnnouncements();
    } catch (err: any) {
      setError(err.message || '優先度の変更に失敗しました');
    }
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingId(null);
    setFormData({
      title: '',
      body: '',
      url: '',
      is_active: false,
      priority: 1
    });
    setError('');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Megaphone className="w-6 h-6" />
            <h2 className="text-2xl font-bold">アナウンス管理</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          {success && (
            <div className="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
              {success}
            </div>
          )}

          {!showForm && (
            <button
              onClick={() => setShowForm(true)}
              className="mb-6 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Plus className="w-5 h-5" />
              新しいアナウンスを作成
            </button>
          )}

          {showForm && (
            <form onSubmit={handleSubmit} className="mb-6 bg-gray-50 p-6 rounded-lg border border-gray-200">
              <h3 className="text-lg font-semibold mb-4">
                {editingId ? 'アナウンスを編集' : '新しいアナウンス'}
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    タイトル *
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    maxLength={200}
                    required
                    className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="アナウンスのタイトル"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    本文 *
                  </label>
                  <textarea
                    value={formData.body}
                    onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                    maxLength={2000}
                    required
                    rows={4}
                    className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="アナウンスの内容"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    リンク（任意）
                  </label>
                  <input
                    type="url"
                    value={formData.url}
                    onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="https://example.com"
                  />
                </div>

                <div className="flex gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      優先度
                    </label>
                    <select
                      value={formData.priority}
                      onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) })}
                      className="border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value={1}>1（最優先）</option>
                      <option value={2}>2</option>
                      <option value={3}>3</option>
                    </select>
                  </div>

                  <div className="flex items-end">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.is_active}
                        onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                        className="w-4 h-4 text-blue-600 focus:ring-2 focus:ring-blue-500 rounded"
                      />
                      <span className="text-sm font-medium text-gray-700">
                        すぐに表示する
                      </span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors"
                >
                  {editingId ? '更新' : '作成'}
                </button>
                <button
                  type="button"
                  onClick={cancelForm}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-2 rounded-lg transition-colors"
                >
                  キャンセル
                </button>
              </div>
            </form>
          )}

          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : announcements.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Megaphone className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>アナウンスがまだありません</p>
            </div>
          ) : (
            <div className="space-y-3">
              {announcements.map((announcement) => (
                <div
                  key={announcement.id}
                  className={`border rounded-lg p-4 ${
                    announcement.is_active
                      ? 'bg-blue-50 border-blue-200'
                      : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col gap-1">
                      <button
                        onClick={() => handlePriorityChange(announcement.id, -1)}
                        disabled={announcement.priority <= 1}
                        className="p-1 hover:bg-gray-200 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                        title="優先度を上げる"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <span className="text-sm font-semibold text-center">{announcement.priority}</span>
                      <button
                        onClick={() => handlePriorityChange(announcement.id, 1)}
                        disabled={announcement.priority >= 3}
                        className="p-1 hover:bg-gray-200 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                        title="優先度を下げる"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-gray-900">{announcement.title}</h3>
                        {announcement.is_active && (
                          <span className="bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">
                            表示中
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap mb-2">
                        {announcement.body}
                      </p>
                      {announcement.url && (
                        <a
                          href={announcement.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-blue-600 hover:underline"
                        >
                          {announcement.url}
                        </a>
                      )}
                      <div className="text-xs text-gray-500 mt-2">
                        作成: {new Date(announcement.created_at).toLocaleString('ja-JP')}
                      </div>
                    </div>

                    <div className="flex flex-col gap-2">
                      <button
                        onClick={() => handleToggleActive(announcement.id, announcement.is_active)}
                        className={`p-2 rounded-lg transition-colors ${
                          announcement.is_active
                            ? 'bg-green-100 text-green-700 hover:bg-green-200'
                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        }`}
                        title={announcement.is_active ? '非表示にする' : '表示する'}
                      >
                        {announcement.is_active ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
                      </button>

                      <button
                        onClick={() => handleEdit(announcement)}
                        className="p-2 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-lg transition-colors"
                        title="編集"
                      >
                        <Edit2 className="w-5 h-5" />
                      </button>

                      <button
                        onClick={() => handleDelete(announcement.id)}
                        className="p-2 bg-red-100 text-red-700 hover:bg-red-200 rounded-lg transition-colors"
                        title="削除"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

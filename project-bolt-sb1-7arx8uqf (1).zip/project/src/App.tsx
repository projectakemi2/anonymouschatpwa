import { useState, useEffect } from 'react';
import InstallPrompt from './components/InstallPrompt';
import RegisterScreen from './components/RegisterScreen';
import ChatScreen from './components/ChatScreen';
import SafariPrompt from './components/SafariPrompt';
import TrackingLandingPage from './components/TrackingLandingPage';
import { NotificationBanner } from './components/NotificationBanner';
import { isPWAInstalled, isStandalone, markPWAInstalled, needsSafariRedirect } from './lib/device';
import { getCurrentUser, checkIPBlocked, validateCurrentUser } from './lib/user';
import { registerServiceWorker } from './lib/notification';
import { subscribeToPushNotifications } from './lib/push';
import { getCurrentRoomId } from './lib/room';

type AppState = 'safari-redirect' | 'install' | 'register' | 'chat' | 'blocked' | 'tracking';

function App() {
  const [appState, setAppState] = useState<AppState>('register');
  const [loading, setLoading] = useState(true);
  const [campaignId, setCampaignId] = useState<string>('');

  useEffect(() => {
    initializeApp();

    const handleURLChange = () => {
      initializeApp();
    };

    window.addEventListener('hashchange', handleURLChange);
    window.addEventListener('popstate', handleURLChange);

    return () => {
      window.removeEventListener('hashchange', handleURLChange);
      window.removeEventListener('popstate', handleURLChange);
    };
  }, []);

  const initializeApp = async () => {
    setLoading(true);
    try {
      const pathname = window.location.pathname;
      const trackMatch = pathname.match(/^\/track\/(.+)$/);

      if (trackMatch) {
        const id = trackMatch[1];
        setCampaignId(id);

        try {
          await registerServiceWorker();
          console.log('✅ Service Worker registered for tracking');
        } catch (err) {
          console.warn('⚠️ Service Worker registration failed:', err);
        }

        setAppState('tracking');
        setLoading(false);
        return;
      }

      localStorage.removeItem('install_banner_dismissed');

      try {
        await registerServiceWorker();
        console.log('✅ Service Worker registered early');
      } catch (err) {
        console.warn('⚠️ Early Service Worker registration failed:', err);
      }

      if (needsSafariRedirect()) {
        setAppState('safari-redirect');
        setLoading(false);
        return;
      }

      const blocked = await checkIPBlocked();
      if (blocked) {
        setAppState('blocked');
        setLoading(false);
        return;
      }

      const pwaInstalled = isPWAInstalled();
      const standalone = isStandalone();

      if (!pwaInstalled && !standalone) {
        setAppState('install');
        setLoading(false);
        return;
      }

      const user = await validateCurrentUser();

      if (user) {
        try {
          if ('Notification' in window) {
            const permission = await Notification.requestPermission();
            if (permission === 'granted') {
              const roomId = getCurrentRoomId();
              await subscribeToPushNotifications(user.id, roomId);
              console.log('✅ Auto-subscribed to push notifications for room:', roomId);
            }
          }
        } catch (err) {
          console.warn('⚠️ Auto push subscription failed:', err);
        }
        setAppState('chat');
      } else {
        setAppState('register');
      }
    } catch (error) {
      console.error('Initialization error:', error);
      setAppState('register');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">読み込み中...</p>
        </div>
      </div>
    );
  }

  if (appState === 'safari-redirect') {
    return <SafariPrompt />;
  }

  if (appState === 'blocked') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
          <div className="inline-block p-4 bg-red-100 rounded-full mb-4">
            <svg
              className="w-12 h-12 text-red-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"
              />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">アクセスがブロックされています</h1>
          <p className="text-gray-600">
            このIPアドレスは管理者によってブロックされています。
            <br />
            アクセスできません。
          </p>
        </div>
      </div>
    );
  }

  if (appState === 'install') {
    return (
      <InstallPrompt
        onComplete={async () => {
          markPWAInstalled();
          const user = await validateCurrentUser();
          try {
            await registerServiceWorker();
          } catch (err) {
            console.warn('Service Worker setup failed:', err);
          }

          if (user) {
            setAppState('chat');
          } else {
            setAppState('register');
          }
        }}
      />
    );
  }

  if (appState === 'tracking') {
    return <TrackingLandingPage campaignId={campaignId} />;
  }

  if (appState === 'register') {
    const roomId = getCurrentRoomId();
    return (
      <>
        <NotificationBanner />
        <RegisterScreen onRegistered={() => setAppState('chat')} roomId={roomId} />
      </>
    );
  }

  return (
    <>
      <NotificationBanner />
      <ChatScreen />
    </>
  );
}

export default App;

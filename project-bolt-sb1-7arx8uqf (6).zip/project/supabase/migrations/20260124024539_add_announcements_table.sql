/*
  # アナウンス機能の追加

  1. 新しいテーブル
    - `announcements`
      - `id` (uuid, primary key)
      - `title` (text) - アナウンスのタイトル
      - `body` (text) - アナウンスの本文
      - `url` (text, nullable) - 外部リンク（任意）
      - `is_active` (boolean) - 表示ON/OFF
      - `priority` (integer) - 表示順序（1-3）
      - `created_by` (uuid) - 作成した管理者のID
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. セキュリティ
    - RLSを有効化
    - 全ユーザーが閲覧可能（is_active=trueのみ）
    - 管理者のみ作成・更新・削除可能
    - 自動更新されるupdated_atトリガーを追加

  3. 制約
    - priority は 1-3 の範囲
    - title と body は必須
    - created_by は anonymous_users を参照
*/

-- Create announcements table
CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL CHECK (char_length(title) <= 200),
  body text NOT NULL CHECK (char_length(body) <= 2000),
  url text,
  is_active boolean DEFAULT false,
  priority integer DEFAULT 1 CHECK (priority >= 1 AND priority <= 3),
  created_by uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index for efficient querying
CREATE INDEX IF NOT EXISTS idx_announcements_active_priority 
ON announcements(is_active, priority) 
WHERE is_active = true;

-- Create updated_at trigger function if not exists
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add trigger for updated_at
DROP TRIGGER IF EXISTS set_updated_at ON announcements;
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON announcements
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

-- Policy: Everyone can view active announcements
CREATE POLICY "Anyone can view active announcements"
  ON announcements
  FOR SELECT
  USING (is_active = true);

-- Policy: Admins can view all announcements
CREATE POLICY "Admins can view all announcements"
  ON announcements
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = auth.uid()
      AND anonymous_users.is_admin = true
    )
  );

-- Policy: Admins can insert announcements
CREATE POLICY "Admins can create announcements"
  ON announcements
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = created_by
      AND anonymous_users.is_admin = true
      AND anonymous_users.id = auth.uid()
    )
  );

-- Policy: Admins can update announcements
CREATE POLICY "Admins can update announcements"
  ON announcements
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = auth.uid()
      AND anonymous_users.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = auth.uid()
      AND anonymous_users.is_admin = true
    )
  );

-- Policy: Admins can delete announcements
CREATE POLICY "Admins can delete announcements"
  ON announcements
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.id = auth.uid()
      AND anonymous_users.is_admin = true
    )
  );
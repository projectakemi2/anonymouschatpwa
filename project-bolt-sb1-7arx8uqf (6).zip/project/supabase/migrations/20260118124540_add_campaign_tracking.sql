/*
  # キャンペーン追跡機能の追加

  1. 変更内容
    - `push_subscriptions`テーブルに`campaign_id`カラムを追加
    - キャンペーンごとに購読者を追跡できるようにする
    - 一斉通知送信時にキャンペーンIDでフィルタリング可能に

  2. セキュリティ
    - 既存のRLSポリシーがそのまま適用される
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'push_subscriptions' AND column_name = 'campaign_id'
  ) THEN
    ALTER TABLE push_subscriptions 
    ADD COLUMN campaign_id text,
    ADD COLUMN subscribed_at timestamptz;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_push_subscriptions_campaign_id 
ON push_subscriptions(campaign_id);

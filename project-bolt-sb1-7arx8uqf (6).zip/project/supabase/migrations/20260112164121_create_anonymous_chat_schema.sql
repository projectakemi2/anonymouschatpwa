/*
  # Anonymous Chat Application Schema

  ## Overview
  Complete database schema for anonymous chat PWA with IP-based moderation

  ## New Tables
  
  ### `anonymous_users`
  - `id` (uuid, primary key) - User identifier
  - `device_id` (text, unique) - Device fingerprint for anonymous users
  - `display_name` (text) - User's chosen display name
  - `ip_address` (text) - Current IP address
  - `is_admin` (boolean) - Admin flag
  - `created_at` (timestamptz) - Registration timestamp
  - `last_seen_at` (timestamptz) - Last activity timestamp
  
  ### `messages`
  - `id` (uuid, primary key) - Message identifier
  - `user_id` (uuid, foreign key) - Reference to anonymous_users
  - `content` (text) - Message content (max 10,000 chars)
  - `images` (jsonb) - Array of image URLs (max 4)
  - `ip_address` (text) - Sender's IP address
  - `created_at` (timestamptz) - Message timestamp
  - `deleted_at` (timestamptz) - Soft delete timestamp
  - `deleted_by` (uuid) - Admin who deleted the message
  
  ### `ip_blocks`
  - `id` (uuid, primary key) - Block record identifier
  - `ip_address` (text, unique) - Blocked IP address
  - `blocked_by` (uuid, foreign key) - Admin who blocked
  - `reason` (text) - Block reason
  - `created_at` (timestamptz) - Block timestamp
  
  ### `audit_logs`
  - `id` (uuid, primary key) - Log entry identifier
  - `admin_id` (uuid, foreign key) - Admin who performed action
  - `action_type` (text) - Action type (block_ip, delete_message, promote_admin, etc.)
  - `target_user_id` (uuid) - Target user
  - `target_ip` (text) - Target IP
  - `details` (jsonb) - Additional details
  - `created_at` (timestamptz) - Action timestamp
  
  ### `rate_limits`
  - `id` (uuid, primary key) - Rate limit entry identifier
  - `user_id` (uuid) - User identifier
  - `last_message_at` (timestamptz) - Last message timestamp
  - `created_at` (timestamptz) - Entry creation timestamp
  
  ## Security
  - Enable RLS on all tables
  - Anonymous users can read messages and create their own
  - Admins have full access
  - IP blocks prevent any access
  - Audit logs are read-only for non-admins
*/

-- Create anonymous_users table
CREATE TABLE IF NOT EXISTS anonymous_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  display_name text NOT NULL,
  ip_address text NOT NULL,
  is_admin boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  last_seen_at timestamptz DEFAULT now()
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (char_length(content) <= 10000),
  images jsonb DEFAULT '[]'::jsonb,
  ip_address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  deleted_at timestamptz,
  deleted_by uuid REFERENCES anonymous_users(id)
);

-- Create ip_blocks table
CREATE TABLE IF NOT EXISTS ip_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address text UNIQUE NOT NULL,
  blocked_by uuid NOT NULL REFERENCES anonymous_users(id),
  reason text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create audit_logs table
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES anonymous_users(id),
  action_type text NOT NULL,
  target_user_id uuid REFERENCES anonymous_users(id),
  target_ip text,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create rate_limits table
CREATE TABLE IF NOT EXISTS rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES anonymous_users(id) ON DELETE CASCADE,
  last_message_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_deleted_at ON messages(deleted_at);
CREATE INDEX IF NOT EXISTS idx_ip_blocks_ip_address ON ip_blocks(ip_address);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_anonymous_users_device_id ON anonymous_users(device_id);

-- Enable Row Level Security
ALTER TABLE anonymous_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE ip_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE rate_limits ENABLE ROW LEVEL SECURITY;

-- RLS Policies for anonymous_users
CREATE POLICY "Anyone can view users"
  ON anonymous_users FOR SELECT
  USING (true);

CREATE POLICY "Users can insert themselves"
  ON anonymous_users FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update their own data"
  ON anonymous_users FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Admins can delete users"
  ON anonymous_users FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users au
      WHERE au.id = anonymous_users.id AND au.is_admin = true
    )
  );

-- RLS Policies for messages
CREATE POLICY "Anyone can view non-deleted messages"
  ON messages FOR SELECT
  USING (deleted_at IS NULL);

CREATE POLICY "Users can insert messages"
  ON messages FOR INSERT
  WITH CHECK (
    NOT EXISTS (
      SELECT 1 FROM ip_blocks
      WHERE ip_blocks.ip_address = messages.ip_address
    )
  );

CREATE POLICY "Admins can delete messages"
  ON messages FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true
    )
  );

-- RLS Policies for ip_blocks
CREATE POLICY "Anyone can view IP blocks"
  ON ip_blocks FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert IP blocks"
  ON ip_blocks FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true
    )
  );

CREATE POLICY "Admins can delete IP blocks"
  ON ip_blocks FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true
    )
  );

-- RLS Policies for audit_logs
CREATE POLICY "Anyone can view audit logs"
  ON audit_logs FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert audit logs"
  ON audit_logs FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM anonymous_users
      WHERE anonymous_users.is_admin = true AND anonymous_users.id = audit_logs.admin_id
    )
  );

-- RLS Policies for rate_limits
CREATE POLICY "Anyone can view rate limits"
  ON rate_limits FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert rate limits"
  ON rate_limits FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update rate limits"
  ON rate_limits FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- Enable Realtime for messages table
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE anonymous_users;
ALTER PUBLICATION supabase_realtime ADD TABLE ip_blocks;
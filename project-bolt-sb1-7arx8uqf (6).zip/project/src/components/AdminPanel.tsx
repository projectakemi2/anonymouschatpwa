import { useState, useEffect } from 'react';
import {
  X,
  Shield,
  Ban,
  Trash2,
  UserPlus,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
  Download,
  Database,
  Bell,
  Mail
} from 'lucide-react';
import { AnonymousUser } from '../lib/user';
import {
  getAllUsers,
  getIPBlocks,
  getDeviceBlocks,
  getAuditLogs,
  blockUserByIP,
  blockUserByDeviceId,
  blockByDisplayName,
  unblockIP,
  unblockDevice,
  promoteToAdmin,
  cleanupOldAuditLogs,
  cleanupOldRateLimits,
  blockDisplayName,
  unblockDisplayName,
  getBlockedDisplayNames,
  toggleDirectMessagePermission
} from '../lib/admin';
import { deleteMessage, deleteMessages, getAllMessages, subscribeToMessages, Message } from '../lib/messages';
import { supabase } from '../lib/supabase';
import { removeNotificationByMessageId, removeNotificationsByMessageIds } from '../lib/notification';
import InstallBanner from './InstallBanner';
import DeviceAnalyticsDashboard from './DeviceAnalyticsDashboard';
import NotificationAnalytics from './NotificationAnalytics';
import { exportAllProjectData, downloadJSON, generateExportFilename } from '../lib/export';
import { downloadCompleteProjectZip } from '../lib/project-export';
import { sendBroadcastNotification } from '../lib/broadcast';
import { getCampaigns, sendCampaignNotification, Campaign } from '../lib/campaigns';
import AnnouncementManager from './AnnouncementManager';
import { DirectMessagesModal } from './DirectMessagesModal';

interface AdminPanelProps {
  onClose: () => void;
  currentUser: AnonymousUser;
  roomId: string;
}

type TabType = 'users' | 'blocks' | 'messages' | 'logs' | 'analytics' | 'export' | 'campaigns' | 'notification-analytics' | 'announcements' | 'direct-messages';

export default function AdminPanel({ onClose, currentUser, roomId }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<TabType>('campaigns');
  const [users, setUsers] = useState<any[]>([]);
  const [ipBlocks, setIpBlocks] = useState<any[]>([]);
  const [deviceBlocks, setDeviceBlocks] = useState<any[]>([]);
  const [blockedDisplayNames, setBlockedDisplayNames] = useState<any[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [selectedMessages, setSelectedMessages] = useState<Set<string>>(new Set());
  const [exportLoading, setExportLoading] = useState(false);
  const [projectExportLoading, setProjectExportLoading] = useState(false);
  const [notificationLoading, setNotificationLoading] = useState(false);
  const [campaignNotificationLoading, setCampaignNotificationLoading] = useState<string | null>(null);
  const [pushSubscribersCount, setPushSubscribersCount] = useState(0);
  const [userSearchQuery, setUserSearchQuery] = useState('');

  useEffect(() => {
    loadData();
    setSelectedMessages(new Set());

    if (activeTab === 'messages') {
      const channel = supabase
        .channel('admin_messages_channel')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'messages'
          },
          () => {
            loadData();
          }
        )
        .subscribe();

      return () => {
        channel.unsubscribe();
      };
    } else if (activeTab === 'blocks') {
      const ipChannel = supabase
        .channel('ip_blocks_channel')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'ip_blocks'
          },
          () => {
            loadData();
          }
        )
        .subscribe();

      const deviceChannel = supabase
        .channel('device_blocks_channel')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'device_blocks'
          },
          () => {
            loadData();
          }
        )
        .subscribe();

      return () => {
        ipChannel.unsubscribe();
        deviceChannel.unsubscribe();
      };
    }
  }, [activeTab]);

  const loadData = async () => {
    setLoading(true);
    setError('');

    try {
      if (activeTab === 'users') {
        const data = await getAllUsers(roomId);
        setUsers(data);
      } else if (activeTab === 'blocks') {
        const [ipData, deviceData, nameData] = await Promise.all([
          getIPBlocks(),
          getDeviceBlocks(),
          getBlockedDisplayNames()
        ]);
        setIpBlocks(ipData);
        setDeviceBlocks(deviceData);
        setBlockedDisplayNames(nameData);
      } else if (activeTab === 'messages') {
        const data = await getAllMessages(200);
        setMessages(data);
      } else if (activeTab === 'logs') {
        const data = await getAuditLogs();
        setAuditLogs(data);
      } else if (activeTab === 'campaigns') {
        const [campaignsData, pushCountResult] = await Promise.all([
          getCampaigns(),
          supabase.from('push_subscriptions').select('user_id', { count: 'exact', head: true }).eq('room_id', roomId)
        ]);
        setCampaigns(campaignsData);
        setPushSubscribersCount(pushCountResult.count || 0);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleBlockUserByIP = async (userId: string, ipAddress: string, displayName: string) => {
    if (!confirm(`${displayName} をIPアドレスでブロックしますか？`)) {
      return;
    }

    try {
      await blockUserByIP(ipAddress, currentUser.id, `ユーザー ${displayName} をブロック`);
      setSuccess('ユーザーをIPアドレスでブロックしました');
      setActiveTab('blocks');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleBlockUserByDevice = async (userId: string, deviceId: string, displayName: string) => {
    if (!confirm(`${displayName} をデバイスIDでブロックしますか？`)) {
      return;
    }

    try {
      await blockUserByDeviceId(deviceId, currentUser.id, `ユーザー ${displayName} をブロック`);
      setSuccess('ユーザーをデバイスIDでブロックしました');
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleUnblockIP = async (ipAddress: string) => {
    if (!confirm(`${ipAddress} のブロックを解除しますか？`)) {
      return;
    }

    try {
      await unblockIP(ipAddress, currentUser.id);
      setSuccess('IPブロックを解除しました');
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleUnblockDevice = async (deviceId: string) => {
    if (!confirm(`${deviceId} のブロックを解除しますか？`)) {
      return;
    }

    try {
      await unblockDevice(deviceId, currentUser.id);
      setSuccess('デバイスブロックを解除しました');
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleUnblockDisplayName = async (displayName: string) => {
    if (!confirm(`「${displayName}」のブロックを解除しますか？`)) {
      return;
    }

    try {
      await unblockDisplayName(displayName, currentUser.id);
      setSuccess('名前ブロックを解除しました');
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handlePromoteUser = async (userId: string, displayName: string) => {
    if (!confirm(`${displayName} を管理者に昇格しますか？`)) {
      return;
    }

    try {
      await promoteToAdmin(userId, currentUser.id);
      setSuccess('管理者に昇格しました');
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleToggleDMPermission = async (userId: string, currentAllowed: boolean, displayName: string) => {
    const action = currentAllowed ? '無効化' : '有効化';
    if (!confirm(`${displayName} の個別メール受信を${action}しますか？`)) {
      return;
    }

    try {
      await toggleDirectMessagePermission(userId, !currentAllowed);
      setSuccess(`個別メール受信を${action}しました`);
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!confirm('このメッセージを削除しますか？')) {
      return;
    }

    try {
      await deleteMessage(messageId, currentUser.id);
      setSuccess('メッセージを削除しました');
      await removeNotificationByMessageId(messageId);
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleCleanup = async () => {
    if (!confirm('180日以上前の監査ログと7日以上前のレート制限データを削除しますか？')) {
      return;
    }

    try {
      await Promise.all([
        cleanupOldAuditLogs(),
        cleanupOldRateLimits()
      ]);
      setSuccess('クリーンアップが完了しました');
      loadData();
    } catch (err: any) {
      setError(err.message || 'クリーンアップに失敗しました');
    }
  };

  const toggleMessageSelection = (messageId: string) => {
    setSelectedMessages(prev => {
      const newSet = new Set(prev);
      if (newSet.has(messageId)) {
        newSet.delete(messageId);
      } else {
        newSet.add(messageId);
      }
      return newSet;
    });
  };

  const toggleAllMessages = () => {
    if (selectedMessages.size === messages.length) {
      setSelectedMessages(new Set());
    } else {
      setSelectedMessages(new Set(messages.map(m => m.id)));
    }
  };

  const handleDeleteSelectedMessages = async () => {
    if (selectedMessages.size === 0) {
      setError('削除するメッセージを選択してください');
      return;
    }

    if (!confirm(`選択した${selectedMessages.size}件のメッセージを削除しますか？`)) {
      return;
    }

    try {
      const messageIds = Array.from(selectedMessages);
      await deleteMessages(messageIds, currentUser.id);
      setSuccess(`${selectedMessages.size}件のメッセージを削除しました`);
      await removeNotificationsByMessageIds(messageIds);
      setSelectedMessages(new Set());
      loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleExportAllData = async () => {
    setExportLoading(true);
    setError('');
    setSuccess('');

    try {
      const exportData = await exportAllProjectData();
      const filename = generateExportFilename();
      downloadJSON(exportData, filename);
      setSuccess('すべてのデータをエクスポートしました');
    } catch (err: any) {
      setError(err.message || 'エクスポートに失敗しました');
    } finally {
      setExportLoading(false);
    }
  };

  const handleDownloadCompleteProject = async () => {
    setProjectExportLoading(true);
    setError('');
    setSuccess('');

    try {
      await downloadCompleteProjectZip();
      setSuccess('プロジェクト全体をZIPでダウンロードしました');
    } catch (err: any) {
      setError(err.message || 'プロジェクトのダウンロードに失敗しました');
    } finally {
      setProjectExportLoading(false);
    }
  };

  const handleSendBroadcastNotification = async () => {
    const title = prompt('通知のタイトルを入力してください', '重要なお知らせ');
    if (!title) return;

    const body = prompt('通知の本文を入力してください', 'クリックして詳細を確認してください');
    if (!body) return;

    if (!confirm('全ユーザーに通知を送信しますか？')) {
      return;
    }

    setNotificationLoading(true);
    setError('');
    setSuccess('');

    try {
      const result = await sendBroadcastNotification(title, body, roomId);
      setSuccess(`${result.sent}/${result.total}人に通知を送信しました`);
    } catch (err: any) {
      setError(err.message || '通知の送信に失敗しました');
    } finally {
      setNotificationLoading(false);
    }
  };

  const handleSendCampaignNotification = async (campaignId: string) => {
    const title = prompt('通知のタイトルを入力してください', '重要なお知らせ');
    if (!title) return;

    const body = prompt('通知の本文を入力してください', 'クリックして詳細を確認してください');
    if (!body) return;

    if (!confirm(`キャンペーン ${campaignId} の登録者全員に通知を送信しますか？`)) {
      return;
    }

    setCampaignNotificationLoading(campaignId);
    setError('');
    setSuccess('');

    try {
      const result = await sendCampaignNotification(campaignId, title, body);
      setSuccess(`${result.sent}/${result.total}人に通知を送信しました（失敗: ${result.failed}件）`);
    } catch (err: any) {
      setError(err.message || '通知の送信に失敗しました');
    } finally {
      setCampaignNotificationLoading(null);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <InstallBanner />
      <header className="bg-red-600 text-white px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6" />
            <h1 className="text-xl font-bold">管理画面</h1>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-red-700 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>

        <div className="flex gap-2 overflow-x-auto">
          {[
            { id: 'campaigns', label: '一斉通知' },
            { id: 'direct-messages', label: 'DM受信箱' },
            { id: 'announcements', label: 'アナウンス' },
            { id: 'notification-analytics', label: '通知分析' },
            { id: 'users', label: 'ユーザー' },
            { id: 'blocks', label: 'ブロック' },
            { id: 'messages', label: 'メッセージ' },
            { id: 'logs', label: '監査ログ' },
            { id: 'analytics', label: 'デバイス分析' },
            { id: 'export', label: 'データ抽出' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-white text-red-600'
                  : 'bg-red-700 text-white hover:bg-red-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4">
        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 rounded-xl p-3 flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        {success && (
          <div className="mb-4 bg-green-50 border border-green-200 rounded-xl p-3 flex items-start gap-2">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-green-600">{success}</p>
          </div>
        )}

        {loading ? (
          <div className="text-center py-8 text-gray-500">読み込み中...</div>
        ) : (
          <>
            {activeTab === 'campaigns' && (
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 shadow-lg text-white mb-6">
                  <h2 className="text-3xl font-bold mb-3 flex items-center gap-3">
                    <Bell className="w-10 h-10" />
                    全ユーザーに一斉通知
                  </h2>
                  <div className="bg-white/20 backdrop-blur rounded-xl p-4 mb-4">
                    <div className="text-center">
                      <p className="text-sm text-white/80 mb-1">現在の登録者数</p>
                      <p className="text-5xl font-bold">{pushSubscribersCount}人</p>
                      {pushSubscribersCount === 0 && (
                        <p className="text-xs text-yellow-200 mt-2">⚠ まだ誰も登録していません</p>
                      )}
                    </div>
                  </div>
                  <p className="text-blue-100 mb-6 text-lg">
                    {window.location.origin} にアクセスした全員に、今すぐプッシュ通知を送信できます
                  </p>
                  <button
                    onClick={handleSendBroadcastNotification}
                    disabled={notificationLoading}
                    className="w-full bg-white text-blue-600 rounded-xl py-5 font-bold text-xl hover:bg-blue-50 transition-colors disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-3 shadow-lg"
                  >
                    {notificationLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                        <span>送信中...</span>
                      </>
                    ) : (
                      <>
                        <Bell className="w-7 h-7" />
                        <span>全員に今すぐ通知を送信</span>
                      </>
                    )}
                  </button>
                  {pushSubscribersCount === 0 ? (
                    <div className="mt-4 bg-red-500/20 backdrop-blur rounded-xl p-4 border border-red-300/50">
                      <p className="text-sm text-white font-bold mb-2">❌ 登録者が0人の理由：</p>
                      <ul className="text-sm text-white/90 space-y-1">
                        <li>• 会員がスマホで通知許可を押していない</li>
                        <li>• ブラウザがプッシュ通知に対応していない</li>
                        <li>• HTTPSでアクセスしていない（必須）</li>
                        <li>• Service Workerが起動していない</li>
                      </ul>
                      <p className="text-sm text-yellow-200 mt-3 font-semibold">
                        👉 会員に「通知を許可してください」と伝えて、再度アクセスしてもらってください
                      </p>
                    </div>
                  ) : (
                    <div className="mt-4 bg-white/10 backdrop-blur rounded-xl p-4">
                      <p className="text-sm text-white/90 font-semibold mb-2">通知が届く条件：</p>
                      <ul className="text-sm text-white/80 space-y-1">
                        <li>✅ アプリを閉じていても届く</li>
                        <li>✅ 画面ロック中でも届く</li>
                        <li>✅ スリープ中でも届く</li>
                        <li>✅ バックグラウンドでも届く</li>
                        <li>✅ Android・iPhoneどちらも対応</li>
                      </ul>
                    </div>
                  )}
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Bell className="w-6 h-6 text-purple-600" />
                    キャンペーン別の通知
                  </h3>
                  <p className="text-gray-600 mb-4">
                    特定のURLをクリックした人だけに通知を送信できます
                  </p>

                  <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 mb-6">
                    <h4 className="font-bold text-gray-900 mb-2">トラッキングURLの作成方法</h4>
                    <p className="text-sm text-gray-700 mb-3">
                      以下の形式でURLを作成して共有：
                    </p>
                    <div className="bg-white rounded-lg p-3 font-mono text-sm text-gray-900 break-all">
                      {window.location.origin}/track/【好きなID】
                    </div>
                    <p className="text-xs text-gray-600 mt-2">
                      例: {window.location.origin}/track/campaign001
                    </p>
                  </div>

                  {campaigns.length === 0 ? (
                    <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-xl">
                      まだキャンペーンはありません
                      <br />
                      <span className="text-sm">トラッキングURLを共有して登録者を集めましょう</span>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {campaigns.map((campaign) => (
                        <div key={campaign.id} className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-5 border border-blue-200">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="text-lg font-bold text-gray-900 mb-1">
                                {campaign.id}
                              </h3>
                              <p className="text-sm text-gray-600">
                                登録者数: <span className="font-bold text-blue-600">{campaign.subscriber_count}人</span>
                              </p>
                              <div className="mt-2 bg-white rounded-lg p-2 font-mono text-xs text-gray-700 break-all">
                                {window.location.origin}/track/{campaign.id}
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => handleSendCampaignNotification(campaign.id)}
                            disabled={campaignNotificationLoading === campaign.id}
                            className="w-full bg-blue-600 text-white rounded-lg py-3 font-bold hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                          >
                            {campaignNotificationLoading === campaign.id ? (
                              <>
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                                <span>送信中...</span>
                              </>
                            ) : (
                              <>
                                <Bell className="w-5 h-5" />
                                <span>この{campaign.subscriber_count}人に一斉通知を送信</span>
                              </>
                            )}
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-bold text-yellow-900 mb-1">通知の仕組み</h3>
                      <ul className="text-sm text-yellow-800 space-y-1">
                        <li>1. トラッキングURLを作成して共有</li>
                        <li>2. URLをクリックした人が自動的に登録される</li>
                        <li>3. この画面から一斉通知ボタンを押す</li>
                        <li>4. 登録者全員のスマホに通知が届く</li>
                        <li className="font-bold mt-2">✅ アプリ閉じてても、ロック画面でも届きます</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-3">
                <div className="bg-gradient-to-r from-green-600 to-teal-600 rounded-xl p-6 shadow-lg text-white mb-4">
                  <h2 className="text-2xl font-bold mb-3">登録ユーザー一覧</h2>
                  <div className="bg-white/20 backdrop-blur rounded-xl p-4">
                    <div className="text-center">
                      <p className="text-sm text-white/80 mb-1">総登録ユーザー数（永久保存）</p>
                      <p className="text-5xl font-bold">{users.length}人</p>
                      <p className="text-xs text-white/70 mt-2">※ログアウト後もデータベースに保存されます</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <input
                    type="text"
                    placeholder="ユーザー名で検索..."
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                {users
                  .filter(user =>
                    userSearchQuery === '' ||
                    user.display_name.toLowerCase().includes(userSearchQuery.toLowerCase())
                  )
                  .map((user) => (
                  <div key={user.id} className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900">{user.display_name}</h3>
                          {user.is_admin && <Shield className="w-4 h-4 text-red-500" />}
                          {user.is_pwa && (
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">
                              PWA
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 font-mono">IP: {user.ip_address}</p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-gray-500 font-mono">Device: {user.device_id}</p>
                          {user.device_id.startsWith('temp_') && (
                            <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded">
                              一時的
                            </span>
                          )}
                        </div>
                        {user.platform && (
                          <p className="text-xs text-gray-600 mt-1">
                            <span className="font-semibold">端末:</span> {user.platform} {user.os_version}
                          </p>
                        )}
                        {user.browser && (
                          <p className="text-xs text-gray-600">
                            <span className="font-semibold">ブラウザ:</span> {user.browser} {user.browser_version}
                          </p>
                        )}
                        {user.user_agent && (
                          <details className="mt-1">
                            <summary className="text-xs text-blue-600 cursor-pointer hover:text-blue-800">
                              UserAgent詳細を表示
                            </summary>
                            <p className="text-xs text-gray-500 font-mono mt-1 break-all bg-gray-50 p-2 rounded">
                              {user.user_agent}
                            </p>
                          </details>
                        )}
                        <p className="text-xs text-gray-400 mt-1">
                          登録日時: {new Date(user.created_at).toLocaleString('ja-JP')}
                        </p>
                        <p className="text-xs text-gray-400">
                          最終アクセス: {new Date(user.last_seen_at).toLocaleString('ja-JP')}
                        </p>
                      </div>

                      <div className="flex gap-2">
                        {user.is_admin ? (
                          <button
                            onClick={() => handleToggleDMPermission(user.id, user.allow_direct_messages, user.display_name)}
                            className={`px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
                              user.allow_direct_messages
                                ? 'bg-green-100 text-green-700 hover:bg-green-200'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                            title="個別メール受信の許可設定"
                          >
                            <Mail className="w-4 h-4" />
                            <span className="text-xs font-medium">
                              {user.allow_direct_messages ? 'DM受信中' : 'DM無効'}
                            </span>
                          </button>
                        ) : (
                          <>
                            <button
                              onClick={() => handlePromoteUser(user.id, user.display_name)}
                              className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
                              title="管理者に昇格"
                            >
                              <UserPlus className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() =>
                                handleBlockUserByIP(user.id, user.ip_address, user.display_name)
                              }
                              className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                              title="IPでブロック"
                            >
                              <Ban className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() =>
                                handleBlockUserByDevice(user.id, user.device_id, user.display_name)
                              }
                              disabled={user.device_id.startsWith('temp_')}
                              className={`p-2 rounded-lg transition-colors ${
                                user.device_id.startsWith('temp_')
                                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                  : 'bg-orange-100 text-orange-600 hover:bg-orange-200'
                              }`}
                              title={
                                user.device_id.startsWith('temp_')
                                  ? '一時的なデバイスIDはブロックできません'
                                  : 'デバイスでブロック'
                              }
                            >
                              <Ban className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'blocks' && (
              <div className="space-y-4">
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h2 className="text-lg font-bold text-gray-900 mb-3">名前を禁止リストに追加</h2>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="禁止する名前を入力..."
                      id="blockNameInput"
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                    <button
                      onClick={async () => {
                        const input = document.getElementById('blockNameInput') as HTMLInputElement;
                        const displayName = input?.value.trim();
                        if (!displayName) {
                          setError('名前を入力してください');
                          return;
                        }

                        if (!confirm(`「${displayName}」という名前を禁止しますか？今後この名前では誰も入室できなくなります。`)) {
                          return;
                        }

                        try {
                          setLoading(true);
                          await blockDisplayName(displayName, currentUser.id, '名前による入室禁止');
                          setSuccess(`「${displayName}」を禁止リストに追加しました`);
                          input.value = '';
                          loadData();
                        } catch (err: any) {
                          setError(err.message);
                        } finally {
                          setLoading(false);
                        }
                      }}
                      className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
                    >
                      禁止
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    この名前を禁止リストに追加します。今後誰もこの名前で入室できなくなります。
                  </p>
                </div>

                <div>
                  <h2 className="text-lg font-bold text-gray-900 mb-3">禁止された名前</h2>
                  <div className="space-y-3">
                    {blockedDisplayNames.length === 0 ? (
                      <div className="text-center py-4 text-gray-500 bg-white rounded-xl">
                        禁止された名前はありません
                      </div>
                    ) : (
                      blockedDisplayNames.map((block) => (
                        <div key={block.id} className="bg-white rounded-xl p-4 shadow-sm">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="text-sm text-gray-900 font-semibold">
                                  {block.display_name}
                                </p>
                                <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded">
                                  禁止名
                                </span>
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                ブロック者:{' '}
                                {Array.isArray(block.blocker)
                                  ? block.blocker[0]?.display_name
                                  : block.blocker?.display_name}
                              </p>
                              <p className="text-xs text-gray-400">
                                {new Date(block.created_at).toLocaleString('ja-JP')}
                              </p>
                              {block.reason && (
                                <p className="text-xs text-gray-600 mt-1">理由: {block.reason}</p>
                              )}
                            </div>

                            <button
                              onClick={() => handleUnblockDisplayName(block.display_name)}
                              className="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition-colors flex-shrink-0"
                              title="ブロック解除"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-bold text-gray-900 mb-3">IPブロック</h2>
                  <div className="space-y-3">
                    {ipBlocks.length === 0 ? (
                      <div className="text-center py-4 text-gray-500 bg-white rounded-xl">
                        ブロックされたIPはありません
                      </div>
                    ) : (
                      ipBlocks.map((block) => (
                        <div key={block.id} className="bg-white rounded-xl p-4 shadow-sm">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-mono text-sm text-gray-900 font-semibold">
                                  {block.ip_address}
                                </p>
                                <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded">
                                  IP
                                </span>
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                ブロック者:{' '}
                                {Array.isArray(block.blocker)
                                  ? block.blocker[0]?.display_name
                                  : block.blocker?.display_name}
                              </p>
                              <p className="text-xs text-gray-400">
                                {new Date(block.created_at).toLocaleString('ja-JP')}
                              </p>
                              {block.reason && (
                                <p className="text-xs text-gray-600 mt-1">理由: {block.reason}</p>
                              )}
                            </div>

                            <button
                              onClick={() => handleUnblockIP(block.ip_address)}
                              className="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition-colors"
                              title="ブロック解除"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-bold text-gray-900 mb-3">デバイスブロック</h2>
                  <div className="space-y-3">
                    {deviceBlocks.length === 0 ? (
                      <div className="text-center py-4 text-gray-500 bg-white rounded-xl">
                        ブロックされたデバイスはありません
                      </div>
                    ) : (
                      deviceBlocks.map((block) => (
                        <div key={block.id} className="bg-white rounded-xl p-4 shadow-sm">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-mono text-xs text-gray-900 font-semibold break-all">
                                  {block.device_id}
                                </p>
                                <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded whitespace-nowrap">
                                  Device
                                </span>
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                ブロック者:{' '}
                                {Array.isArray(block.blocker)
                                  ? block.blocker[0]?.display_name
                                  : block.blocker?.display_name}
                              </p>
                              <p className="text-xs text-gray-400">
                                {new Date(block.created_at).toLocaleString('ja-JP')}
                              </p>
                              {block.reason && (
                                <p className="text-xs text-gray-600 mt-1">理由: {block.reason}</p>
                              )}
                            </div>

                            <button
                              onClick={() => handleUnblockDevice(block.device_id)}
                              className="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition-colors flex-shrink-0"
                              title="ブロック解除"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'messages' && (
              <div className="space-y-3">
                {messages.length > 0 && currentUser.is_admin && (
                  <div className="bg-white rounded-xl p-4 shadow-sm sticky top-0 z-10">
                    <div className="flex items-center justify-between">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedMessages.size === messages.length && messages.length > 0}
                          onChange={toggleAllMessages}
                          className="w-5 h-5 rounded border-gray-300"
                        />
                        <span className="text-sm font-medium text-gray-700">
                          全て選択 ({selectedMessages.size}/{messages.length})
                        </span>
                      </label>
                      {selectedMessages.size > 0 && (
                        <button
                          onClick={handleDeleteSelectedMessages}
                          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium flex items-center gap-2"
                        >
                          <Trash2 className="w-4 h-4" />
                          選択した{selectedMessages.size}件を削除
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {messages.map((msg) => (
                  <div key={msg.id} className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="flex items-start gap-3">
                      {currentUser.is_admin && (
                        <input
                          type="checkbox"
                          checked={selectedMessages.has(msg.id)}
                          onChange={() => toggleMessageSelection(msg.id)}
                          className="w-5 h-5 rounded border-gray-300 mt-1 flex-shrink-0 cursor-pointer"
                        />
                      )}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-semibold text-gray-900">
                            {msg.user?.display_name}
                          </span>
                          {msg.user?.is_admin && <Shield className="w-3 h-3 text-red-500" />}
                          <span className="text-xs text-gray-400">
                            {new Date(msg.created_at).toLocaleString('ja-JP')}
                          </span>
                        </div>
                        <p className="text-sm text-gray-700 whitespace-pre-wrap break-words">
                          {msg.content}
                        </p>
                        {msg.images && msg.images.length > 0 && (
                          <div className="flex gap-2 mt-2">
                            {msg.images.map((img, idx) => (
                              <img
                                key={idx}
                                src={img}
                                alt=""
                                className="w-16 h-16 object-cover rounded-lg"
                              />
                            ))}
                          </div>
                        )}
                        <p className="text-xs text-gray-400 font-mono mt-1">{msg.ip_address}</p>
                      </div>

                      {currentUser.is_admin && (
                        <button
                          onClick={() => handleDeleteMessage(msg.id)}
                          className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors flex-shrink-0"
                          title="削除"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'logs' && (
              <div className="space-y-3">
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-gray-900 text-sm mb-1">データクリーンアップ</h3>
                      <p className="text-xs text-gray-600">
                        180日以上前の監査ログと7日以上前のレート制限データを削除します
                      </p>
                    </div>
                    <button
                      onClick={handleCleanup}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium whitespace-nowrap ml-4"
                    >
                      クリーンアップ実行
                    </button>
                  </div>
                </div>

                {auditLogs.map((log) => (
                  <div key={log.id} className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="flex items-start gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-semibold text-gray-900">
                            {Array.isArray(log.admin)
                              ? log.admin[0]?.display_name
                              : log.admin?.display_name}
                          </span>
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                            {log.action_type}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500">
                          {new Date(log.created_at).toLocaleString('ja-JP')}
                        </p>
                        {log.target_ip && (
                          <p className="text-xs text-gray-600 mt-1 font-mono">IP: {log.target_ip}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'analytics' && <DeviceAnalyticsDashboard />}

            {activeTab === 'announcements' && (
              <AnnouncementManager
                currentUser={currentUser}
                onClose={() => setActiveTab('campaigns')}
              />
            )}

            {activeTab === 'notification-analytics' && <NotificationAnalytics />}

            {activeTab === 'direct-messages' && (
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-3 bg-purple-100 rounded-full">
                    <Mail className="w-8 h-8 text-purple-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">DM受信箱</h2>
                    <p className="text-gray-600">全ユーザーからのダイレクトメッセージを確認・返信</p>
                  </div>
                </div>
                <DirectMessagesModal
                  isOpen={true}
                  onClose={() => setActiveTab('campaigns')}
                  currentUserId={currentUser.id}
                  currentUserName={currentUser.display_name}
                  isAdmin={true}
                  roomId={roomId}
                />
              </div>
            )}

            {activeTab === 'export' && (
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-8 shadow-lg text-white mb-6">
                  <h2 className="text-3xl font-bold mb-3 flex items-center gap-3">
                    <Download className="w-10 h-10" />
                    プロジェクト全体をダウンロード
                  </h2>
                  <p className="text-purple-100 mb-6 text-lg">
                    すべてのソースコード、データベーススキーマ、ドキュメントをZIPファイルでダウンロードできます
                  </p>
                  <button
                    onClick={handleDownloadCompleteProject}
                    disabled={projectExportLoading}
                    className="w-full bg-white text-purple-600 rounded-xl py-5 font-bold text-xl hover:bg-purple-50 transition-colors disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-3 shadow-lg"
                  >
                    {projectExportLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-purple-600"></div>
                        <span>ダウンロード中...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-7 h-7" />
                        <span>プロジェクト全体をZIPでダウンロード</span>
                      </>
                    )}
                  </button>
                  <div className="mt-4 bg-white/10 backdrop-blur rounded-xl p-4">
                    <p className="text-sm text-white/90 font-semibold mb-2">ZIPファイルに含まれる内容：</p>
                    <ul className="text-sm text-white/80 space-y-1">
                      <li>✅ 完全なソースコード（COMPLETE_SOURCE_CODE.md）</li>
                      <li>✅ データベーススキーマ（DATABASE_SCHEMA.sql）</li>
                      <li>✅ セットアップガイド</li>
                      <li>✅ デプロイガイド</li>
                      <li>✅ API仕様書</li>
                      <li>✅ アーキテクチャドキュメント</li>
                      <li>✅ 環境変数テンプレート（.env.example）</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-start gap-4 mb-6">
                    <div className="p-3 bg-blue-100 rounded-full">
                      <Database className="w-8 h-8 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold text-gray-900 mb-2">
                        データベースデータのエクスポート
                      </h2>
                      <p className="text-gray-600">
                        データベース内のすべてのデータをJSONファイルとしてダウンロードします。
                      </p>
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                    <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      エクスポート内容
                    </h3>
                    <ul className="space-y-2 text-sm text-gray-700">
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 font-bold">•</span>
                        <span><strong>データベース構造:</strong> すべてのテーブルスキーマ、インデックス、RLSポリシー</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 font-bold">•</span>
                        <span><strong>全データ:</strong> ユーザー、メッセージ、ルーム、ブロック、分析データ、監査ログ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 font-bold">•</span>
                        <span><strong>プロジェクト情報:</strong> タイムスタンプ、バージョン、統計情報</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 font-bold">•</span>
                        <span><strong>環境設定:</strong> Supabase URL、アプリURL（機密情報を除く）</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 font-bold">•</span>
                        <span><strong>統計:</strong> 全テーブルのレコード数</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <h3 className="font-bold text-yellow-900 mb-1">注意事項</h3>
                        <ul className="text-sm text-yellow-800 space-y-1">
                          <li>• エクスポートファイルには個人情報が含まれます</li>
                          <li>• ファイルは安全な場所に保管してください</li>
                          <li>• 大量のデータがある場合、処理に時間がかかる場合があります</li>
                          <li>• データベース接続キーは含まれません（セキュリティ保護）</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleExportAllData}
                    disabled={exportLoading}
                    className="w-full bg-blue-600 text-white rounded-xl py-4 font-bold text-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                  >
                    {exportLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>エクスポート中...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-6 h-6" />
                        <span>すべてのデータをエクスポート</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <h3 className="font-bold text-gray-900 mb-3">エクスポートファイルの使用方法</h3>
                  <div className="space-y-3 text-sm text-gray-700">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-semibold mb-2">1. バックアップとして保存</h4>
                      <p className="text-gray-600">
                        定期的にエクスポートして、プロジェクトのバックアップを作成できます。
                      </p>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-semibold mb-2">2. 別のプロジェクトに移行</h4>
                      <p className="text-gray-600">
                        エクスポートしたデータを使用して、新しいSupabaseプロジェクトにデータを移行できます。
                      </p>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-semibold mb-2">3. データ分析</h4>
                      <p className="text-gray-600">
                        JSONファイルを他のツールで開いて、データ分析やレポート作成に使用できます。
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <h3 className="font-bold text-gray-900 mb-3">プロジェクトファイル</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    ソースコードの完全なコピーは以下のファイルを参照してください：
                  </p>
                  <div className="space-y-2">
                    <a
                      href="/COMPLETE_SOURCE_CODE.md"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block bg-gray-50 hover:bg-gray-100 rounded-lg p-3 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-sm text-gray-900">COMPLETE_SOURCE_CODE.md</span>
                        <Download className="w-4 h-4 text-gray-600" />
                      </div>
                      <p className="text-xs text-gray-600 mt-1">すべてのソースコードファイル</p>
                    </a>
                    <a
                      href="/DATABASE_SCHEMA.sql"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block bg-gray-50 hover:bg-gray-100 rounded-lg p-3 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-sm text-gray-900">DATABASE_SCHEMA.sql</span>
                        <Download className="w-4 h-4 text-gray-600" />
                      </div>
                      <p className="text-xs text-gray-600 mt-1">データベーススキーマ定義</p>
                    </a>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

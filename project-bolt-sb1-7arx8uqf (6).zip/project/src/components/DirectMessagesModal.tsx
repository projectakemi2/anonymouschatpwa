import { useState, useEffect, useRef } from 'react';
import { X, Send, ArrowLeft, Image as ImageIcon, X as XIcon, Trash2, Users } from 'lucide-react';
import {
  DirectMessage,
  DMThread,
  getDMThreads,
  getDirectMessages,
  sendDirectMessage,
  markThreadAsRead,
  getAdminUsers,
  subscribeToDirectMessages,
  deleteDirectMessage,
  broadcastToRepliedUsers,
  getUsersWhoReplied,
} from '../lib/direct-messages';
import { linkifyText } from '../lib/text-utils';

interface DirectMessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserId: string;
  currentUserName: string;
  isAdmin: boolean;
  roomId: string | null;
}

export function DirectMessagesModal({
  isOpen,
  onClose,
  currentUserId,
  currentUserName,
  isAdmin,
  roomId,
}: DirectMessagesModalProps) {
  const [view, setView] = useState<'threads' | 'chat' | 'broadcast'>('threads');
  const [threads, setThreads] = useState<DMThread[]>([]);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [selectedThread, setSelectedThread] = useState<DMThread | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [adminUsers, setAdminUsers] = useState<Array<{ id: string; display_name: string }>>([]);
  const [selectedImage, setSelectedImage] = useState<{ url: string; name: string } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [repliedUsersCount, setRepliedUsersCount] = useState(0);
  const [isSendingBroadcast, setIsSendingBroadcast] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      loadThreads();
      if (!isAdmin) {
        loadAdminUsers();
      } else {
        loadRepliedUsersCount();
      }
    }
  }, [isOpen, currentUserId]);

  const loadRepliedUsersCount = async () => {
    if (!isAdmin) return;
    const users = await getUsersWhoReplied(currentUserId);
    setRepliedUsersCount(users.length);
  };

  useEffect(() => {
    if (!isOpen) return;

    const channel = subscribeToDirectMessages(currentUserId, (newMsg) => {
      if (selectedThread &&
          (newMsg.sender_id === selectedThread.user_id || newMsg.recipient_id === selectedThread.user_id)) {
        setMessages(prev => [...prev, newMsg]);
        markThreadAsRead(currentUserId, selectedThread.user_id);
      }
      loadThreads();
    });

    return () => {
      channel.unsubscribe();
    };
  }, [isOpen, currentUserId, selectedThread]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadThreads = async () => {
    const data = await getDMThreads(currentUserId);
    setThreads(data);
  };

  const loadAdminUsers = async () => {
    const data = await getAdminUsers();
    setAdminUsers(data);
  };

  const openThread = async (thread: DMThread) => {
    setSelectedThread(thread);
    const msgs = await getDirectMessages(currentUserId, thread.user_id);
    setMessages(msgs);
    setView('chat');
    await markThreadAsRead(currentUserId, thread.user_id);
    await loadThreads();
  };

  const startNewThreadWithAdmin = async (adminId: string, adminName: string) => {
    const thread: DMThread = {
      user_id: adminId,
      user_name: adminName,
      is_admin: true,
      last_message: '',
      last_message_at: new Date().toISOString(),
      unread_count: 0,
    };
    setSelectedThread(thread);
    const msgs = await getDirectMessages(currentUserId, adminId);
    setMessages(msgs);
    setView('chat');
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('画像ファイルのみアップロード可能です');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('画像サイズは5MB以下にしてください');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage({
        url: event.target?.result as string,
        name: file.name,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!newMessage.trim() && !selectedImage) || !selectedThread) return;

    const message = await sendDirectMessage(
      currentUserId,
      selectedThread.user_id,
      newMessage.trim(),
      roomId,
      selectedImage?.url,
      selectedImage?.name
    );

    if (message) {
      setMessages(prev => [...prev, message]);
      setNewMessage('');
      setSelectedImage(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      await loadThreads();
    }
  };

  const backToThreads = () => {
    setView('threads');
    setSelectedThread(null);
    setMessages([]);
    setNewMessage('');
    setSelectedImage(null);
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!confirm('このメッセージを削除しますか？')) return;

    const success = await deleteDirectMessage(messageId);
    if (success) {
      setMessages(prev => prev.filter(msg => msg.id !== messageId));
      await loadThreads();
    } else {
      alert('メッセージの削除に失敗しました');
    }
  };

  const openBroadcast = () => {
    setView('broadcast');
    setNewMessage('');
    setSelectedImage(null);
  };

  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!newMessage.trim() && !selectedImage) || isSendingBroadcast) return;

    if (!confirm(`返信があった${repliedUsersCount}人に一斉送信しますか？`)) return;

    setIsSendingBroadcast(true);

    const result = await broadcastToRepliedUsers(
      currentUserId,
      newMessage.trim(),
      roomId,
      selectedImage?.url,
      selectedImage?.name
    );

    setIsSendingBroadcast(false);

    if (result.success > 0) {
      alert(`${result.success}人中${result.total}人に送信しました`);
      setNewMessage('');
      setSelectedImage(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      setView('threads');
      await loadThreads();
    } else {
      alert('送信に失敗しました');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files).filter(file => file.type.startsWith('image/'));
    if (files.length === 0) {
      alert('画像ファイルのみアップロード可能です');
      return;
    }

    const file = files[0];

    if (file.size > 5 * 1024 * 1024) {
      alert('画像サイズは5MB以下にしてください');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage({
        url: event.target?.result as string,
        name: file.name,
      });
    };
    reader.readAsDataURL(file);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          {(view === 'chat' || view === 'broadcast') && (
            <button
              onClick={backToThreads}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-xl font-bold flex-1">
            {view === 'threads'
              ? 'ダイレクトメッセージ'
              : view === 'broadcast'
              ? `一斉送信 (${repliedUsersCount}人)`
              : selectedThread?.user_name}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {view === 'threads' ? (
          <div className="flex-1 overflow-y-auto">
            {isAdmin && repliedUsersCount > 0 && (
              <div className="p-4 border-b bg-gradient-to-r from-purple-50 to-blue-50">
                <button
                  onClick={openBroadcast}
                  className="w-full p-4 bg-white hover:bg-blue-50 rounded-lg transition-colors border-2 border-blue-300 shadow-sm"
                >
                  <div className="flex items-center justify-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    <span className="font-bold text-blue-600">
                      返信があったユーザーに一斉送信 ({repliedUsersCount}人)
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    個別メッセージで返信があった全員に同時送信できます
                  </div>
                </button>
              </div>
            )}

            {!isAdmin && adminUsers.length > 0 && (
              <div className="p-4 border-b bg-gray-50">
                <h3 className="text-sm font-semibold text-gray-700 mb-2">管理者に連絡</h3>
                <div className="space-y-2">
                  {adminUsers.map((admin) => (
                    <button
                      key={admin.id}
                      onClick={() => startNewThreadWithAdmin(admin.id, admin.display_name)}
                      className="w-full text-left p-3 bg-white hover:bg-blue-50 rounded-lg transition-colors border border-gray-200"
                    >
                      <div className="font-medium text-blue-600">{admin.display_name}</div>
                      <div className="text-sm text-gray-500">新しいメッセージを送信</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {threads.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <p>メッセージはありません</p>
                {!isAdmin && adminUsers.length > 0 && (
                  <p className="mt-2 text-sm">上の管理者から選択してメッセージを送信できます</p>
                )}
              </div>
            ) : (
              <div className="divide-y">
                {threads.map((thread) => (
                  <button
                    key={thread.user_id}
                    onClick={() => openThread(thread)}
                    className="w-full text-left p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{thread.user_name}</span>
                          {thread.is_admin && (
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">
                              管理者
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 truncate mt-1">{thread.last_message}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(thread.last_message_at).toLocaleString('ja-JP')}
                        </p>
                      </div>
                      {thread.unread_count > 0 && (
                        <span className="ml-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                          {thread.unread_count}
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : view === 'chat' ? (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <p>メッセージを送信して会話を始めましょう</p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isOwnMessage = msg.sender_id === currentUserId;
                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-2 items-end ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg p-3 ${
                          isOwnMessage
                            ? 'bg-blue-500 text-white'
                            : 'bg-white border border-gray-200'
                        }`}
                      >
                        {msg.image_url && (
                          <div className="mb-2">
                            <img
                              src={msg.image_url}
                              alt={msg.image_name || '添付画像'}
                              className="max-w-full rounded-lg max-h-64 object-contain"
                            />
                          </div>
                        )}
                        {msg.content && (
                          <p className="whitespace-pre-wrap break-words">
                            {linkifyText(msg.content).map((part, idx) =>
                              part.type === 'link' ? (
                                <a
                                  key={part.index || idx}
                                  href={part.content}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="underline hover:opacity-80"
                                >
                                  {part.content}
                                </a>
                              ) : (
                                <span key={idx}>{part.content}</span>
                              )
                            )}
                          </p>
                        )}
                        <p
                          className={`text-xs mt-1 ${
                            isOwnMessage ? 'text-blue-100' : 'text-gray-400'
                          }`}
                        >
                          {new Date(msg.created_at).toLocaleTimeString('ja-JP', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                      {isAdmin && (
                        <button
                          onClick={() => handleDeleteMessage(msg.id)}
                          className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors flex-shrink-0"
                          title="メッセージを削除"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            <form
              onSubmit={handleSendMessage}
              className="p-4 border-t bg-white relative"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              {isDragging && (
                <div className="absolute inset-0 bg-blue-500 bg-opacity-20 border-4 border-blue-500 border-dashed rounded-lg z-10 flex items-center justify-center pointer-events-none">
                  <div className="bg-white px-6 py-4 rounded-lg shadow-lg">
                    <p className="text-lg font-bold text-blue-600">画像をドロップして添付</p>
                  </div>
                </div>
              )}
              {selectedImage && (
                <div className="mb-3 relative inline-block">
                  <img
                    src={selectedImage.url}
                    alt={selectedImage.name}
                    className="max-h-32 rounded-lg border border-gray-300"
                  />
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <XIcon className="w-4 h-4" />
                  </button>
                </div>
              )}
              <div className="flex gap-2 items-end">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-shrink-0 p-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                  title="画像を添付"
                >
                  <ImageIcon className="w-5 h-5" />
                </button>
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage(e);
                    }
                  }}
                  placeholder="メッセージを入力... (Shift+Enterで改行)"
                  className="flex-1 min-w-0 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  maxLength={10000}
                  rows={3}
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim() && !selectedImage}
                  className="flex-shrink-0 p-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  title="送信"
                >
                  <Send className="w-5 h-5" />
                  <span className="hidden sm:inline">送信</span>
                </button>
              </div>
            </form>
          </>
        ) : view === 'broadcast' ? (
          <>
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
              <div className="bg-white rounded-lg p-6 border border-gray-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">一斉送信</h3>
                    <p className="text-sm text-gray-600">
                      個別メッセージで返信があった{repliedUsersCount}人に同時送信されます
                    </p>
                  </div>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
                  <p className="text-sm text-blue-800">
                    このメッセージは、あなたに個別メッセージで返信したことがある全てのユーザーに送信されます。
                  </p>
                </div>
              </div>
            </div>

            <form
              onSubmit={handleSendBroadcast}
              className="p-4 border-t bg-white relative"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              {isDragging && (
                <div className="absolute inset-0 bg-blue-500 bg-opacity-20 border-4 border-blue-500 border-dashed rounded-lg z-10 flex items-center justify-center pointer-events-none">
                  <div className="bg-white px-6 py-4 rounded-lg shadow-lg">
                    <p className="text-lg font-bold text-blue-600">画像をドロップして添付</p>
                  </div>
                </div>
              )}
              {selectedImage && (
                <div className="mb-3 relative inline-block">
                  <img
                    src={selectedImage.url}
                    alt={selectedImage.name}
                    className="max-h-32 rounded-lg border border-gray-300"
                  />
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <XIcon className="w-4 h-4" />
                  </button>
                </div>
              )}
              <div className="flex gap-2 items-end">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-shrink-0 p-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                  title="画像を添付"
                >
                  <ImageIcon className="w-5 h-5" />
                </button>
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendBroadcast(e);
                    }
                  }}
                  placeholder="メッセージを入力... (Shift+Enterで改行)"
                  className="flex-1 min-w-0 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  maxLength={10000}
                  rows={3}
                />
                <button
                  type="submit"
                  disabled={(!newMessage.trim() && !selectedImage) || isSendingBroadcast}
                  className="flex-shrink-0 p-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  title="一斉送信"
                >
                  {isSendingBroadcast ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <Users className="w-5 h-5" />
                      <span className="hidden sm:inline">送信</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </>
        ) : null}
      </div>
    </div>
  );
}

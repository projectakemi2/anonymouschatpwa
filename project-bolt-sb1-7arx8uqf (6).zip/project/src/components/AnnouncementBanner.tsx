import { useState, useEffect } from 'react';
import { Megaphone, ExternalLink, ChevronDown, ChevronUp } from 'lucide-react';
import { Announcement, subscribeToAnnouncements } from '../lib/announcements';

function linkifyText(text: string) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts = text.split(urlRegex);

  return parts.map((part, index) => {
    if (part.match(urlRegex)) {
      return (
        <a
          key={index}
          href={part}
          target="_blank"
          rel="noopener noreferrer"
          className="underline hover:opacity-80 text-blue-600 font-medium"
          onClick={(e) => e.stopPropagation()}
        >
          {part}
        </a>
      );
    }
    return part;
  });
}

export default function AnnouncementBanner() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    const unsubscribe = subscribeToAnnouncements((data) => {
      setAnnouncements(data);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const toggleExpand = (id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  if (announcements.length === 0) {
    return null;
  }

  return (
    <div className="sticky top-0 z-40 bg-gradient-to-b from-gray-50 to-white border-b border-gray-200 shadow-sm">
      <div className="max-w-4xl mx-auto px-4 py-2 space-y-1.5">
        {announcements.map((announcement) => {
          const isExpanded = expandedIds.has(announcement.id);

          return (
            <div
              key={announcement.id}
              className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg shadow-sm hover:shadow-md transition-shadow"
            >
              {!isExpanded ? (
                <button
                  onClick={() => toggleExpand(announcement.id)}
                  className="w-full text-left p-2.5 flex items-center gap-2.5 hover:bg-blue-50/50 rounded-lg transition-colors"
                >
                  <div className="flex-shrink-0">
                    <div className="bg-blue-500 text-white p-1.5 rounded-full">
                      <Megaphone className="w-3.5 h-3.5" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0 overflow-hidden">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900 text-xs truncate">
                        {announcement.title}
                      </h3>
                      <span className="text-[10px] text-gray-500 flex-shrink-0">
                        {new Date(announcement.created_at).toLocaleDateString('ja-JP', {
                          month: 'short',
                          day: 'numeric'
                        })}
                      </span>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
                </button>
              ) : (
                <div className="p-3 max-h-[40vh] overflow-y-auto">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-0.5">
                      <div className="bg-blue-500 text-white p-1.5 rounded-full">
                        <Megaphone className="w-4 h-4" />
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900 text-sm">
                          {announcement.title}
                        </h3>
                        <span className="text-xs text-gray-500 flex-shrink-0">
                          {new Date(announcement.created_at).toLocaleDateString('ja-JP', {
                            month: 'short',
                            day: 'numeric'
                          })}
                        </span>
                      </div>

                      <p className="text-sm text-gray-700 whitespace-pre-wrap break-words">
                        {linkifyText(announcement.body)}
                      </p>

                      <div className="flex items-center gap-3 mt-2 sticky bottom-0 bg-gradient-to-t from-blue-50 pt-2">
                        <button
                          onClick={() => toggleExpand(announcement.id)}
                          className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
                        >
                          <ChevronUp className="w-3 h-3" />
                          閉じる
                        </button>

                        {announcement.url && (
                          <a
                            href={announcement.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3" />
                            リンクを開く
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

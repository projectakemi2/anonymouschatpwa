import { supabase } from './supabase';

export interface DirectMessage {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  is_read: boolean;
  room_id: string | null;
  image_url?: string | null;
  image_name?: string | null;
  created_at: string;
  sender?: {
    id: string;
    display_name: string;
    is_admin: boolean;
  };
  recipient?: {
    id: string;
    display_name: string;
    is_admin: boolean;
  };
}

export interface DMThread {
  user_id: string;
  user_name: string;
  is_admin: boolean;
  last_message: string;
  last_message_at: string;
  unread_count: number;
}

export async function sendDirectMessage(
  senderId: string,
  recipientId: string,
  content: string,
  roomId: string | null = null,
  imageUrl?: string | null,
  imageName?: string | null
): Promise<DirectMessage | null> {
  const { data, error } = await supabase
    .from('direct_messages')
    .insert({
      sender_id: senderId,
      recipient_id: recipientId,
      content,
      room_id: roomId,
      image_url: imageUrl,
      image_name: imageName,
    })
    .select(`
      *,
      sender:anonymous_users!direct_messages_sender_id_fkey(id, display_name, is_admin),
      recipient:anonymous_users!direct_messages_recipient_id_fkey(id, display_name, is_admin)
    `)
    .single();

  if (error) {
    console.error('Error sending direct message:', error);
    return null;
  }

  if (data && data.sender) {
    await sendDMPushNotification(
      recipientId,
      data.sender.display_name,
      data.sender.is_admin,
      content,
      data.id
    ).catch((err) => console.error('Failed to send DM push notification:', err));
  }

  return data;
}

async function sendDMPushNotification(
  recipientId: string,
  senderName: string,
  isAdmin: boolean,
  messageContent: string,
  messageId: string
): Promise<void> {
  try {
    const title = isAdmin ? '管理者からのメッセージ' : `${senderName}さんからのメッセージ`;
    const body = messageContent.substring(0, 100) + (messageContent.length > 100 ? '...' : '');

    const { error } = await supabase.functions.invoke('send-push-notification', {
      body: {
        userId: recipientId,
        title,
        body,
        campaignId: `dm:${messageId}`,
      },
    });

    if (error) {
      console.error('Error sending DM push notification:', error);
    }
  } catch (err) {
    console.error('Error in sendDMPushNotification:', err);
  }
}

export async function getDirectMessages(
  userId: string,
  otherUserId: string
): Promise<DirectMessage[]> {
  const { data, error } = await supabase
    .from('direct_messages')
    .select(`
      *,
      sender:anonymous_users!direct_messages_sender_id_fkey(id, display_name, is_admin),
      recipient:anonymous_users!direct_messages_recipient_id_fkey(id, display_name, is_admin)
    `)
    .or(`and(sender_id.eq.${userId},recipient_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},recipient_id.eq.${userId})`)
    .order('created_at', { ascending: true });

  if (error) {
    console.error('Error fetching direct messages:', error);
    return [];
  }

  return data || [];
}

export async function getUnreadCount(userId: string): Promise<number> {
  const { count, error } = await supabase
    .from('direct_messages')
    .select('*', { count: 'exact', head: true })
    .eq('recipient_id', userId)
    .eq('is_read', false);

  if (error) {
    console.error('Error fetching unread count:', error);
    return 0;
  }

  return count || 0;
}

export async function markAsRead(messageId: string): Promise<boolean> {
  const { error } = await supabase
    .from('direct_messages')
    .update({ is_read: true })
    .eq('id', messageId);

  if (error) {
    console.error('Error marking message as read:', error);
    return false;
  }

  return true;
}

export async function markThreadAsRead(
  userId: string,
  otherUserId: string
): Promise<boolean> {
  const { error } = await supabase
    .from('direct_messages')
    .update({ is_read: true })
    .eq('recipient_id', userId)
    .eq('sender_id', otherUserId)
    .eq('is_read', false);

  if (error) {
    console.error('Error marking thread as read:', error);
    return false;
  }

  return true;
}

export async function getDMThreads(userId: string): Promise<DMThread[]> {
  const { data, error } = await supabase
    .from('direct_messages')
    .select(`
      *,
      sender:anonymous_users!direct_messages_sender_id_fkey(id, display_name, is_admin),
      recipient:anonymous_users!direct_messages_recipient_id_fkey(id, display_name, is_admin)
    `)
    .or(`sender_id.eq.${userId},recipient_id.eq.${userId}`)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching DM threads:', error);
    return [];
  }

  const threads = new Map<string, DMThread>();

  for (const msg of data || []) {
    const isReceiver = msg.recipient_id === userId;
    const otherUser = isReceiver ? msg.sender : msg.recipient;
    const otherUserId = isReceiver ? msg.sender_id : msg.recipient_id;

    if (!otherUser) continue;

    const existing = threads.get(otherUserId);

    if (!existing || new Date(msg.created_at) > new Date(existing.last_message_at)) {
      const unreadCount = existing?.unread_count || 0;

      const lastMessagePreview = msg.image_url
        ? (msg.content ? `📷 ${msg.content.substring(0, 40)}${msg.content.length > 40 ? '...' : ''}` : '📷 画像')
        : msg.content.substring(0, 50) + (msg.content.length > 50 ? '...' : '');

      threads.set(otherUserId, {
        user_id: otherUserId,
        user_name: otherUser.display_name,
        is_admin: otherUser.is_admin,
        last_message: lastMessagePreview,
        last_message_at: msg.created_at,
        unread_count: isReceiver && !msg.is_read ? unreadCount + 1 : unreadCount,
      });
    } else if (isReceiver && !msg.is_read) {
      const thread = threads.get(otherUserId)!;
      thread.unread_count += 1;
    }
  }

  return Array.from(threads.values()).sort(
    (a, b) => new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime()
  );
}

export async function getAdminUsers(): Promise<Array<{ id: string; display_name: string }>> {
  const { data, error } = await supabase
    .from('anonymous_users')
    .select('id, display_name')
    .eq('is_admin', true)
    .eq('allow_direct_messages', true)
    .order('display_name');

  if (error) {
    console.error('Error fetching admin users:', error);
    return [];
  }

  return data || [];
}

export function subscribeToDirectMessages(
  userId: string,
  callback: (message: DirectMessage) => void
) {
  const channel = supabase
    .channel('direct_messages_channel')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'direct_messages',
        filter: `recipient_id=eq.${userId}`,
      },
      async (payload) => {
        const { data } = await supabase
          .from('direct_messages')
          .select(`
            *,
            sender:anonymous_users!direct_messages_sender_id_fkey(id, display_name, is_admin),
            recipient:anonymous_users!direct_messages_recipient_id_fkey(id, display_name, is_admin)
          `)
          .eq('id', payload.new.id)
          .single();

        if (data) {
          callback(data);
        }
      }
    )
    .subscribe();

  return channel;
}

export async function getUsersWhoReplied(adminUserId: string): Promise<Array<{ id: string; display_name: string }>> {
  const { data, error } = await supabase
    .from('direct_messages')
    .select(`
      sender_id,
      sender:anonymous_users!direct_messages_sender_id_fkey(id, display_name)
    `)
    .eq('recipient_id', adminUserId)
    .neq('sender_id', adminUserId);

  if (error) {
    console.error('Error fetching users who replied:', error);
    return [];
  }

  const uniqueUsers = new Map<string, { id: string; display_name: string }>();

  for (const msg of data || []) {
    if (msg.sender) {
      uniqueUsers.set(msg.sender_id, {
        id: msg.sender.id,
        display_name: msg.sender.display_name,
      });
    }
  }

  return Array.from(uniqueUsers.values()).sort((a, b) =>
    a.display_name.localeCompare(b.display_name)
  );
}

export async function broadcastToRepliedUsers(
  adminUserId: string,
  content: string,
  roomId: string | null = null,
  imageUrl?: string | null,
  imageName?: string | null
): Promise<{ success: number; total: number }> {
  const users = await getUsersWhoReplied(adminUserId);
  let successCount = 0;

  for (const user of users) {
    const result = await sendDirectMessage(
      adminUserId,
      user.id,
      content,
      roomId,
      imageUrl,
      imageName
    );
    if (result) {
      successCount++;
    }
  }

  return { success: successCount, total: users.length };
}

export async function deleteDirectMessage(messageId: string): Promise<boolean> {
  const { error } = await supabase
    .from('direct_messages')
    .delete()
    .eq('id', messageId);

  if (error) {
    console.error('Error deleting direct message:', error);
    return false;
  }

  return true;
}

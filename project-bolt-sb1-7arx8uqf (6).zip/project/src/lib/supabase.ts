import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: {
    params: {
      eventsPerSecond: 10
    },
    heartbeatIntervalMs: 15000,
    timeout: 20000
  },
  global: {
    headers: {
      'X-Client-Info': 'anonymous-chat-app'
    }
  }
});

export type Database = {
  anonymous_users: {
    id: string;
    device_id: string;
    display_name: string;
    ip_address: string;
    is_admin: boolean;
    created_at: string;
    last_seen_at: string;
  };
  messages: {
    id: string;
    user_id: string;
    content: string;
    images: string[];
    ip_address: string;
    created_at: string;
    deleted_at: string | null;
    deleted_by: string | null;
  };
  ip_blocks: {
    id: string;
    ip_address: string;
    blocked_by: string;
    reason: string;
    created_at: string;
  };
  audit_logs: {
    id: string;
    admin_id: string;
    action_type: string;
    target_user_id: string | null;
    target_ip: string | null;
    details: Record<string, any>;
    created_at: string;
  };
};

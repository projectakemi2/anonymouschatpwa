import { supabase } from './supabase';

const VAPID_PUBLIC_KEY = import.meta.env.VITE_VAPID_PUBLIC_KEY;

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export async function subscribeToPushNotifications(userId: string, roomId: string = 'default'): Promise<boolean> {
  try {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      return false;
    }

    if (!VAPID_PUBLIC_KEY) {
      return false;
    }

    const registration = await navigator.serviceWorker.ready;

    const existingSubscription = await registration.pushManager.getSubscription();
    if (existingSubscription) {
      const subscriptionJSON = existingSubscription.toJSON();

      const { error } = await supabase
        .from('push_subscriptions')
        .upsert({
          user_id: userId,
          room_id: roomId,
          endpoint: existingSubscription.endpoint,
          p256dh: subscriptionJSON.keys?.p256dh || '',
          auth: subscriptionJSON.keys?.auth || '',
          user_agent: navigator.userAgent,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'endpoint'
        });

      if (!error) {
        return true;
      }
    }

    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
    });

    const subscriptionJSON = subscription.toJSON();

    const { error } = await supabase
      .from('push_subscriptions')
      .upsert({
        user_id: userId,
        room_id: roomId,
        endpoint: subscription.endpoint,
        p256dh: subscriptionJSON.keys?.p256dh || '',
        auth: subscriptionJSON.keys?.auth || '',
        user_agent: navigator.userAgent,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'endpoint'
      });

    if (error) {
      return false;
    }

    return true;
  } catch (error) {
    return false;
  }
}

export async function unsubscribeFromPushNotifications(userId: string): Promise<void> {
  try {
    if (!('serviceWorker' in navigator)) {
      return;
    }

    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();

    if (subscription) {
      await subscription.unsubscribe();
    }

    await supabase
      .from('push_subscriptions')
      .delete()
      .eq('user_id', userId);
  } catch (error) {
  }
}

export async function checkPushSubscription(): Promise<boolean> {
  try {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      return false;
    }

    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();

    return subscription !== null;
  } catch (error) {
    return false;
  }
}

export async function syncPushSubscription(userId: string, roomId: string = 'default'): Promise<boolean> {
  try {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      await supabase
        .from('push_subscriptions')
        .delete()
        .eq('user_id', userId);
      return false;
    }

    const registration = await navigator.serviceWorker.ready;
    const browserSubscription = await registration.pushManager.getSubscription();

    if (!browserSubscription) {
      await supabase
        .from('push_subscriptions')
        .delete()
        .eq('user_id', userId);
      return false;
    }

    const { data: dbSubscriptions } = await supabase
      .from('push_subscriptions')
      .select('*')
      .eq('user_id', userId);

    if (!dbSubscriptions || dbSubscriptions.length === 0) {
      const subscriptionJSON = browserSubscription.toJSON();
      const { error } = await supabase
        .from('push_subscriptions')
        .insert({
          user_id: userId,
          room_id: roomId,
          endpoint: browserSubscription.endpoint,
          p256dh: subscriptionJSON.keys?.p256dh || '',
          auth: subscriptionJSON.keys?.auth || '',
          user_agent: navigator.userAgent,
        });

      if (error) {
        return false;
      }
      return true;
    }

    const dbSub = dbSubscriptions[0];
    if (dbSub.endpoint !== browserSubscription.endpoint) {
      const subscriptionJSON = browserSubscription.toJSON();
      await supabase
        .from('push_subscriptions')
        .delete()
        .eq('user_id', userId);

      const { error } = await supabase
        .from('push_subscriptions')
        .insert({
          user_id: userId,
          room_id: roomId,
          endpoint: browserSubscription.endpoint,
          p256dh: subscriptionJSON.keys?.p256dh || '',
          auth: subscriptionJSON.keys?.auth || '',
          user_agent: navigator.userAgent,
        });

      if (error) {
        return false;
      }
      return true;
    }

    return true;
  } catch (error) {
    return false;
  }
}

export async function sendPushNotification(
  messageId: string,
  roomId: string,
  senderId: string,
  senderName: string,
  content: string
): Promise<void> {
  try {
    await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-push-notification`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          message_id: messageId,
          room_id: roomId,
          sender_id: senderId,
          sender_name: senderName,
          content: content,
        }),
      }
    );
  } catch (error) {
  }
}

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import * as api from '../lib/api';
import type { Account, AccountGroup, Conversation, Message } from '../types';
import Header from '../components/Header';
import AccountSidebar from '../components/AccountSidebar';
import ConversationList from '../components/ConversationList';
import ChatView from '../components/ChatView';
import ImportModal from '../components/ImportModal';
import BroadcastModal from '../components/BroadcastModal';
import BroadcastHistory from '../components/BroadcastHistory';
import RedirectLinksModal from '../components/RedirectLinksModal';

function sortConversations(convs: Conversation[]): Conversation[] {
  return [...convs].sort((a, b) => {
    const ua = a.unread_count > 0 ? 1 : 0;
    const ub = b.unread_count > 0 ? 1 : 0;
    if (ub !== ua) return ub - ua;
    const ta = a.last_message_at ? new Date(a.last_message_at).getTime() : 0;
    const tb = b.last_message_at ? new Date(b.last_message_at).getTime() : 0;
    return tb - ta;
  });
}

export default function Dashboard() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [groups, setGroups] = useState<AccountGroup[]>([]);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loadingAccounts, setLoadingAccounts] = useState(true);
  const [loadingConversations, setLoadingConversations] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showBroadcast, setShowBroadcast] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showRedirectLinks, setShowRedirectLinks] = useState(false);
  const [mobilePanel, setMobilePanel] = useState<'sidebar' | 'conversations' | 'chat'>('sidebar');
  const [loadError, setLoadError] = useState<string | null>(null);

  const selectedAccountIdRef = useRef(selectedAccountId);
  const selectedConversationIdRef = useRef(selectedConversationId);

  useEffect(() => {
    selectedAccountIdRef.current = selectedAccountId;
  }, [selectedAccountId]);

  useEffect(() => {
    selectedConversationIdRef.current = selectedConversationId;
  }, [selectedConversationId]);

  const loadGroups = useCallback(async () => {
    try {
      const data = await api.listGroups();
      setGroups(data);
    } catch {
      // ignore
    }
  }, []);

  const loadAccounts = useCallback(async () => {
    setLoadError(null);
    try {
      const data = await api.listAccounts();
      setAccounts(data);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'アカウントの読み込みに失敗しました');
    } finally {
      setLoadingAccounts(false);
    }
  }, []);

  const loadConversations = useCallback(async (accountId: string) => {
    setLoadingConversations(true);
    try {
      const data = await api.listConversations(accountId);
      setConversations(data);
    } catch {
      // ignore
    } finally {
      setLoadingConversations(false);
    }
  }, []);

  const [hasMoreMessages, setHasMoreMessages] = useState(false);

  const loadMessages = useCallback(async (conversationId: string, before?: string) => {
    if (!before) setLoadingMessages(true);
    try {
      const { messages: data, has_more } = await api.listMessages(conversationId, { limit: 50, before });
      if (before) {
        setMessages((prev) => [...data, ...prev]);
      } else {
        setMessages(data);
      }
      setHasMoreMessages(has_more);
      if (!before) {
        setConversations((prev) => {
          const target = prev.find((c) => c.id === conversationId);
          const readCount = target?.unread_count ?? 0;
          if (readCount > 0) {
            setAccounts((prevAccounts) =>
              prevAccounts.map((a) =>
                a.id === target?.account_id
                  ? { ...a, total_unread: Math.max((a.total_unread ?? 0) - readCount, 0) }
                  : a
              )
            );
          }
          return prev.map((c) =>
            c.id === conversationId ? { ...c, unread_count: 0 } : c
          );
        });
        api.markAsRead(conversationId).catch(() => {});
      }
    } catch {
      // ignore
    } finally {
      setLoadingMessages(false);
    }
  }, []);

  useEffect(() => {
    loadAccounts();
    loadGroups();
  }, [loadAccounts, loadGroups]);

  useEffect(() => {
    if (selectedAccountId) {
      loadConversations(selectedAccountId);
      setSelectedConversationId(null);
      setMessages([]);
    }
  }, [selectedAccountId, loadConversations]);

  useEffect(() => {
    if (selectedConversationId) {
      loadMessages(selectedConversationId);
    }
  }, [selectedConversationId, loadMessages]);

  useEffect(() => {
    if (!selectedAccountId) return;

    const msgChannel = supabase
      .channel(`realtime-msgs-${selectedAccountId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `account_id=eq.${selectedAccountId}` },
        (payload) => {
          const newMsg = payload.new as Message;
          if (newMsg.conversation_id === selectedConversationIdRef.current) {
            setMessages((prev) => {
              if (prev.some((m) => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });
          }
          setConversations((prev) => {
            const updated = prev.map((c) =>
              c.id === newMsg.conversation_id
                ? {
                    ...c,
                    last_message_text: newMsg.image_url && !newMsg.text ? '[画像]' : newMsg.text,
                    last_message_at: newMsg.created_at,
                    unread_count:
                      c.id === selectedConversationIdRef.current
                        ? c.unread_count
                        : c.unread_count + 1,
                  }
                : c
            );
            return updated;
          });
          if (newMsg.direction === 'in') {
            const isCurrentConv = newMsg.conversation_id === selectedConversationIdRef.current;
            if (!isCurrentConv) {
              setAccounts((prev) =>
                prev.map((a) =>
                  a.id === newMsg.account_id
                    ? { ...a, total_unread: (a.total_unread ?? 0) + 1 }
                    : a
                )
              );
            }
          }
        }
      )
      .subscribe();

    const convChannel = supabase
      .channel(`realtime-convs-${selectedAccountId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'conversations', filter: `account_id=eq.${selectedAccountId}` },
        (payload) => {
          const conv = payload.new as Conversation;
          setConversations((prev) => {
            if (prev.some((c) => c.id === conv.id)) return prev;
            return [conv, ...prev];
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(msgChannel);
      supabase.removeChannel(convChannel);
    };
  }, [selectedAccountId]);

  const handleSelectAccount = (id: string) => {
    setSelectedAccountId(id);
    setMobilePanel('conversations');
  };

  const handleSelectConversation = (id: string) => {
    setSelectedConversationId(id);
    setMobilePanel('chat');
  };

  const handleMessageSent = (msg: Message) => {
    setMessages((prev) => {
      if (prev.some((m) => m.id === msg.id)) return prev;
      return [...prev, msg];
    });
    setConversations((prev) => {
      const updated = prev.map((c) =>
        c.id === msg.conversation_id
          ? { ...c, last_message_text: msg.text, last_message_at: msg.created_at }
          : c
      );
      return updated;
    });
  };

  const handleDeleteAccount = async (id: string) => {
    try {
      await api.deleteAccount(id);
      setAccounts((prev) => prev.filter((a) => a.id !== id));
      if (selectedAccountId === id) {
        setSelectedAccountId(null);
        setConversations([]);
        setMessages([]);
      }
    } catch {
      alert('アカウントの削除に失敗しました');
    }
  };

  const handleCreateGroup = async (name: string) => {
    try {
      const group = await api.createGroup(name);
      setGroups((prev) => [...prev, group]);
    } catch {
      alert('グループの作成に失敗しました');
    }
  };

  const handleRenameGroup = async (id: string, name: string) => {
    try {
      await api.updateGroup(id, name);
      setGroups((prev) => prev.map((g) => (g.id === id ? { ...g, name } : g)));
    } catch {
      alert('グループ名の変更に失敗しました');
    }
  };

  const handleDeleteGroup = async (id: string) => {
    try {
      await api.deleteGroup(id);
      setGroups((prev) => prev.filter((g) => g.id !== id));
      setAccounts((prev) => prev.map((a) => (a.group_id === id ? { ...a, group_id: null } : a)));
      if (selectedGroupId === id) setSelectedGroupId(null);
    } catch {
      alert('グループの削除に失敗しました');
    }
  };

  const handleAssignGroup = async (accountId: string, groupId: string | null) => {
    try {
      await api.assignAccountGroup(accountId, groupId);
      setAccounts((prev) => prev.map((a) => (a.id === accountId ? { ...a, group_id: groupId } : a)));
    } catch {
      alert('グループの変更に失敗しました');
    }
  };

  const sortedConversations = useMemo(() => sortConversations(conversations), [conversations]);
  const selectedAccount = accounts.find((a) => a.id === selectedAccountId);
  const selectedConversation = sortedConversations.find((c) => c.id === selectedConversationId);

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <Header
        onBroadcast={() => setShowBroadcast(true)}
        onHistory={() => setShowHistory(true)}
        onRedirectLinks={() => setShowRedirectLinks(true)}
        onMenuToggle={() => setMobilePanel('sidebar')}
      />

      <div className="flex-1 flex overflow-hidden">
        <div
          className={`${
            mobilePanel === 'sidebar' ? 'flex' : 'hidden'
          } lg:flex`}
        >
          <AccountSidebar
            accounts={accounts}
            groups={groups}
            selectedId={selectedAccountId}
            selectedGroupId={selectedGroupId}
            onSelect={handleSelectAccount}
            onImport={() => setShowImport(true)}
            onDelete={handleDeleteAccount}
            onCreateGroup={handleCreateGroup}
            onRenameGroup={handleRenameGroup}
            onDeleteGroup={handleDeleteGroup}
            onAssignGroup={handleAssignGroup}
            onSelectGroup={setSelectedGroupId}
            loading={loadingAccounts}
            loadError={loadError}
            onRetry={() => { setLoadingAccounts(true); loadAccounts(); loadGroups(); }}
          />
        </div>

        <div
          className={`${
            mobilePanel === 'conversations' ? 'flex' : 'hidden'
          } md:flex`}
        >
          <ConversationList
            conversations={sortedConversations}
            selectedId={selectedConversationId}
            onSelect={handleSelectConversation}
            loading={loadingConversations}
            accountName={selectedAccount?.display_name || ''}
          />
        </div>

        <div
          className={`flex-1 min-w-0 ${
            mobilePanel === 'chat' ? 'flex' : 'hidden'
          } md:flex`}
        >
          <ChatView
            conversation={selectedConversation || null}
            messages={messages}
            accountId={selectedAccountId}
            accountName={selectedAccount?.display_name || ''}
            loading={loadingMessages}
            hasMore={hasMoreMessages}
            onLoadMore={() => {
              if (selectedConversationId && messages.length > 0) {
                loadMessages(selectedConversationId, messages[0].created_at);
              }
            }}
            onMessageSent={handleMessageSent}
            onBack={() => setMobilePanel('conversations')}
          />
        </div>
      </div>

      {showImport && (
        <ImportModal
          onClose={() => setShowImport(false)}
          onComplete={() => { loadAccounts(); loadGroups(); }}
          groups={groups}
          selectedGroupId={selectedGroupId}
        />
      )}
      {showBroadcast && (
        <BroadcastModal
          onClose={() => setShowBroadcast(false)}
          groups={groups}
          selectedGroupId={selectedGroupId}
        />
      )}
      {showHistory && (
        <BroadcastHistory onClose={() => setShowHistory(false)} />
      )}
      {showRedirectLinks && (
        <RedirectLinksModal
          onClose={() => setShowRedirectLinks(false)}
          accounts={accounts}
          groups={groups}
          selectedGroupId={selectedGroupId}
        />
      )}
    </div>
  );
}

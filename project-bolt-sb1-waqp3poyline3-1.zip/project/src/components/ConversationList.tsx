import { Search, UserCheck, UserX, Users, MessageCircle } from 'lucide-react';
import { useState, useMemo } from 'react';
import type { Conversation } from '../types';

interface ConversationListProps {
  conversations: Conversation[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  loading: boolean;
  accountName: string;
}

function formatTime(dateStr: string | null): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return '今';
  if (mins < 60) return `${mins}分`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}時間`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}日`;
  return d.toLocaleDateString('ja-JP', { month: 'short', day: 'numeric' });
}

export default function ConversationList({
  conversations,
  selectedId,
  onSelect,
  loading,
  accountName,
}: ConversationListProps) {
  const [search, setSearch] = useState('');
  const [unreadOnly, setUnreadOnly] = useState(false);

  const unreadCount = useMemo(
    () => conversations.filter((c) => c.unread_count > 0).length,
    [conversations]
  );

  const filtered = useMemo(() => {
    let list = conversations;
    if (unreadOnly) {
      list = list.filter((c) => c.unread_count > 0);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (c) =>
          (c.line_display_name || '').toLowerCase().includes(q) ||
          c.line_user_id.toLowerCase().includes(q)
      );
    }
    return list;
  }, [conversations, search, unreadOnly]);

  return (
    <div className="w-80 bg-white border-r border-gray-200 flex flex-col shrink-0 h-full">
      <div className="p-3 border-b border-gray-100">
        <div className="flex items-center gap-2 mb-2">
          <Users className="w-4 h-4 text-gray-400" />
          <h3 className="text-sm font-semibold text-gray-900 truncate">
            {accountName || 'アカウントを選択'}
          </h3>
          <span className="text-xs text-gray-400 ml-auto">
            {conversations.length}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ユーザーを検索..."
              className="w-full pl-9 pr-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
          </div>
          <button
            onClick={() => setUnreadOnly((v) => !v)}
            className={`relative shrink-0 p-1.5 rounded-lg border transition-all ${
              unreadOnly
                ? 'bg-emerald-500 border-emerald-500 text-white shadow-sm'
                : 'bg-gray-50 border-gray-200 text-gray-400 hover:text-gray-600 hover:border-gray-300'
            }`}
            title={unreadOnly ? '全て表示' : '未読のみ表示'}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            {!unreadOnly && unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-500 text-white text-[8px] font-bold min-w-[14px] h-[14px] flex items-center justify-center rounded-full px-0.5">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-5 h-5 border-2 border-gray-200 border-t-emerald-500 rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="px-4 py-12 text-center">
            <p className="text-xs text-gray-400">
              {conversations.length === 0
                ? 'まだ会話がありません'
                : unreadOnly
                  ? '未読の会話はありません'
                  : '該当するユーザーがいません'}
            </p>
          </div>
        ) : (
          filtered.map((conv) => (
            <button
              key={conv.id}
              onClick={() => onSelect(conv.id)}
              className={`w-full px-3 py-3 flex items-start gap-3 text-left transition-all border-b border-gray-50 ${
                selectedId === conv.id
                  ? 'bg-emerald-50'
                  : 'hover:bg-gray-50'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                  conv.is_blocked
                    ? 'bg-red-100 text-red-500'
                    : conv.is_active
                      ? 'bg-emerald-100 text-emerald-600'
                      : 'bg-gray-100 text-gray-400'
                }`}
              >
                {conv.is_blocked ? (
                  <UserX className="w-4 h-4" />
                ) : (
                  <UserCheck className="w-4 h-4" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900 truncate">
                    {conv.line_display_name ||
                      `User-${conv.line_user_id.slice(-6)}`}
                  </span>
                  <span className="text-[10px] text-gray-400 shrink-0 ml-2">
                    {formatTime(conv.last_message_at)}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-0.5">
                  <span className="text-xs text-gray-500 truncate">
                    {conv.last_message_text ||
                      (conv.followed_at && !conv.last_message_at
                        ? 'フォローしました'
                        : '')}
                  </span>
                  {conv.unread_count > 0 && (
                    <span className="bg-emerald-500 text-white text-[10px] font-bold min-w-[18px] h-[18px] flex items-center justify-center rounded-full px-1 shrink-0 ml-2">
                      {conv.unread_count}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
}

import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import {
  Send,
  RefreshCw,
  AlertCircle,
  MessageSquare,
  ArrowLeft,
  ImagePlus,
  X,
  Loader,
  Video,
  Paperclip,
} from 'lucide-react';
import type { Message, Conversation } from '../types';
import * as api from '../lib/api';

interface ChatViewProps {
  conversation: Conversation | null;
  messages: Message[];
  accountId: string | null;
  accountName: string;
  loading: boolean;
  hasMore?: boolean;
  onLoadMore?: () => void;
  onMessageSent: (msg: Message) => void;
  onBack?: () => void;
}

function formatTimestamp(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleTimeString('ja-JP', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('ja-JP', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

function groupMessagesByDate(
  messages: Message[]
): Map<string, Message[]> {
  const groups = new Map<string, Message[]>();
  for (const msg of messages) {
    const dateKey = new Date(msg.created_at).toLocaleDateString('ja-JP');
    if (!groups.has(dateKey)) groups.set(dateKey, []);
    groups.get(dateKey)!.push(msg);
  }
  return groups;
}

export default function ChatView({
  conversation,
  messages,
  accountId,
  accountName,
  loading,
  hasMore,
  onLoadMore,
  onMessageSent,
  onBack,
}: ChatViewProps) {
  const [loadingMore, setLoadingMore] = useState(false);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [resending, setResending] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const dragCounterRef = useRef(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const prevConvIdRef = useRef<string | null>(null);

  useEffect(() => {
    if (messages.length === 0) return;
    const isNewConversation = prevConvIdRef.current !== conversation?.id;
    if (isNewConversation && !loading) {
      prevConvIdRef.current = conversation?.id ?? null;
      requestAnimationFrame(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'instant' as ScrollBehavior });
      });
    } else if (!isNewConversation) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, loading, conversation?.id]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height =
        Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [text]);

  const attachImage = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) return;
    setVideoFile(null);
    setVideoPreview(null);
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  }, []);

  const attachVideo = useCallback((file: File) => {
    if (!file.type.startsWith('video/')) return;
    setImageFile(null);
    setImagePreview(null);
    setVideoFile(file);
    setVideoPreview(URL.createObjectURL(file));
  }, []);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    attachImage(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    attachVideo(file);
    if (videoInputRef.current) videoInputRef.current.value = '';
  };

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounterRef.current++;
    if (e.dataTransfer.types.includes('Files')) {
      setDragging(true);
    }
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounterRef.current--;
    if (dragCounterRef.current === 0) {
      setDragging(false);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounterRef.current = 0;
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (file.type.startsWith('video/')) {
        attachVideo(file);
      } else {
        attachImage(file);
      }
    }
  }, [attachImage, attachVideo]);

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const clearVideo = () => {
    if (videoPreview) URL.revokeObjectURL(videoPreview);
    setVideoFile(null);
    setVideoPreview(null);
  };

  const handleSend = async () => {
    if ((!text.trim() && !imageFile && !videoFile) || !accountId || !conversation || sending) return;
    const msgText = text.trim();
    const currentImage = imageFile;
    const currentVideo = videoFile;
    setText('');
    clearImage();
    clearVideo();
    setSending(true);
    try {
      let imageUrl: string | undefined;
      let videoUrl: string | undefined;
      if (currentImage) {
        setUploading(true);
        imageUrl = await api.uploadImage(currentImage);
        setUploading(false);
      }
      if (currentVideo) {
        setUploading(true);
        videoUrl = await api.uploadVideo(currentVideo);
        setUploading(false);
      }
      const { message } = await api.sendMessage(
        accountId,
        conversation.id,
        msgText,
        imageUrl,
        videoUrl
      );
      onMessageSent(message);
    } catch {
      setUploading(false);
      onMessageSent({
        id: crypto.randomUUID(),
        account_id: accountId,
        conversation_id: conversation.id,
        direction: 'out',
        message_type: 'text',
        text: msgText,
        image_url: null,
        video_url: null,
        raw_payload: null,
        event_id: null,
        status: 'failed',
        created_at: new Date().toISOString(),
      });
    } finally {
      setSending(false);
    }
  };

  const handleResend = async (msg: Message) => {
    if (!accountId || !conversation || resending) return;
    setResending(msg.id);
    try {
      const { message } = await api.sendMessage(
        accountId,
        conversation.id,
        msg.text
      );
      onMessageSent(message);
    } catch {
      // keep failed state
    } finally {
      setResending(null);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const dateGroups = useMemo(() => groupMessagesByDate(messages), [messages]);

  if (!conversation) {
    return (
      <div className="flex-1 bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-sm text-gray-400">
            会話を選択してください
          </p>
        </div>
      </div>
    );
  }

  const userName =
    conversation.line_display_name ||
    `User-${conversation.line_user_id.slice(-6)}`;

  return (
    <div
      className="flex-1 min-w-0 bg-gray-50 flex flex-col h-full relative"
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {dragging && (
        <div className="absolute inset-0 z-40 bg-emerald-500/10 backdrop-blur-[2px] border-2 border-dashed border-emerald-400 rounded-lg flex items-center justify-center pointer-events-none">
          <div className="bg-white rounded-xl shadow-lg px-6 py-4 flex items-center gap-3">
            <Paperclip className="w-6 h-6 text-emerald-500" />
            <span className="text-sm font-medium text-gray-700">ファイルをドロップして添付</span>
          </div>
        </div>
      )}
      <div className="h-14 bg-white border-b border-gray-200 flex items-center px-4 shrink-0">
        {onBack && (
          <button
            onClick={onBack}
            className="mr-2 p-1 rounded-lg hover:bg-gray-100 transition-colors md:hidden"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
        )}
        <div className="flex-1 min-w-0">
          <div className="text-sm font-semibold text-gray-900 truncate">
            {userName}
          </div>
          <div className="text-xs text-gray-500 truncate">{accountName}</div>
        </div>
        <div className="flex items-center gap-2">
          {conversation.is_blocked && (
            <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">
              ブロック済
            </span>
          )}
          {conversation.followed_at && (
            <span className="text-xs bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded-full">
              友だち
            </span>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden px-4 py-4">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-5 h-5 border-2 border-gray-200 border-t-emerald-500 rounded-full animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-xs text-gray-400">まだメッセージがありません</p>
          </div>
        ) : (
          <>
          {hasMore && (
            <div className="flex justify-center mb-4">
              <button
                onClick={async () => {
                  if (loadingMore || !onLoadMore) return;
                  setLoadingMore(true);
                  await onLoadMore();
                  setLoadingMore(false);
                }}
                disabled={loadingMore}
                className="text-xs text-gray-500 hover:text-emerald-600 bg-white border border-gray-200 rounded-full px-4 py-1.5 transition-colors disabled:opacity-50"
              >
                {loadingMore ? '読み込み中...' : '過去のメッセージを読み込む'}
              </button>
            </div>
          )}
          {Array.from(dateGroups.entries()).map(([dateKey, msgs]) => (
            <div key={dateKey}>
              <div className="flex items-center justify-center my-4">
                <span className="bg-gray-200/80 text-gray-500 text-[10px] px-3 py-1 rounded-full">
                  {formatDate(msgs[0].created_at)}
                </span>
              </div>
              {msgs.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex mb-2 ${
                    msg.direction === 'out' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[75%] min-w-0 ${
                      msg.direction === 'out' ? 'order-1' : ''
                    }`}
                  >
                    {msg.video_url && (
                      <div className={`mb-1 rounded-2xl overflow-hidden ${
                        msg.direction === 'out'
                          ? msg.status === 'failed'
                            ? 'border border-red-200'
                            : ''
                          : 'border border-gray-100 shadow-sm'
                      }`}>
                        <video
                          src={msg.video_url}
                          controls
                          preload="metadata"
                          className="max-w-full max-h-60 rounded-2xl"
                        />
                      </div>
                    )}
                    {msg.image_url && (
                      <div className={`mb-1 rounded-2xl overflow-hidden ${
                        msg.direction === 'out'
                          ? msg.status === 'failed'
                            ? 'border border-red-200'
                            : ''
                          : 'border border-gray-100 shadow-sm'
                      }`}>
                        <img
                          src={msg.image_url}
                          alt=""
                          className="max-w-full max-h-60 object-contain cursor-pointer"
                          onClick={() => window.open(msg.image_url!, '_blank')}
                        />
                      </div>
                    )}
                    {msg.text && (
                      <div
                        className={`px-3.5 py-2 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap break-words ${
                          msg.direction === 'out'
                            ? msg.status === 'failed'
                              ? 'bg-red-100 text-red-900 border border-red-200'
                              : 'bg-emerald-500 text-white'
                            : 'bg-white text-gray-900 border border-gray-100 shadow-sm'
                        }`}
                      >
                        {msg.text}
                      </div>
                    )}
                    <div
                      className={`flex items-center gap-1.5 mt-0.5 ${
                        msg.direction === 'out'
                          ? 'justify-end'
                          : 'justify-start'
                      }`}
                    >
                      <span className="text-[10px] text-gray-400">
                        {formatTimestamp(msg.created_at)}
                      </span>
                      {msg.status === 'failed' && (
                        <button
                          onClick={() => handleResend(msg)}
                          disabled={resending === msg.id}
                          className="inline-flex items-center gap-0.5 text-[10px] text-red-500 hover:text-red-700 transition-colors"
                        >
                          {resending === msg.id ? (
                            <RefreshCw className="w-3 h-3 animate-spin" />
                          ) : (
                            <>
                              <AlertCircle className="w-3 h-3" />
                              再送
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {!conversation.is_blocked && (
        <div className="bg-white border-t border-gray-200 p-3 shrink-0">
          {imagePreview && (
            <div className="mb-2 relative inline-block">
              <img
                src={imagePreview}
                alt=""
                className="h-20 rounded-lg object-cover border border-gray-200"
              />
              <button
                onClick={clearImage}
                className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-gray-800 text-white rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          {videoPreview && (
            <div className="mb-2 relative inline-block">
              <video
                src={videoPreview}
                className="h-20 rounded-lg border border-gray-200"
              />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-8 h-8 bg-black/50 rounded-full flex items-center justify-center">
                  <Video className="w-4 h-4 text-white" />
                </div>
              </div>
              <button
                onClick={clearVideo}
                className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-gray-800 text-white rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          <div className="flex items-end gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            <input
              ref={videoInputRef}
              type="file"
              accept="video/*"
              onChange={handleVideoSelect}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={sending}
              className="p-2.5 text-gray-500 hover:text-emerald-600 hover:bg-gray-100 rounded-xl transition-colors disabled:opacity-40 shrink-0"
              title="画像を添付"
            >
              <ImagePlus className="w-5 h-5" />
            </button>
            <button
              onClick={() => videoInputRef.current?.click()}
              disabled={sending}
              className="p-2.5 text-gray-500 hover:text-emerald-600 hover:bg-gray-100 rounded-xl transition-colors disabled:opacity-40 shrink-0"
              title="動画を添付"
            >
              <Video className="w-5 h-5" />
            </button>
            <textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="メッセージを入力... (Shift+Enter で改行)"
              rows={1}
              className="flex-1 resize-none border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all max-h-[120px]"
            />
            <button
              onClick={handleSend}
              disabled={(!text.trim() && !imageFile && !videoFile) || sending}
              className="p-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0 shadow-sm"
            >
              {sending ? (
                uploading ? (
                  <Loader className="w-4 h-4 animate-spin" />
                ) : (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                )
              ) : (
                <Send className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

import { Radio, History, Menu, Link2 } from 'lucide-react';

interface HeaderProps {
  onBroadcast: () => void;
  onHistory: () => void;
  onMenuToggle: () => void;
  onRedirectLinks: () => void;
}

export default function Header({
  onBroadcast,
  onHistory,
  onMenuToggle,
  onRedirectLinks,
}: HeaderProps) {
  return (
    <header className="h-14 bg-white border-b border-gray-200 flex items-center justify-between px-4 shrink-0">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuToggle}
          className="lg:hidden p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Menu className="w-5 h-5 text-gray-600" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-emerald-500 rounded-lg flex items-center justify-center">
            <Radio className="w-4 h-4 text-white" />
          </div>
          <span className="font-semibold text-gray-900 text-sm hidden sm:inline">
            LINE Manager
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={onBroadcast}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-xs font-medium transition-colors shadow-sm"
        >
          <Radio className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">一斉配信</span>
        </button>
        <button
          onClick={onRedirectLinks}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-medium transition-colors"
        >
          <Link2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">リダイレクト</span>
        </button>
        <button
          onClick={onHistory}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-medium transition-colors"
        >
          <History className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">配信履歴</span>
        </button>
      </div>
    </header>
  );
}

import { useState, useEffect } from 'react';
import { X, Radio, CheckCircle, AlertCircle, Clock, Loader } from 'lucide-react';
import * as api from '../lib/api';
import type { Broadcast } from '../types';

interface BroadcastHistoryProps {
  onClose: () => void;
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleString('ja-JP', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function StatusBadge({ status }: { status: Broadcast['status'] }) {
  const config = {
    queued: {
      icon: Clock,
      label: '待機中',
      className: 'bg-gray-100 text-gray-600',
    },
    running: {
      icon: Loader,
      label: '送信中',
      className: 'bg-blue-100 text-blue-600',
    },
    done: {
      icon: CheckCircle,
      label: '完了',
      className: 'bg-emerald-100 text-emerald-600',
    },
    failed: {
      icon: AlertCircle,
      label: '失敗',
      className: 'bg-red-100 text-red-600',
    },
  };
  const c = config[status];
  const Icon = c.icon;
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${c.className}`}
    >
      <Icon className={`w-3 h-3 ${status === 'running' ? 'animate-spin' : ''}`} />
      {c.label}
    </span>
  );
}

export default function BroadcastHistory({ onClose }: BroadcastHistoryProps) {
  const [broadcasts, setBroadcasts] = useState<Broadcast[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBroadcasts();
  }, []);

  const loadBroadcasts = async () => {
    try {
      const data = await api.listBroadcasts();
      setBroadcasts(data);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = async (broadcast: Broadcast) => {
    try {
      await api.processBroadcast(broadcast.id);
      loadBroadcasts();
    } catch {
      // ignore
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center">
      <div className="bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl w-full sm:max-w-xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-gray-100 shrink-0">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-500" />
            <h2 className="text-lg font-semibold text-gray-900">
              配信履歴
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-5 h-5 border-2 border-gray-200 border-t-emerald-500 rounded-full animate-spin" />
            </div>
          ) : broadcasts.length === 0 ? (
            <div className="text-center py-12">
              <Radio className="w-10 h-10 text-gray-300 mx-auto mb-2" />
              <p className="text-sm text-gray-400">まだ配信履歴がありません</p>
            </div>
          ) : (
            <div className="space-y-3">
              {broadcasts.map((b) => {
                const progress =
                  b.total_targets > 0
                    ? Math.round(
                        ((b.sent_count + b.failed_count) / b.total_targets) *
                          100
                      )
                    : 0;
                return (
                  <div
                    key={b.id}
                    className="border border-gray-200 rounded-xl p-4 hover:border-gray-300 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex-1 min-w-0">
                        {b.video_url && (
                          <video
                            src={b.video_url}
                            preload="metadata"
                            className="h-12 rounded mb-1 object-cover"
                          />
                        )}
                        {b.image_url && !b.video_url && (
                          <img
                            src={b.image_url}
                            alt=""
                            className="h-12 rounded mb-1 object-cover"
                          />
                        )}
                        {b.text && (
                          <p className="text-sm text-gray-900 line-clamp-2">
                            {b.text}
                          </p>
                        )}
                        {!b.text && b.video_url && (
                          <p className="text-sm text-gray-400">[動画]</p>
                        )}
                        {!b.text && !b.video_url && b.image_url && (
                          <p className="text-sm text-gray-400">[画像]</p>
                        )}
                      </div>
                      <StatusBadge status={b.status} />
                    </div>

                    <div className="mb-2">
                      <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            b.failed_count > 0
                              ? 'bg-amber-500'
                              : 'bg-emerald-500'
                          }`}
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 text-[10px] text-gray-500">
                        <span>{formatDate(b.created_at)}</span>
                        <span>
                          {b.sent_count}/{b.total_targets} 送信済
                        </span>
                        {b.failed_count > 0 && (
                          <span className="text-red-500">
                            {b.failed_count} 失敗
                          </span>
                        )}
                      </div>
                      {(b.status === 'failed' || b.status === 'queued') && (
                        <button
                          onClick={() => handleRetry(b)}
                          className="text-[10px] text-emerald-600 hover:text-emerald-700 font-medium"
                        >
                          再試行
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

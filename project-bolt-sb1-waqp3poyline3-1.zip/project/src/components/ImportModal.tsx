import { useState } from 'react';
import { X, Upload, Eye, AlertTriangle, CheckCircle, Folder } from 'lucide-react';
import type { ParsedAccountBlock, ImportResult, AccountGroup } from '../types';
import * as api from '../lib/api';

interface ImportModalProps {
  onClose: () => void;
  onComplete: () => void;
  groups: AccountGroup[];
  selectedGroupId?: string | null;
}

function parseBlocks(text: string): ParsedAccountBlock[] {
  const lines = text.split('\n');
  const nonEmpty: string[] = [];
  for (const line of lines) {
    if (line.trim()) nonEmpty.push(line.trim());
  }

  const isUrl = (s: string) =>
    s.startsWith('http://') || s.startsWith('https://');

  const urlIndices: number[] = [];
  for (let i = 0; i < nonEmpty.length; i++) {
    if (isUrl(nonEmpty[i])) urlIndices.push(i);
  }

  const blocks: ParsedAccountBlock[] = [];

  if (urlIndices.length === 0 && nonEmpty.length >= 4) {
    for (let i = 0; i < nonEmpty.length; i += 4) {
      if (i + 3 < nonEmpty.length) {
        blocks.push({
          friend_add_url: nonEmpty[i],
          channel_id: nonEmpty[i + 1],
          channel_secret: nonEmpty[i + 2],
          access_token: nonEmpty[i + 3],
          bot_user_id: '',
          valid: isUrl(nonEmpty[i]),
          error: isUrl(nonEmpty[i]) ? undefined : '無効なURL形式',
        });
      } else {
        blocks.push({
          friend_add_url: nonEmpty[i] || '',
          channel_id: nonEmpty[i + 1] || '',
          channel_secret: nonEmpty[i + 2] || '',
          access_token: '',
          bot_user_id: '',
          valid: false,
          error: '不完全なブロック (4行必要)',
        });
      }
    }
  } else {
    for (let idx = 0; idx < urlIndices.length; idx++) {
      const start = urlIndices[idx];
      const nextStart =
        idx + 1 < urlIndices.length ? urlIndices[idx + 1] : nonEmpty.length;
      const blockLines = nonEmpty.slice(start, nextStart);

      if (blockLines.length < 4) {
        blocks.push({
          friend_add_url: blockLines[0] || '',
          channel_id: blockLines[1] || '',
          channel_secret: blockLines[2] || '',
          access_token: '',
          bot_user_id: '',
          valid: false,
          error: `不完全なブロック (4行必要、${blockLines.length}行のみ)`,
        });
        continue;
      }

      blocks.push({
        friend_add_url: blockLines[0],
        channel_id: blockLines[1],
        channel_secret: blockLines[2],
        access_token: blockLines.slice(3).join(''),
        bot_user_id: '',
        valid: true,
      });
    }
  }

  return blocks;
}

export default function ImportModal({
  onClose,
  onComplete,
  groups,
  selectedGroupId,
}: ImportModalProps) {
  const [textData, setTextData] = useState('');
  const [groupId, setGroupId] = useState<string>(selectedGroupId || '');
  const [preview, setPreview] = useState<ParsedAccountBlock[] | null>(null);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);

  const handlePreview = () => {
    const blocks = parseBlocks(textData);
    setPreview(blocks);
  };

  const handleImport = async () => {
    setImporting(true);
    try {
      const res = await api.importAccounts(textData, groupId || undefined);
      setResult(res);
    } catch (err) {
      setResult({
        parsed_count: 0,
        success_count: 0,
        fail_count: 1,
        errors: [
          {
            index: 0,
            reason: err instanceof Error ? err.message : 'インポート失敗',
            raw_block: '',
          },
        ],
      });
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              アカウントインポート
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              4行ブロックを貼り付け: URL, Channel ID, Secret, Token
            </p>
          </div>
          <button
            onClick={() => {
              if (result) onComplete();
              onClose();
            }}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {!result ? (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  アカウントデータ
                </label>
                <textarea
                  value={textData}
                  onChange={(e) => {
                    setTextData(e.target.value);
                    setPreview(null);
                  }}
                  placeholder={`https://line.me/R/ti/p/aaa\n2009148469\nxxx_secret\nxxx_token\n\nhttps://line.me/R/ti/p/bbb\n2009156393\nyyy_secret\nyyy_token`}
                  rows={8}
                  className="w-full border border-gray-200 rounded-lg px-4 py-3 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
                />
              </div>

              {groups.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    インポート先グループ
                  </label>
                  <div className="relative">
                    <Folder className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <select
                      value={groupId}
                      onChange={(e) => setGroupId(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all appearance-none bg-white"
                    >
                      <option value="">未分類</option>
                      {groups.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}

              {preview && (
                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-gray-700">
                    プレビュー ({preview.length} 件)
                  </h3>
                  {preview.map((block, i) => (
                    <div
                      key={i}
                      className={`p-3 rounded-lg border text-xs ${
                        block.valid
                          ? 'border-emerald-200 bg-emerald-50'
                          : 'border-red-200 bg-red-50'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        {block.valid ? (
                          <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                        )}
                        <div className="min-w-0">
                          <div className="font-medium text-gray-900">
                            アカウント #{i + 1}
                          </div>
                          <div className="text-gray-600 truncate mt-0.5">
                            URL: {block.friend_add_url}
                          </div>
                          <div className="text-gray-600 truncate">
                            ID: {block.channel_id}
                          </div>
                          <div className="text-gray-600">
                            Secret: {block.channel_secret.slice(0, 8)}...
                          </div>
                          <div className="text-gray-600">
                            Token: {block.access_token.slice(0, 12)}...
                          </div>
                          {block.error && (
                            <div className="text-red-600 mt-1">
                              {block.error}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="space-y-4">
              <div className="text-center py-4">
                {result.success_count > 0 ? (
                  <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
                ) : (
                  <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-2" />
                )}
                <h3 className="text-lg font-semibold text-gray-900">
                  インポート完了
                </h3>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-gray-900">
                    {result.parsed_count}
                  </div>
                  <div className="text-xs text-gray-500">解析数</div>
                </div>
                <div className="text-center p-3 bg-emerald-50 rounded-lg">
                  <div className="text-2xl font-bold text-emerald-600">
                    {result.success_count}
                  </div>
                  <div className="text-xs text-emerald-600">成功</div>
                </div>
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    {result.fail_count}
                  </div>
                  <div className="text-xs text-red-600">失敗</div>
                </div>
              </div>
              {result.errors.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-red-700">エラー</h4>
                  {result.errors.map((err, i) => (
                    <div
                      key={i}
                      className="p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700"
                    >
                      ブロック #{err.index + 1}: {err.reason}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="p-5 border-t border-gray-100 flex justify-end gap-2">
          {!result ? (
            <>
              <button
                onClick={handlePreview}
                disabled={!textData.trim()}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-40 flex items-center gap-1.5"
              >
                <Eye className="w-4 h-4" />
                プレビュー
              </button>
              <button
                onClick={handleImport}
                disabled={!textData.trim() || importing}
                className="px-4 py-2 text-sm font-medium text-white bg-emerald-500 hover:bg-emerald-600 rounded-lg transition-colors disabled:opacity-40 flex items-center gap-1.5 shadow-sm"
              >
                {importing ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Upload className="w-4 h-4" />
                )}
                インポート
              </button>
            </>
          ) : (
            <button
              onClick={() => {
                onComplete();
                onClose();
              }}
              className="px-4 py-2 text-sm font-medium text-white bg-emerald-500 hover:bg-emerald-600 rounded-lg transition-colors shadow-sm"
            >
              完了
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

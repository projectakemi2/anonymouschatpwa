export interface AccountGroup {
  id: string;
  name: string;
  account_count: number;
  created_at: string;
  updated_at: string;
}

export interface Account {
  id: string;
  display_name: string;
  channel_id: string;
  channel_secret: string;
  access_token: string;
  friend_add_url: string;
  bot_user_id: string;
  group_id: string | null;
  is_enabled: boolean;
  created_at: string;
  updated_at: string;
  total_unread?: number;
}

export interface Conversation {
  id: string;
  account_id: string;
  line_user_id: string;
  line_display_name: string | null;
  last_message_at: string | null;
  unread_count: number;
  is_active: boolean;
  is_blocked: boolean;
  followed_at: string | null;
  unfollowed_at: string | null;
  created_at: string;
  updated_at: string;
  last_message_text?: string;
}

export interface Message {
  id: string;
  account_id: string;
  conversation_id: string;
  direction: 'in' | 'out';
  message_type: 'text' | 'image' | 'video';
  text: string;
  image_url: string | null;
  video_url: string | null;
  raw_payload: unknown;
  event_id: string | null;
  status: 'received' | 'sent' | 'failed';
  created_at: string;
}

export interface Broadcast {
  id: string;
  text: string;
  image_url: string | null;
  video_url: string | null;
  group_id: string | null;
  status: 'queued' | 'running' | 'done' | 'failed';
  total_targets: number;
  sent_count: number;
  failed_count: number;
  created_at: string;
}

export interface BroadcastTarget {
  id: string;
  broadcast_id: string;
  account_id: string;
  line_user_id: string;
  status: 'queued' | 'sent' | 'failed';
  error_message: string | null;
  sent_at: string | null;
}

export interface ImportResult {
  parsed_count: number;
  success_count: number;
  fail_count: number;
  errors: Array<{
    index: number;
    reason: string;
    raw_block: string;
  }>;
}

export interface ParsedAccountBlock {
  friend_add_url: string;
  channel_id: string;
  channel_secret: string;
  access_token: string;
  bot_user_id: string;
  valid: boolean;
  error?: string;
}

export interface RedirectLinkTarget {
  id: string;
  redirect_link_id: string;
  account_id: string;
  friend_add_url: string;
  weight: number;
  click_count: number;
  created_at: string;
}

export interface RedirectLink {
  id: string;
  slug: string;
  name: string;
  is_active: boolean;
  distribution_mode: 'weighted' | 'balanced';
  click_count: number;
  created_at: string;
  updated_at: string;
  targets: RedirectLinkTarget[];
}

import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import RedirectPage from './pages/RedirectPage';
import LoginPage from './pages/LoginPage';

export default function App() {
  const [authenticated, setAuthenticated] = useState(
    () => sessionStorage.getItem('authenticated') === '1'
  );

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/r/:slug" element={<RedirectPage />} />
        <Route
          path="/"
          element={
            authenticated ? (
              <Dashboard />
            ) : (
              <LoginPage onLogin={() => setAuthenticated(true)} />
            )
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

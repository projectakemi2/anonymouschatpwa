import type {
  Account,
  AccountGroup,
  Conversation,
  Message,
  Broadcast,
  ImportResult,
  RedirectLink,
} from '../types';
import { supabase } from './supabase';

const API_BASE = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-api`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

function getAuthHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${ANON_KEY}`,
    'Content-Type': 'application/json',
    apikey: ANON_KEY,
  };
}

async function fetchWithTimeout(
  url: string,
  options: RequestInit,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchApi<T = unknown>(
  path: string,
  options: RequestInit = {},
  retries = 1
): Promise<T> {
  const headers = getAuthHeaders();
  const timeoutMs = 30000;

  let lastError: Error | null = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const response = await fetchWithTimeout(
        `${API_BASE}${path}`,
        { ...options, headers: { ...headers, ...(options.headers as Record<string, string>) } },
        timeoutMs
      );

      const text = await response.text();
      let data: unknown;
      try {
        data = JSON.parse(text);
      } catch {
        console.error('Failed to parse response:', text);
        throw new Error(`API request failed (status ${response.status})`);
      }

      if (!response.ok) {
        console.error('API error:', data);
        const errMsg = (data as Record<string, string>)?.error || `API request failed (status ${response.status})`;
        throw new Error(errMsg);
      }
      return data as T;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      if (attempt < retries && (lastError.name === 'AbortError' || lastError.message.includes('fetch'))) {
        await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
        continue;
      }
    }
  }
  throw lastError!;
}

export async function listAccounts(): Promise<Account[]> {
  const data = await fetchApi<{ accounts: Account[] }>('/accounts');
  return data.accounts;
}

export async function createAccount(
  account: Partial<Account>
): Promise<Account> {
  const data = await fetchApi<{ account: Account }>('/accounts', {
    method: 'POST',
    body: JSON.stringify(account),
  });
  return data.account;
}

export async function importAccounts(
  textData: string,
  groupId?: string
): Promise<ImportResult> {
  return fetchApi<ImportResult>('/accounts/import', {
    method: 'POST',
    body: JSON.stringify({ text_data: textData, group_id: groupId }),
  });
}

export async function listConversations(
  accountId: string
): Promise<Conversation[]> {

  const { data, error } = await supabase
    .from('conversations')
    .select('id, account_id, line_user_id, line_display_name, last_message_at, last_message_text, unread_count, is_active, is_blocked, followed_at, unfollowed_at, created_at, updated_at')
    .eq('account_id', accountId)
    .order('last_message_at', { ascending: false, nullsFirst: false });

  if (error) throw new Error(error.message);

  return (data || []).sort((a, b) => {
    const ua = a.unread_count > 0 ? 1 : 0;
    const ub = b.unread_count > 0 ? 1 : 0;
    if (ub !== ua) return ub - ua;
    const ta = a.last_message_at ? new Date(a.last_message_at).getTime() : 0;
    const tb = b.last_message_at ? new Date(b.last_message_at).getTime() : 0;
    return tb - ta;
  }) as Conversation[];
}

export async function listMessages(
  conversationId: string,
  options?: { limit?: number; before?: string }
): Promise<{ messages: Message[]; has_more: boolean }> {

  const limit = Math.min(options?.limit || 50, 200);

  let query = supabase
    .from('messages')
    .select('id, account_id, conversation_id, direction, message_type, text, image_url, video_url, event_id, status, created_at')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (options?.before) {
    query = query.lt('created_at', options.before);
  }

  const { data, error } = await query;
  if (error) throw new Error(error.message);

  const messages = (data || []).reverse() as Message[];
  const has_more = (data || []).length === limit;
  return { messages, has_more };
}

export async function markAsRead(conversationId: string): Promise<void> {
  await fetchApi(`/conversations/${conversationId}/read`, {
    method: 'POST',
  });
}

export async function uploadImage(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('file', file);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${ANON_KEY}`,
    apikey: ANON_KEY,
  };
  const response = await fetch(`${API_BASE}/upload-image`, {
    method: 'POST',
    headers,
    body: formData,
  });
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || 'Upload failed');
  }
  const data = await response.json();
  return data.url;
}

export async function uploadVideo(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('file', file);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${ANON_KEY}`,
    apikey: ANON_KEY,
  };
  const response = await fetch(`${API_BASE}/upload-video`, {
    method: 'POST',
    headers,
    body: formData,
  });
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || 'Upload failed');
  }
  const data = await response.json();
  return data.url;
}

export async function sendMessage(
  accountId: string,
  conversationId: string,
  text: string,
  imageUrl?: string,
  videoUrl?: string
): Promise<{ message: Message; success: boolean }> {
  return fetchApi('/send', {
    method: 'POST',
    body: JSON.stringify({
      account_id: accountId,
      conversation_id: conversationId,
      text,
      image_url: imageUrl,
      video_url: videoUrl,
    }),
  });
}

export async function createBroadcast(
  text: string,
  imageUrl?: string,
  groupId?: string,
  videoUrl?: string
): Promise<{ broadcast: Broadcast }> {
  return fetchApi('/broadcast-all', {
    method: 'POST',
    body: JSON.stringify({ text, image_url: imageUrl, group_id: groupId, video_url: videoUrl }),
  });
}

export async function listGroups(): Promise<AccountGroup[]> {
  const data = await fetchApi<{ groups: AccountGroup[] }>('/account-groups');
  return data.groups;
}

export async function createGroup(name: string): Promise<AccountGroup> {
  const data = await fetchApi<{ group: AccountGroup }>('/account-groups', {
    method: 'POST',
    body: JSON.stringify({ name }),
  });
  return data.group;
}

export async function updateGroup(groupId: string, name: string): Promise<AccountGroup> {
  const data = await fetchApi<{ group: AccountGroup }>(`/account-groups/${groupId}`, {
    method: 'PUT',
    body: JSON.stringify({ name }),
  });
  return data.group;
}

export async function deleteGroup(groupId: string): Promise<void> {
  await fetchApi(`/account-groups/${groupId}`, {
    method: 'DELETE',
  });
}

export async function assignAccountGroup(accountId: string, groupId: string | null): Promise<void> {
  await fetchApi(`/accounts/${accountId}/group`, {
    method: 'PUT',
    body: JSON.stringify({ group_id: groupId }),
  });
}

export async function processBroadcast(
  broadcastId: string
): Promise<{ broadcast: Broadcast; remaining: number; processed: number }> {
  return fetchApi('/broadcast-process', {
    method: 'POST',
    body: JSON.stringify({ broadcast_id: broadcastId }),
  });
}

export async function listBroadcasts(): Promise<Broadcast[]> {
  const data = await fetchApi<{ broadcasts: Broadcast[] }>('/broadcasts');
  return data.broadcasts;
}

export async function getBroadcast(
  broadcastId: string
): Promise<Broadcast> {
  const data = await fetchApi<{ broadcast: Broadcast }>(
    `/broadcasts/${broadcastId}`
  );
  return data.broadcast;
}

export async function resendMessage(
  messageId: string,
  accountId: string,
  conversationId: string,
  text: string
): Promise<{ message: Message; success: boolean }> {
  return fetchApi('/resend', {
    method: 'POST',
    body: JSON.stringify({
      message_id: messageId,
      account_id: accountId,
      conversation_id: conversationId,
      text,
    }),
  });
}

export async function deleteAccount(accountId: string): Promise<void> {
  await fetchApi(`/accounts/${accountId}`, {
    method: 'DELETE',
  });
}

export async function listRedirectLinks(): Promise<RedirectLink[]> {
  const data = await fetchApi<{ redirect_links: RedirectLink[] }>('/redirect-links');
  return data.redirect_links;
}

export async function createRedirectLink(
  payload: {
    name: string;
    slug: string;
    distribution_mode?: 'weighted' | 'balanced';
    targets: Array<{ account_id: string; friend_add_url: string; weight?: number }>;
  }
): Promise<RedirectLink> {
  const data = await fetchApi<{ redirect_link: RedirectLink }>('/redirect-links', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return data.redirect_link;
}

export async function updateRedirectLink(
  linkId: string,
  payload: {
    name?: string;
    slug?: string;
    is_active?: boolean;
    distribution_mode?: 'weighted' | 'balanced';
    targets?: Array<{ account_id: string; friend_add_url: string; weight?: number }>;
  }
): Promise<RedirectLink> {
  const data = await fetchApi<{ redirect_link: RedirectLink }>(`/redirect-links/${linkId}`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
  return data.redirect_link;
}

export async function deleteRedirectLink(linkId: string): Promise<void> {
  await fetchApi(`/redirect-links/${linkId}`, {
    method: 'DELETE',
  });
}

import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function getSupabase() {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );
}

function getRoutePath(url: URL): string {
  const match = url.pathname.match(/\/manage-api\/(.*)/);
  return match ? "/" + match[1] : "/";
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = getSupabase();
    const url = new URL(req.url);
    const route = getRoutePath(url);
    const method = req.method;

    if (method === "GET" && route === "/accounts") {
      return await handleListAccounts(supabase);
    }
    if (method === "POST" && route === "/accounts") {
      return await handleCreateAccount(supabase, req);
    }
    if (method === "POST" && route === "/accounts/import") {
      return await handleImportAccounts(supabase, req);
    }
    const deleteAccountMatch = route.match(/^\/accounts\/([^/]+)$/);
    if (method === "DELETE" && deleteAccountMatch) {
      return await handleDeleteAccount(supabase, deleteAccountMatch[1]);
    }
    if (method === "GET" && route === "/conversations") {
      return await handleListConversations(supabase, url);
    }
    if (method === "GET" && route === "/messages") {
      return await handleListMessages(supabase, url);
    }
    const readMatch = route.match(/^\/conversations\/([^/]+)\/read$/);
    if (method === "POST" && readMatch) {
      return await handleMarkAsRead(supabase, readMatch[1]);
    }
    if (method === "POST" && route === "/upload-image") {
      return await handleUploadImage(supabase, req);
    }
    if (method === "POST" && route === "/upload-video") {
      return await handleUploadVideo(supabase, req);
    }
    if (method === "POST" && route === "/send") {
      return await handleSend(supabase, req);
    }
    if (method === "POST" && route === "/resend") {
      return await handleResend(supabase, req);
    }
    if (method === "POST" && route === "/broadcast-all") {
      return await handleBroadcastAll(supabase, req);
    }
    if (method === "POST" && route === "/broadcast-process") {
      return await handleBroadcastProcess(supabase, req);
    }
    if (method === "GET" && route === "/broadcasts") {
      return await handleListBroadcasts(supabase);
    }
    const broadcastMatch = route.match(/^\/broadcasts\/([^/]+)$/);
    if (method === "GET" && broadcastMatch) {
      return await handleGetBroadcast(supabase, broadcastMatch[1]);
    }

    if (method === "GET" && route === "/account-groups") {
      return await handleListGroups(supabase);
    }
    if (method === "POST" && route === "/account-groups") {
      return await handleCreateGroup(supabase, req);
    }
    const groupMatch = route.match(/^\/account-groups\/([^/]+)$/);
    if (method === "PUT" && groupMatch) {
      return await handleUpdateGroup(supabase, groupMatch[1], req);
    }
    if (method === "DELETE" && groupMatch) {
      return await handleDeleteGroup(supabase, groupMatch[1]);
    }
    const assignGroupMatch = route.match(/^\/accounts\/([^/]+)\/group$/);
    if (method === "PUT" && assignGroupMatch) {
      return await handleAssignGroup(supabase, assignGroupMatch[1], req);
    }

    if (method === "GET" && route === "/redirect-links") {
      return await handleListRedirectLinks(supabase);
    }
    if (method === "POST" && route === "/redirect-links") {
      return await handleCreateRedirectLink(supabase, req);
    }
    const redirectLinkMatch = route.match(/^\/redirect-links\/([^/]+)$/);
    if (method === "PUT" && redirectLinkMatch) {
      return await handleUpdateRedirectLink(supabase, redirectLinkMatch[1], req);
    }
    if (method === "DELETE" && redirectLinkMatch) {
      return await handleDeleteRedirectLink(supabase, redirectLinkMatch[1]);
    }

    return jsonResponse({ error: "Not found" }, 404);
  } catch (error) {
    console.error("API error:", error);
    return jsonResponse({ error: "Internal server error" }, 500);
  }
});

type SB = ReturnType<typeof createClient>;

async function handleListAccounts(supabase: SB) {
  const [accountsRes, unreadRes] = await Promise.all([
    supabase
      .from("accounts")
      .select("id, display_name, channel_id, friend_add_url, is_enabled, group_id, created_at, updated_at")
      .order("created_at", { ascending: true }),
    supabase
      .from("conversations")
      .select("account_id, unread_count")
      .gt("unread_count", 0),
  ]);

  if (accountsRes.error) return jsonResponse({ error: accountsRes.error.message }, 500);

  const unreadByAccount: Record<string, number> = {};
  for (const conv of unreadRes.data || []) {
    unreadByAccount[conv.account_id] =
      (unreadByAccount[conv.account_id] || 0) + conv.unread_count;
  }

  const result = (accountsRes.data || []).map((a: Record<string, unknown>) => ({
    ...a,
    total_unread: unreadByAccount[a.id as string] || 0,
  }));

  return jsonResponse({ accounts: result });
}

async function handleCreateAccount(supabase: SB, req: Request) {
  const body = await req.json();
  const { data, error } = await supabase
    .from("accounts")
    .insert({
      display_name: body.display_name || "",
      channel_id: body.channel_id,
      channel_secret: body.channel_secret,
      access_token: body.access_token,
      friend_add_url: body.friend_add_url || "",
      is_enabled: true,
    })
    .select()
    .single();

  if (error) return jsonResponse({ error: error.message }, 400);
  return jsonResponse({ account: data });
}

async function handleImportAccounts(supabase: SB, req: Request) {
  try {
    const body = await req.json();
    console.log("Import request body:", body);

    const { text_data, group_id } = body;
    const lines = (text_data as string).split("\n");
    const nonEmpty: string[] = [];
    for (const line of lines) {
      if (line.trim()) nonEmpty.push(line.trim());
    }

    console.log("Non-empty lines:", nonEmpty.length);

    const results = {
      parsed_count: 0,
      success_count: 0,
      fail_count: 0,
      errors: [] as Array<{ index: number; reason: string; raw_block: string }>,
    };

    const blocks: Array<{
      friend_add_url: string;
      channel_id: string;
      channel_secret: string;
      access_token: string;
    }> = [];

    const isUrl = (s: string) =>
      s.startsWith("http://") || s.startsWith("https://");

    const urlIndices: number[] = [];
    for (let i = 0; i < nonEmpty.length; i++) {
      if (isUrl(nonEmpty[i])) urlIndices.push(i);
    }

    if (urlIndices.length === 0 && nonEmpty.length >= 4) {
      for (let i = 0; i < nonEmpty.length; i += 4) {
        if (i + 3 < nonEmpty.length) {
          blocks.push({
            friend_add_url: nonEmpty[i],
            channel_id: nonEmpty[i + 1],
            channel_secret: nonEmpty[i + 2],
            access_token: nonEmpty[i + 3],
          });
        } else {
          results.errors.push({
            index: blocks.length,
            reason: "Incomplete block (needs 4 lines)",
            raw_block: nonEmpty.slice(i).join("\n"),
          });
          results.fail_count++;
        }
      }
    } else {
      for (let idx = 0; idx < urlIndices.length; idx++) {
        const start = urlIndices[idx];
        const nextStart =
          idx + 1 < urlIndices.length ? urlIndices[idx + 1] : nonEmpty.length;
        const blockLines = nonEmpty.slice(start, nextStart);

        if (blockLines.length < 4) {
          results.errors.push({
            index: blocks.length,
            reason: `Incomplete block (needs 4 lines, got ${blockLines.length})`,
            raw_block: blockLines.join("\n"),
          });
          results.fail_count++;
          continue;
        }

        blocks.push({
          friend_add_url: blockLines[0],
          channel_id: blockLines[1],
          channel_secret: blockLines[2],
          access_token: blockLines.slice(3).join(""),
        });
      }
    }

    console.log("Parsed blocks:", blocks.length);
    results.parsed_count = blocks.length + results.fail_count;

    for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];

    if (
      !block.friend_add_url.startsWith("http://") &&
      !block.friend_add_url.startsWith("https://")
    ) {
      results.errors.push({
        index: i,
        reason: "Invalid URL format (must start with http/https)",
        raw_block: Object.values(block).join("\n"),
      });
      results.fail_count++;
      continue;
    }

    if (!block.channel_id || !block.channel_secret || !block.access_token) {
      results.errors.push({
        index: i,
        reason: "Missing required field",
        raw_block: Object.values(block).join("\n"),
      });
      results.fail_count++;
      continue;
    }

    const { data: existing } = await supabase
      .from("accounts")
      .select("id, display_name")
      .eq("channel_id", block.channel_id)
      .maybeSingle();

    if (existing) {
      const updateData: Record<string, unknown> = {
        channel_secret: block.channel_secret,
        access_token: block.access_token,
        friend_add_url: block.friend_add_url,
      };
      if (group_id) updateData.group_id = group_id;
      const { error } = await supabase
        .from("accounts")
        .update(updateData)
        .eq("id", existing.id);

      if (error) {
        results.errors.push({
          index: i,
          reason: error.message,
          raw_block: Object.values(block).join("\n"),
        });
        results.fail_count++;
      } else {
        results.success_count++;
      }
    } else {
      const displayName = `Imported-${block.channel_id.slice(-6)}`;
      const { error } = await supabase.from("accounts").insert({
        display_name: displayName,
        channel_id: block.channel_id,
        channel_secret: block.channel_secret,
        access_token: block.access_token,
        friend_add_url: block.friend_add_url,
        group_id: group_id || null,
        is_enabled: true,
      });

      if (error) {
        results.errors.push({
          index: i,
          reason: error.message,
          raw_block: Object.values(block).join("\n"),
        });
        results.fail_count++;
      } else {
        results.success_count++;
      }
    }
    }

    return jsonResponse(results);
  } catch (error) {
    console.error("Import error:", error);
    return jsonResponse({
      parsed_count: 0,
      success_count: 0,
      fail_count: 1,
      errors: [{
        index: 0,
        reason: error instanceof Error ? error.message : "Unknown error",
        raw_block: ""
      }]
    }, 500);
  }
}

async function handleDeleteAccount(supabase: SB, accountId: string) {
  const { error } = await supabase
    .from("accounts")
    .delete()
    .eq("id", accountId);

  if (error) return jsonResponse({ error: error.message }, 500);
  return jsonResponse({ success: true });
}

async function handleListConversations(supabase: SB, url: URL) {
  const accountId = url.searchParams.get("account_id");
  if (!accountId) return jsonResponse({ error: "account_id required" }, 400);

  const { data, error } = await supabase
    .from("conversations")
    .select("id, account_id, line_user_id, line_display_name, last_message_at, last_message_text, unread_count, is_active, is_blocked, followed_at, unfollowed_at, created_at, updated_at")
    .eq("account_id", accountId)
    .order("last_message_at", { ascending: false, nullsFirst: false });

  if (error) return jsonResponse({ error: error.message }, 500);

  const result = (data || []).sort((a: Record<string, unknown>, b: Record<string, unknown>) => {
    const ua = (a.unread_count as number) > 0 ? 1 : 0;
    const ub = (b.unread_count as number) > 0 ? 1 : 0;
    if (ub !== ua) return ub - ua;
    const ta = a.last_message_at ? new Date(a.last_message_at as string).getTime() : 0;
    const tb = b.last_message_at ? new Date(b.last_message_at as string).getTime() : 0;
    return tb - ta;
  });

  return jsonResponse({ conversations: result });
}

async function handleListMessages(supabase: SB, url: URL) {
  const conversationId = url.searchParams.get("conversation_id");
  if (!conversationId)
    return jsonResponse({ error: "conversation_id required" }, 400);

  const limit = Math.min(Number(url.searchParams.get("limit")) || 50, 200);
  const before = url.searchParams.get("before");

  let query = supabase
    .from("messages")
    .select("id, account_id, conversation_id, direction, message_type, text, image_url, video_url, event_id, status, created_at")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (before) {
    query = query.lt("created_at", before);
  }

  const { data, error } = await query;

  if (error) return jsonResponse({ error: error.message }, 500);

  const messages = (data || []).reverse();
  const has_more = (data || []).length === limit;

  return jsonResponse({ messages, has_more });
}

async function handleMarkAsRead(supabase: SB, conversationId: string) {
  const { error } = await supabase
    .from("conversations")
    .update({ unread_count: 0 })
    .eq("id", conversationId);

  if (error) return jsonResponse({ error: error.message }, 500);
  return jsonResponse({ success: true });
}

async function handleUploadImage(supabase: SB, req: Request) {
  const contentType = req.headers.get("content-type") || "";
  if (!contentType.includes("multipart/form-data")) {
    return jsonResponse({ error: "multipart/form-data required" }, 400);
  }

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  if (!file) return jsonResponse({ error: "No file provided" }, 400);

  const ext = file.name.split(".").pop() || "jpg";
  const fileName = `${crypto.randomUUID()}.${ext}`;
  const filePath = `uploads/${fileName}`;

  const arrayBuffer = await file.arrayBuffer();
  const { error } = await supabase.storage
    .from("line-images")
    .upload(filePath, arrayBuffer, {
      contentType: file.type,
      upsert: false,
    });

  if (error) return jsonResponse({ error: error.message }, 500);

  const { data: urlData } = supabase.storage
    .from("line-images")
    .getPublicUrl(filePath);

  return jsonResponse({ url: urlData.publicUrl });
}

function buildLineMessages(text: string, imageUrl?: string, videoUrl?: string): Array<Record<string, unknown>> {
  const msgs: Array<Record<string, unknown>> = [];
  if (videoUrl) {
    msgs.push({
      type: "video",
      originalContentUrl: videoUrl,
      previewImageUrl: imageUrl || videoUrl,
    });
  } else if (imageUrl) {
    msgs.push({
      type: "image",
      originalContentUrl: imageUrl,
      previewImageUrl: imageUrl,
    });
  }
  if (text) {
    msgs.push({ type: "text", text });
  }
  return msgs;
}

async function handleUploadVideo(supabase: SB, req: Request) {
  const contentType = req.headers.get("content-type") || "";
  if (!contentType.includes("multipart/form-data")) {
    return jsonResponse({ error: "multipart/form-data required" }, 400);
  }

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  if (!file) return jsonResponse({ error: "No file provided" }, 400);

  const ext = file.name.split(".").pop() || "mp4";
  const fileName = `${crypto.randomUUID()}.${ext}`;
  const filePath = `videos/${fileName}`;

  const arrayBuffer = await file.arrayBuffer();
  const { error } = await supabase.storage
    .from("line-images")
    .upload(filePath, arrayBuffer, {
      contentType: file.type,
      upsert: false,
    });

  if (error) return jsonResponse({ error: error.message }, 500);

  const { data: urlData } = supabase.storage
    .from("line-images")
    .getPublicUrl(filePath);

  return jsonResponse({ url: urlData.publicUrl });
}

async function handleSend(supabase: SB, req: Request) {
  const { account_id, conversation_id, text, image_url, video_url } = await req.json();

  const { data: conv } = await supabase
    .from("conversations")
    .select("line_user_id")
    .eq("id", conversation_id)
    .single();

  if (!conv) return jsonResponse({ error: "Conversation not found" }, 404);

  const { data: account } = await supabase
    .from("accounts")
    .select("access_token")
    .eq("id", account_id)
    .single();

  if (!account) return jsonResponse({ error: "Account not found" }, 404);

  const lineMessages = buildLineMessages(text || "", image_url, video_url);
  if (lineMessages.length === 0) {
    return jsonResponse({ error: "No message content" }, 400);
  }

  let status = "sent";
  let rawResponse = null;

  try {
    const response = await fetch("https://api.line.me/v2/bot/message/push", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${account.access_token}`,
      },
      body: JSON.stringify({
        to: conv.line_user_id,
        messages: lineMessages,
      }),
    });

    if (!response.ok) {
      status = "failed";
      rawResponse = await response.text();
    }
  } catch (err) {
    status = "failed";
    rawResponse = (err as Error).message;
  }

  const messageType = video_url ? "video" : image_url ? (text ? "text" : "image") : "text";
  const { data: msg, error } = await supabase
    .from("messages")
    .insert({
      account_id,
      conversation_id,
      direction: "out",
      message_type: messageType,
      text: text || "",
      image_url: image_url || null,
      video_url: video_url || null,
      status,
      raw_payload: rawResponse ? { error: rawResponse } : null,
    })
    .select()
    .single();

  if (error) return jsonResponse({ error: error.message }, 500);

  await supabase
    .from("conversations")
    .update({ last_message_at: new Date().toISOString() })
    .eq("id", conversation_id);

  return jsonResponse({ message: msg, success: status === "sent" });
}

async function handleResend(supabase: SB, req: Request) {
  const { message_id, account_id, conversation_id, text, image_url, video_url } = await req.json();

  if (message_id) {
    await supabase.from("messages").delete().eq("id", message_id);
  }

  const fakeReq = new Request(req.url, {
    method: "POST",
    headers: req.headers,
    body: JSON.stringify({ account_id, conversation_id, text, image_url, video_url }),
  });
  return handleSend(supabase, fakeReq);
}

async function handleBroadcastAll(supabase: SB, req: Request) {
  const { text, image_url, video_url, group_id } = await req.json();

  let query = supabase
    .from("conversations")
    .select("account_id, line_user_id, accounts!inner(is_enabled, group_id)")
    .eq("is_active", true)
    .eq("is_blocked", false)
    .eq("accounts.is_enabled", true);

  if (group_id) {
    query = query.eq("accounts.group_id", group_id);
  }

  const { data: targetRows, error: targetErr } = await query;

  if (targetErr) {
    console.error("Failed to fetch broadcast targets:", targetErr);
    return jsonResponse({ error: targetErr.message }, 500);
  }

  const targetList = (targetRows || []).map((r: Record<string, unknown>) => ({
    account_id: r.account_id,
    line_user_id: r.line_user_id,
  }));

  const { data: broadcast, error } = await supabase
    .from("broadcasts")
    .insert({
      text: text || "",
      image_url: image_url || null,
      video_url: video_url || null,
      group_id: group_id || null,
      status: "queued",
      total_targets: targetList.length,
      sent_count: 0,
      failed_count: 0,
    })
    .select()
    .single();

  if (error) return jsonResponse({ error: error.message }, 500);

  if (targetList.length > 0) {
    const targetRecords = targetList.map(
      (t: Record<string, unknown>) => ({
        broadcast_id: broadcast.id,
        account_id: t.account_id,
        line_user_id: t.line_user_id,
        status: "queued",
      })
    );

    const batchSize = 500;
    for (let i = 0; i < targetRecords.length; i += batchSize) {
      await supabase
        .from("broadcast_targets")
        .insert(targetRecords.slice(i, i + batchSize));
    }
  }

  return jsonResponse({ broadcast });
}

async function handleBroadcastProcess(supabase: SB, req: Request) {
  const { broadcast_id } = await req.json();
  const BATCH_SIZE = 50;
  const CONCURRENCY = 10;

  const { data: broadcast } = await supabase
    .from("broadcasts")
    .select("*")
    .eq("id", broadcast_id)
    .single();

  if (!broadcast) return jsonResponse({ error: "Broadcast not found" }, 404);

  if (broadcast.status === "done") {
    return jsonResponse({ broadcast, remaining: 0, processed: 0 });
  }

  await supabase
    .from("broadcasts")
    .update({ status: "running" })
    .eq("id", broadcast_id);

  const { data: targets } = await supabase
    .from("broadcast_targets")
    .select("*")
    .eq("broadcast_id", broadcast_id)
    .eq("status", "queued")
    .limit(BATCH_SIZE);

  if (!targets || targets.length === 0) {
    await supabase
      .from("broadcasts")
      .update({ status: "done" })
      .eq("id", broadcast_id);

    const { data: updated } = await supabase
      .from("broadcasts")
      .select("*")
      .eq("id", broadcast_id)
      .single();

    return jsonResponse({ broadcast: updated, remaining: 0, processed: 0 });
  }

  const accountIds = [
    ...new Set(targets.map((t: Record<string, unknown>) => t.account_id)),
  ];
  const { data: accountsData } = await supabase
    .from("accounts")
    .select("id, access_token")
    .in("id", accountIds);

  const tokenMap: Record<string, string> = {};
  for (const a of accountsData || []) {
    tokenMap[a.id] = a.access_token;
  }

  let sentCount = 0;
  let failedCount = 0;
  const lineMessages = buildLineMessages(broadcast.text || "", broadcast.image_url, broadcast.video_url);

  async function sendOne(target: Record<string, unknown>) {
    const accessToken = tokenMap[target.account_id as string];
    try {
      const response = await fetch(
        "https://api.line.me/v2/bot/message/push",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            to: target.line_user_id,
            messages: lineMessages,
          }),
        }
      );

      if (response.ok) {
        await supabase
          .from("broadcast_targets")
          .update({ status: "sent", sent_at: new Date().toISOString() })
          .eq("id", target.id);
        sentCount++;
      } else {
        const errText = await response.text();
        await supabase
          .from("broadcast_targets")
          .update({ status: "failed", error_message: errText })
          .eq("id", target.id);
        failedCount++;
      }
    } catch (err) {
      await supabase
        .from("broadcast_targets")
        .update({
          status: "failed",
          error_message: (err as Error).message,
        })
        .eq("id", target.id);
      failedCount++;
    }
  }

  for (let i = 0; i < targets.length; i += CONCURRENCY) {
    const chunk = targets.slice(i, i + CONCURRENCY);
    await Promise.all(chunk.map(sendOne));
    if (i + CONCURRENCY < targets.length) {
      await new Promise((r) => setTimeout(r, 100));
    }
  }

  await supabase
    .from("broadcasts")
    .update({
      sent_count: broadcast.sent_count + sentCount,
      failed_count: broadcast.failed_count + failedCount,
    })
    .eq("id", broadcast_id);

  const { count: remainingCount } = await supabase
    .from("broadcast_targets")
    .select("id", { count: "exact", head: true })
    .eq("broadcast_id", broadcast_id)
    .eq("status", "queued");

  if ((remainingCount || 0) === 0) {
    await supabase
      .from("broadcasts")
      .update({ status: "done" })
      .eq("id", broadcast_id);
  }

  const { data: updatedBroadcast } = await supabase
    .from("broadcasts")
    .select("*")
    .eq("id", broadcast_id)
    .single();

  return jsonResponse({
    broadcast: updatedBroadcast,
    remaining: remainingCount || 0,
    processed: targets.length,
  });
}

async function handleListBroadcasts(supabase: SB) {
  const { data, error } = await supabase
    .from("broadcasts")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) return jsonResponse({ error: error.message }, 500);
  return jsonResponse({ broadcasts: data || [] });
}

async function handleGetBroadcast(supabase: SB, broadcastId: string) {
  const { data, error } = await supabase
    .from("broadcasts")
    .select("*")
    .eq("id", broadcastId)
    .single();

  if (error) return jsonResponse({ error: error.message }, 404);
  return jsonResponse({ broadcast: data });
}

async function handleListRedirectLinks(supabase: SB) {
  const { data: links, error } = await supabase
    .from("redirect_links")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) return jsonResponse({ error: error.message }, 500);

  const linkIds = (links || []).map((l: Record<string, unknown>) => l.id as string);
  let targets: Record<string, unknown>[] = [];

  if (linkIds.length > 0) {
    const { data: t } = await supabase
      .from("redirect_link_targets")
      .select("*")
      .in("redirect_link_id", linkIds)
      .order("created_at", { ascending: true });
    targets = t || [];
  }

  const targetsByLink: Record<string, Record<string, unknown>[]> = {};
  for (const t of targets) {
    const lid = t.redirect_link_id as string;
    if (!targetsByLink[lid]) targetsByLink[lid] = [];
    targetsByLink[lid].push(t);
  }

  const result = (links || []).map((l: Record<string, unknown>) => ({
    ...l,
    targets: targetsByLink[l.id as string] || [],
  }));

  return jsonResponse({ redirect_links: result });
}

async function handleCreateRedirectLink(supabase: SB, req: Request) {
  const body = await req.json();
  const { name, slug, targets } = body as {
    name: string;
    slug: string;
    targets: Array<{ account_id: string; friend_add_url: string; weight?: number }>;
  };

  const distribution_mode = body.distribution_mode || "weighted";

  const { data: link, error } = await supabase
    .from("redirect_links")
    .insert({ name, slug, distribution_mode })
    .select()
    .single();

  if (error) return jsonResponse({ error: error.message }, 400);

  if (targets && targets.length > 0) {
    const targetRecords = targets.map((t) => ({
      redirect_link_id: link.id,
      account_id: t.account_id,
      friend_add_url: t.friend_add_url,
      weight: t.weight || 1,
    }));

    const { error: tErr } = await supabase
      .from("redirect_link_targets")
      .insert(targetRecords);

    if (tErr) return jsonResponse({ error: tErr.message }, 400);
  }

  const { data: full } = await supabase
    .from("redirect_link_targets")
    .select("*")
    .eq("redirect_link_id", link.id);

  return jsonResponse({ redirect_link: { ...link, targets: full || [] } });
}

async function handleUpdateRedirectLink(supabase: SB, linkId: string, req: Request) {
  const body = await req.json();
  const { name, slug, is_active, distribution_mode, targets } = body as {
    name?: string;
    slug?: string;
    is_active?: boolean;
    distribution_mode?: string;
    targets?: Array<{ account_id: string; friend_add_url: string; weight?: number }>;
  };

  const updates: Record<string, unknown> = {};
  if (name !== undefined) updates.name = name;
  if (slug !== undefined) updates.slug = slug;
  if (is_active !== undefined) updates.is_active = is_active;
  if (distribution_mode !== undefined) updates.distribution_mode = distribution_mode;

  if (Object.keys(updates).length > 0) {
    const { error } = await supabase
      .from("redirect_links")
      .update(updates)
      .eq("id", linkId);

    if (error) return jsonResponse({ error: error.message }, 400);
  }

  if (targets !== undefined) {
    await supabase
      .from("redirect_link_targets")
      .delete()
      .eq("redirect_link_id", linkId);

    if (targets.length > 0) {
      const targetRecords = targets.map((t) => ({
        redirect_link_id: linkId,
        account_id: t.account_id,
        friend_add_url: t.friend_add_url,
        weight: t.weight || 1,
      }));

      const { error: tErr } = await supabase
        .from("redirect_link_targets")
        .insert(targetRecords);

      if (tErr) return jsonResponse({ error: tErr.message }, 400);
    }
  }

  const { data: link } = await supabase
    .from("redirect_links")
    .select("*")
    .eq("id", linkId)
    .single();

  const { data: tgts } = await supabase
    .from("redirect_link_targets")
    .select("*")
    .eq("redirect_link_id", linkId);

  return jsonResponse({ redirect_link: { ...link, targets: tgts || [] } });
}

async function handleDeleteRedirectLink(supabase: SB, linkId: string) {
  const { error } = await supabase
    .from("redirect_links")
    .delete()
    .eq("id", linkId);

  if (error) return jsonResponse({ error: error.message }, 500);
  return jsonResponse({ success: true });
}

async function handleListGroups(supabase: SB) {
  const { data: groups, error } = await supabase
    .from("account_groups")
    .select("*")
    .order("created_at", { ascending: true });

  if (error) return jsonResponse({ error: error.message }, 500);

  const { data: accounts } = await supabase
    .from("accounts")
    .select("id, group_id")
    .not("group_id", "is", null);

  const countByGroup: Record<string, number> = {};
  for (const a of accounts || []) {
    countByGroup[a.group_id] = (countByGroup[a.group_id] || 0) + 1;
  }

  const result = (groups || []).map((g: Record<string, unknown>) => ({
    ...g,
    account_count: countByGroup[g.id as string] || 0,
  }));

  return jsonResponse({ groups: result });
}

async function handleCreateGroup(supabase: SB, req: Request) {
  const { name } = await req.json();
  if (!name || !name.trim()) {
    return jsonResponse({ error: "Group name is required" }, 400);
  }

  const { data, error } = await supabase
    .from("account_groups")
    .insert({ name: name.trim() })
    .select()
    .single();

  if (error) return jsonResponse({ error: error.message }, 400);
  return jsonResponse({ group: { ...data, account_count: 0 } });
}

async function handleUpdateGroup(supabase: SB, groupId: string, req: Request) {
  const { name } = await req.json();
  const updates: Record<string, unknown> = {};
  if (name !== undefined) updates.name = name.trim();

  const { data, error } = await supabase
    .from("account_groups")
    .update(updates)
    .eq("id", groupId)
    .select()
    .single();

  if (error) return jsonResponse({ error: error.message }, 400);
  return jsonResponse({ group: data });
}

async function handleDeleteGroup(supabase: SB, groupId: string) {
  const { error } = await supabase
    .from("account_groups")
    .delete()
    .eq("id", groupId);

  if (error) return jsonResponse({ error: error.message }, 500);
  return jsonResponse({ success: true });
}

async function handleAssignGroup(supabase: SB, accountId: string, req: Request) {
  const { group_id } = await req.json();

  const { error } = await supabase
    .from("accounts")
    .update({ group_id: group_id || null })
    .eq("id", accountId);

  if (error) return jsonResponse({ error: error.message }, 500);
  return jsonResponse({ success: true });
}

/*
  # Create redirect links table

  1. New Tables
    - `redirect_links`
      - `id` (uuid, primary key)
      - `slug` (text, unique) - Short code used in the URL path e.g. /r/abc123
      - `name` (text) - Human-readable label for admin reference
      - `is_active` (boolean, default true) - Whether the link is active
      - `click_count` (integer, default 0) - Total number of clicks/redirects
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `redirect_link_targets`
      - `id` (uuid, primary key)
      - `redirect_link_id` (uuid, FK to redirect_links) - Parent link
      - `account_id` (uuid, FK to accounts) - The LINE account
      - `friend_add_url` (text) - The LINE friend add URL to redirect to
      - `weight` (integer, default 1) - Weight for weighted random selection
      - `click_count` (integer, default 0) - Clicks routed to this target
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Admin-only policies for CRUD operations
    - Public SELECT on redirect_links and redirect_link_targets for the redirect page (no auth needed for visitors)

  3. Notes
    - The slug is unique and indexed for fast lookup
    - Weighted random selection allows uneven distribution across LINE accounts
    - click_count tracking on both tables for analytics
*/

CREATE TABLE IF NOT EXISTS redirect_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  click_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS redirect_link_targets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  redirect_link_id uuid NOT NULL REFERENCES redirect_links(id) ON DELETE CASCADE,
  account_id uuid REFERENCES accounts(id) ON DELETE CASCADE,
  friend_add_url text NOT NULL,
  weight integer NOT NULL DEFAULT 1,
  click_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_redirect_links_slug ON redirect_links(slug);
CREATE INDEX IF NOT EXISTS idx_redirect_link_targets_link_id ON redirect_link_targets(redirect_link_id);

ALTER TABLE redirect_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE redirect_link_targets ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER update_redirect_links_updated_at
  BEFORE UPDATE ON redirect_links
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE POLICY "Admins can select redirect_links"
  ON redirect_links FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can insert redirect_links"
  ON redirect_links FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admins can update redirect_links"
  ON redirect_links FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can delete redirect_links"
  ON redirect_links FOR DELETE
  TO authenticated
  USING (is_admin());

CREATE POLICY "Public can read active redirect_links"
  ON redirect_links FOR SELECT
  TO anon
  USING (is_active = true);

CREATE POLICY "Admins can select redirect_link_targets"
  ON redirect_link_targets FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can insert redirect_link_targets"
  ON redirect_link_targets FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admins can update redirect_link_targets"
  ON redirect_link_targets FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can delete redirect_link_targets"
  ON redirect_link_targets FOR DELETE
  TO authenticated
  USING (is_admin());

CREATE POLICY "Public can read redirect_link_targets"
  ON redirect_link_targets FOR SELECT
  TO anon
  USING (
    EXISTS (
      SELECT 1 FROM redirect_links
      WHERE redirect_links.id = redirect_link_targets.redirect_link_id
      AND redirect_links.is_active = true
    )
  );

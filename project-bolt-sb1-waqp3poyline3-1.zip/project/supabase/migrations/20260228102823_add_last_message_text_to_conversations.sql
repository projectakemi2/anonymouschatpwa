/*
  # Add last_message_text column to conversations

  1. Modified Tables
    - `conversations`
      - Added `last_message_text` (text, default '') - stores the latest message preview text

  2. Functions and Triggers
    - `update_conversation_last_message_text()` - trigger function that auto-updates
      last_message_text on conversations when a new message is inserted
    - Trigger fires AFTER INSERT on messages

  3. Data Backfill
    - Populates last_message_text for all existing conversations using the most recent message

  This eliminates the need to fetch all messages just to display conversation previews,
  dramatically reducing query time for the conversation list.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'conversations' AND column_name = 'last_message_text'
  ) THEN
    ALTER TABLE conversations ADD COLUMN last_message_text text NOT NULL DEFAULT '';
  END IF;
END $$;

UPDATE conversations c
SET last_message_text = COALESCE(sub.preview, '')
FROM (
  SELECT DISTINCT ON (conversation_id)
    conversation_id,
    CASE
      WHEN video_url IS NOT NULL AND (text IS NULL OR text = '') THEN '[動画]'
      WHEN image_url IS NOT NULL AND (text IS NULL OR text = '') THEN '[画像]'
      ELSE COALESCE(text, '')
    END AS preview
  FROM messages
  ORDER BY conversation_id, created_at DESC
) sub
WHERE c.id = sub.conversation_id;

CREATE OR REPLACE FUNCTION public.update_conversation_last_message_text()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE conversations
  SET last_message_text = CASE
    WHEN NEW.video_url IS NOT NULL AND (NEW.text IS NULL OR NEW.text = '') THEN '[動画]'
    WHEN NEW.image_url IS NOT NULL AND (NEW.text IS NULL OR NEW.text = '') THEN '[画像]'
    ELSE COALESCE(NEW.text, '')
  END
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_update_conversation_last_message_text'
  ) THEN
    CREATE TRIGGER trg_update_conversation_last_message_text
      AFTER INSERT ON messages
      FOR EACH ROW EXECUTE FUNCTION update_conversation_last_message_text();
  END IF;
END $$;
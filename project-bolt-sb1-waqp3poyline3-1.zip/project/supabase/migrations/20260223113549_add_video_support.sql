/*
  # Add video support to messages and broadcasts

  1. Modified Tables
    - `messages`
      - Add `video_url` (text, nullable) - URL for video content stored in Supabase storage
      - Update `message_type` to support 'video' value
    - `broadcasts`
      - Add `video_url` (text, nullable) - URL for video content in broadcast messages

  2. Important Notes
    - Existing data is unaffected; new columns are nullable
    - message_type column already stores text values, no constraint change needed
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'video_url'
  ) THEN
    ALTER TABLE messages ADD COLUMN video_url text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'broadcasts' AND column_name = 'video_url'
  ) THEN
    ALTER TABLE broadcasts ADD COLUMN video_url text;
  END IF;
END $$;
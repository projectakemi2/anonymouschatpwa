/*
  # Add anon SELECT policies for realtime subscriptions

  1. Security Changes
    - Add SELECT policy on `messages` for `anon` role
      - Allows anon role to receive realtime INSERT events
      - Required because Supabase Realtime checks RLS before delivering events
    - Add SELECT policy on `conversations` for `anon` role
      - Same reason as above for conversation INSERT events

  2. Important Notes
    - The frontend Supabase client connects with the anon key (not authenticated)
    - Without these policies, realtime subscriptions silently fail and
      the client retries connections repeatedly, causing performance issues
    - All data mutations still go through the edge function using service_role_key,
      so these read-only policies don't weaken write security
    - The anon role can only SELECT; it cannot INSERT, UPDATE, or DELETE
*/

CREATE POLICY "Anon can select messages for realtime"
  ON messages FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anon can select conversations for realtime"
  ON conversations FOR SELECT
  TO anon
  USING (true);

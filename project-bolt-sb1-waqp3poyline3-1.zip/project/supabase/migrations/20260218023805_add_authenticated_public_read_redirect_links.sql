/*
  # Add public read policies for authenticated users on redirect tables

  1. Security Changes
    - Add SELECT policy on `redirect_links` for authenticated users to read active links
    - Add SELECT policy on `redirect_link_targets` for authenticated users to read targets of active links
    - This ensures redirect pages work regardless of whether the visitor is logged in or not

  2. Notes
    - The existing admin policies remain unchanged
    - These new policies allow any authenticated user to read active redirect links (needed for redirect page)
    - The admin-only policies still control insert/update/delete
*/

CREATE POLICY "Authenticated can read active redirect_links"
  ON redirect_links
  FOR SELECT
  TO authenticated
  USING (is_active = true OR is_admin());

CREATE POLICY "Authenticated can read active redirect_link_targets"
  ON redirect_link_targets
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM redirect_links
      WHERE redirect_links.id = redirect_link_targets.redirect_link_id
      AND redirect_links.is_active = true
    )
    OR is_admin()
  );

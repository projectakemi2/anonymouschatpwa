/*
  # Add distribution mode to redirect links

  1. Modified Tables
    - `redirect_links`
      - Added `distribution_mode` (text, default 'weighted')
        - 'weighted': Original weight-based random distribution
        - 'balanced': Prioritizes accounts with fewer followers (friends)
          to balance follower counts across accounts

  2. Modified Functions
    - Dropped and recreated `get_active_redirect_targets` with new return columns:
      - `follower_count`: Number of active followers per account (from conversations)
      - `distribution_mode`: The link's distribution mode
      This allows the client to apply the correct selection algorithm

  3. Notes
    - Follower count is derived from the conversations table
      where is_active = true and is_blocked = false (active followers)
    - For 'balanced' mode, the client uses inverse follower count
      as effective weight so accounts with fewer followers get more traffic
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'redirect_links' AND column_name = 'distribution_mode'
  ) THEN
    ALTER TABLE redirect_links
      ADD COLUMN distribution_mode text NOT NULL DEFAULT 'weighted'
      CHECK (distribution_mode IN ('weighted', 'balanced'));
  END IF;
END $$;

DROP FUNCTION IF EXISTS get_active_redirect_targets(text);

CREATE OR REPLACE FUNCTION get_active_redirect_targets(p_link_slug text)
RETURNS TABLE (
  link_id uuid,
  target_id uuid,
  friend_add_url text,
  weight integer,
  follower_count bigint,
  distribution_mode text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT
    rl.id AS link_id,
    rlt.id AS target_id,
    rlt.friend_add_url,
    rlt.weight,
    COALESCE(fc.cnt, 0) AS follower_count,
    rl.distribution_mode
  FROM redirect_links rl
  JOIN redirect_link_targets rlt ON rlt.redirect_link_id = rl.id
  LEFT JOIN accounts a ON a.id = rlt.account_id
  LEFT JOIN LATERAL (
    SELECT COUNT(*) AS cnt
    FROM conversations c
    WHERE c.account_id = rlt.account_id
      AND c.is_active = true
      AND c.is_blocked = false
  ) fc ON true
  WHERE rl.slug = p_link_slug
    AND rl.is_active = true
    AND (rlt.account_id IS NULL OR a.is_enabled = true);
END;
$$;

/*
  # Add RPC function for redirect click counting

  1. New Functions
    - `increment_redirect_clicks(p_link_id uuid, p_target_id uuid)` 
      - Atomically increments click_count on both the redirect_link and the selected target
      - Callable by anonymous users (visitors clicking the redirect link)

  2. Security
    - Function is marked SECURITY DEFINER to bypass RLS for the update
    - Only increments counts, cannot read or modify other data
*/

CREATE OR REPLACE FUNCTION increment_redirect_clicks(p_link_id uuid, p_target_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE redirect_links
  SET click_count = click_count + 1
  WHERE id = p_link_id;

  UPDATE redirect_link_targets
  SET click_count = click_count + 1
  WHERE id = p_target_id;
END;
$$;

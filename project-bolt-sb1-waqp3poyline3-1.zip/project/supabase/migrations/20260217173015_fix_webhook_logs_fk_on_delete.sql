/*
  # Fix webhook_logs foreign key constraint

  1. Changes
    - Update `webhook_logs.matched_account_id` foreign key from NO ACTION to SET NULL
    - This allows account deletion without losing webhook log history

  2. Reason
    - Account deletion was failing due to webhook_logs referencing the account
*/

ALTER TABLE webhook_logs
  DROP CONSTRAINT IF EXISTS webhook_logs_matched_account_id_fkey;

ALTER TABLE webhook_logs
  ADD CONSTRAINT webhook_logs_matched_account_id_fkey
  FOREIGN KEY (matched_account_id) REFERENCES accounts(id)
  ON DELETE SET NULL;

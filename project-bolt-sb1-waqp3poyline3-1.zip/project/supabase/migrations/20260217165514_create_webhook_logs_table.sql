/*
  # Create webhook_logs table for debugging

  1. New Tables
    - `webhook_logs`
      - `id` (uuid, primary key)
      - `destination` (text) - LINE bot user ID from webhook payload
      - `event_count` (integer) - number of events in the webhook
      - `matched_account_id` (uuid, nullable) - which account was matched
      - `match_method` (text, nullable) - how the account was matched (bot_user_id, signature, none)
      - `signature_valid` (boolean) - whether signature was verified
      - `error_message` (text, nullable) - any error that occurred
      - `raw_destination` (text, nullable) - raw destination for debugging
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Allow authenticated users to read logs
*/

CREATE TABLE IF NOT EXISTS webhook_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  destination text,
  event_count integer DEFAULT 0,
  matched_account_id uuid REFERENCES accounts(id),
  match_method text,
  signature_valid boolean DEFAULT false,
  error_message text,
  raw_destination text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE webhook_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read webhook logs"
  ON webhook_logs FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);
